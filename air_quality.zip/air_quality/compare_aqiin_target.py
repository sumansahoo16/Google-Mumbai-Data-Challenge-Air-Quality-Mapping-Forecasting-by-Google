"""Compare AQI.in daily PM2.5 exports with the four Zindi target stations.

Usage: python3 air_quality/compare_aqiin_target.py [--aqi-csv path/to/daily.csv]
The optional CSV must have columns date,pm25_ug_m3 and contain daily mean
concentrations, not AQI index values. All dates are Asia/Kolkata calendar days.
"""

import argparse
import csv
from collections import defaultdict
from datetime import date, datetime, timedelta
from math import sqrt
from pathlib import Path
from statistics import mean
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
TRAIN = ROOT / "input" / "Train (2).csv"
TODAY = datetime.now(ZoneInfo("Asia/Kolkata")).date()
START = TODAY - timedelta(days=29)
OUTPUT = ROOT / "output" / ("aqiin_comparison_" + datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST"))


def correlation(xs, ys):
    if len(xs) < 3:
        return None
    mx, my = mean(xs), mean(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    denominator = sqrt(sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys))
    return numerator / denominator if denominator else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aqi-csv", type=Path, help="AQI.in daily PM2.5 concentration CSV: date,pm25_ug_m3")
    args = parser.parse_args()
    readings = defaultdict(list)
    with TRAIN.open(newline="") as file:
        for row in csv.DictReader(file):
            day = date.fromisoformat(row["timestamp_ist"][:10])
            if START <= day <= TODAY and row["pm25"] and row["flag_high_1000"].lower() != "true":
                readings[(day, row["station_name"])].append(float(row["pm25"]))
    station_names = sorted({station for _, station in readings})
    aqi = {}
    if args.aqi_csv:
        with args.aqi_csv.open(newline="") as file:
            for row in csv.DictReader(file):
                day = date.fromisoformat(row["date"])
                if START <= day <= TODAY:
                    aqi[day] = float(row["pm25_ug_m3"])

    OUTPUT.mkdir(parents=True, exist_ok=True)
    daily = []
    for offset in range(30):
        day = START + timedelta(days=offset)
        station_values = {name: mean(readings[(day, name)]) if readings[(day, name)] else None for name in station_names}
        valid = [v for v in station_values.values() if v is not None]
        daily.append({"date": day.isoformat(), "target_four_station_mean_ug_m3": mean(valid) if len(valid) == 4 else None,
                      "target_station_count": len(valid), "target_hourly_readings": sum(len(readings[(day, name)]) for name in station_names),
                      "aqiin_city_pm25_ug_m3": aqi.get(day), **{name: station_values[name] for name in station_names}})
    with (OUTPUT / "daily_comparison.csv").open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=daily[0].keys())
        writer.writeheader()
        writer.writerows(daily)

    paired = [row for row in daily if row["target_four_station_mean_ug_m3"] is not None and row["aqiin_city_pm25_ug_m3"] is not None]
    lines = ["# AQI.in versus Zindi Mumbai PM2.5", "", f"Window: {START} to {TODAY} (30 calendar days, IST).",
             "Zindi source: `input/Train (2).csv`, four OpenAQ/CPCB PM2.5 stations. Flagged values above 1,000 µg/m³ excluded.",
             "Daily Zindi city value is the equal-weight average of four station daily means, only when all four stations report.",
             "AQI.in values must be **daily PM2.5 concentrations in µg/m³**, not AQI index values.", "",
             f"Zindi dates with all four stations: {sum(row['target_station_count'] == 4 for row in daily)}/30.",
             f"Matched dates with AQI.in concentration: {len(paired)}.", ""]
    if paired:
        x = [row["target_four_station_mean_ug_m3"] for row in paired]
        y = [row["aqiin_city_pm25_ug_m3"] for row in paired]
        r = correlation(x, y)
        lines.extend([f"Pearson correlation of daily means: {r:.3f}." if r is not None else "Correlation undefined (fewer than three pairs or constant series).",
                      f"Mean AQI.in minus Zindi: {mean(b-a for a,b in zip(x,y)):.2f} µg/m³.",
                      f"Mean absolute difference: {mean(abs(b-a) for a,b in zip(x,y)):.2f} µg/m³."])
    else:
        lines.extend(["**Correlation cannot be computed:** no AQI.in dated daily PM2.5 concentration series was available.",
                      "The public page was blocked by Cloudflare; the 30-day API returned HTTP 401 without authentication.",
                      "AQI.in displays a Mumbai city estimate and many location names, but no matching sensor IDs were verified.",
                      "A matching location name alone does not establish identical monitors or data processing."])
    lines.extend(["", "AQI.in dashboard: https://www.aqi.in/in/dashboard/india/maharashtra/mumbai/pm",
                  "Competition: https://zindi.world/competitions/google-mumbai-data-challenge/data", ""])
    (OUTPUT / "report.md").write_text("\n".join(lines))
    print(OUTPUT)


if __name__ == "__main__":
    main()
