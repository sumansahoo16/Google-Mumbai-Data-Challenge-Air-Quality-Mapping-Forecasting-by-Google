"""Build a self-contained daily/weekly PM2.5 EDA dashboard from Zindi Train.

Run: python3 air_quality/build_eda_dashboard.py
Only the Python standard library is required. The generated HTML needs no server.
"""

import csv
import json
import shutil
import statistics
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
TRAIN = ROOT / "input" / "Train (2).csv"
STAMP = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
OUT = ROOT / "output" / f"daily_weekly_eda_{STAMP}"
OUT.mkdir(parents=True)

records = []
excluded = 0
with TRAIN.open(newline="") as fh:
    for row in csv.DictReader(fh):
        value = float(row["pm25"])
        if row["flag_high_1000"].lower() == "true" or not 0 <= value <= 1000:
            excluded += 1
            continue
        day = date.fromisoformat(row["timestamp_ist"][:10])
        records.append((day, row["station_name"].split(",")[0], value))

first, last = min(r[0] for r in records), max(r[0] for r in records)
stations = sorted({r[1] for r in records})


def summarize(period):
    groups = defaultdict(list)
    for day, station, value in records:
        key = day if period == "daily" else day - timedelta(days=day.weekday())
        groups[(key, station)].append(value)
        groups[(key, "All stations")].append(value)
    rows = []
    for (start, station), values in sorted(groups.items()):
        end = start if period == "daily" else start + timedelta(days=6)
        days = (min(end, last) - max(start, first)).days + 1
        expected = days * 24 * (len(stations) if station == "All stations" else 1)
        rows.append([start.isoformat(), station, round(statistics.median(values), 2),
                     round(statistics.mean(values), 2), len(values), expected])
    return rows


payload = {"daily": summarize("daily"), "weekly": summarize("weekly"),
           "stations": ["All stations", *stations], "first": first.isoformat(),
           "last": last.isoformat(), "rows": len(records), "excluded": excluded}

html = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mumbai PM2.5 · Daily and weekly EDA</title>
<style>
:root{--bg:#f5f7f4;--panel:#fff;--ink:#14251f;--muted:#60736a;--line:#dce5df;--green:#08765c;--blue:#3469aa;--orange:#cc6b26;--red:#b63f43;--soft:#e9f4ee;--shadow:0 8px 30px rgba(19,48,37,.06)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}header{background:#123e34;color:#fff;padding:25px max(24px,calc((100vw - 1260px)/2));}header h1{font-size:clamp(24px,3vw,36px);line-height:1.15;margin:0 0 7px;font-weight:650}header p{margin:0;color:#d5e8dd}main{max-width:1308px;margin:0 auto;padding:24px}.toolbar{display:flex;gap:14px;flex-wrap:wrap;align-items:end;background:var(--panel);padding:16px 18px;border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow)}label{display:grid;gap:5px;font-size:12px;font-weight:650;color:var(--muted)}select,input,button{font:inherit}select,input{min-height:40px;border:1px solid #c9d8ce;border-radius:8px;background:#fff;color:var(--ink);padding:7px 10px}select{min-width:170px}input[type=date]{min-width:145px}button{border:1px solid #bdd3c5;color:#0b654f;background:#fff;border-radius:8px;min-height:40px;padding:8px 13px;cursor:pointer;font-weight:600}button:hover,button:focus-visible{background:var(--soft)}button.active{background:var(--green);color:#fff;border-color:var(--green)}.quick{display:flex;gap:6px;flex-wrap:wrap}.quick button{font-size:12px}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:13px;margin:17px 0}.card,.panel{background:var(--panel);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow)}.card{padding:17px 19px}.card small{display:block;color:var(--muted);font-size:12px;font-weight:650}.card strong{display:block;font-size:25px;letter-spacing:-.03em;margin-top:3px}.card span{font-size:12px;color:var(--muted)}.charts{display:grid;grid-template-columns:1fr 1fr;gap:15px}.panel{padding:18px 20px;margin-bottom:15px;min-width:0}.panel h2{font-size:17px;margin:0 0 3px}.sub{font-size:12px;color:var(--muted);margin:0 0 12px}.chart{height:300px;position:relative}.chart svg{width:100%;height:100%;overflow:visible}.chart svg text{font:11px system-ui,sans-serif;fill:var(--muted)}.chart svg .grid{stroke:#e4ece7;stroke-width:1}.chart svg .axis{stroke:#bdcec3;stroke-width:1}.chart svg .trend{fill:none;stroke:var(--green);stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}.chart svg .area{fill:#eaf5ee}.chart svg .coverage{fill:var(--blue)}.chart svg .marker{stroke:var(--orange);stroke-dasharray:4 4;stroke-width:1.6}.chart svg .hoverline{stroke:#78948a;stroke-width:1;stroke-dasharray:3 3}.chart svg .dot{fill:var(--green);stroke:#fff;stroke-width:2}.tooltip{position:absolute;pointer-events:none;z-index:5;background:#17382e;color:#fff;border-radius:8px;padding:9px 11px;min-width:150px;box-shadow:var(--shadow);font-size:12px;display:none}.insight{border-left:4px solid var(--orange);padding-left:13px;margin:9px 0;color:var(--ink)}.note{font-size:12px;color:var(--muted)}.legend{display:flex;gap:17px;color:var(--muted);font-size:12px;flex-wrap:wrap}.legend i{display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--green);margin-right:5px}.legend i.orange{background:var(--orange)}.legend i.blue{background:var(--blue)}.tablewrap{overflow:auto;max-height:320px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:8px 11px;border-bottom:1px solid var(--line);white-space:nowrap}th{position:sticky;top:0;background:#f3f8f4;color:var(--muted)}td.num{text-align:right;font-variant-numeric:tabular-nums}th.num{text-align:right}.foot{margin:8px 0 0;font-size:12px;color:var(--muted)}@media(max-width:900px){.charts{grid-template-columns:1fr}.cards{grid-template-columns:repeat(2,1fr)}}@media(max-width:600px){main{padding:14px}.cards{grid-template-columns:1fr 1fr;gap:8px}.card{padding:12px}.card strong{font-size:20px}.panel{padding:15px}.chart{height:260px}.toolbar{gap:10px}.toolbar label{flex:1 1 135px}select,input[type=date]{width:100%;min-width:0}.quick{width:100%}}
</style>
</head>
<body>
<header><h1>Mumbai PM2.5 explorer</h1><p>Daily and weekly patterns · four competition stations · timestamps in IST</p></header>
<main>
 <div class="toolbar" aria-label="Dashboard filters">
  <label>Station<select id="station"></select></label>
  <label>Measure<select id="metric"><option value="median">Median PM2.5</option><option value="mean">Mean PM2.5</option></select></label>
  <label>From<input type="date" id="from"></label><label>To<input type="date" id="to"></label>
  <div class="quick" aria-label="Quick date ranges"><button data-range="all">All data</button><button data-range="90">Last 90 days</button><button data-range="diwali">Diwali 2025</button></div>
 </div>
 <div class="cards" aria-live="polite"><div class="card"><small>Daily typical level</small><strong id="kLevel">—</strong><span>Median of selected daily values · µg/m³</span></div><div class="card"><small>Observed station-hours</small><strong id="kHours">—</strong><span>Valid hourly targets in selection</span></div><div class="card"><small>Coverage</small><strong id="kCoverage">—</strong><span>Observed / possible station-hours</span></div><div class="card"><small>Highest daily median</small><strong id="kHigh">—</strong><span id="kHighDate">—</span></div></div>
 <div class="charts"><section class="panel"><h2>Daily PM2.5</h2><p class="sub">Each point summarizes the observed hours on one IST date.</p><div class="chart" id="dailyChart" role="img" aria-label="Daily PM2.5 time series"><div class="tooltip"></div></div><div class="legend"><span><i></i>PM2.5</span><span><i class="orange"></i>Diwali 2025</span></div></section><section class="panel"><h2>Weekly PM2.5</h2><p class="sub">Monday–Sunday weeks; median or mean of all observed hours in that week.</p><div class="chart" id="weeklyChart" role="img" aria-label="Weekly PM2.5 time series"><div class="tooltip"></div></div><div class="legend"><span><i></i>PM2.5</span><span><i class="orange"></i>Diwali week</span></div></section></div>
 <div class="charts"><section class="panel"><h2>Daily measurement coverage</h2><p class="sub">This exposes sparse days that can distort apparent peaks.</p><div class="chart" id="coverageChart" role="img" aria-label="Daily reporting coverage"><div class="tooltip"></div></div><div class="legend"><span><i class="blue"></i>Observed share of possible station-hours</span></div></section><section class="panel"><h2>Reading the Diwali pattern</h2><p class="sub">Competition target data, four CPCB-derived monitoring stations.</p><p class="insight">The 2025 daily median rose before Diwali on 20 October, remained elevated on 21 October, and returned near the earlier baseline by 22–23 October.</p><p class="insight">The Diwali-day sample contains 58 of 96 possible station-hours. Missing evening observations limit the precision of the peak.</p><p class="note">Patterns show association, not a causal effect. Weather, traffic, and other emissions are not controlled for here. The available training data ends on 2 November 2026, before Diwali 2026.</p><p class="note">Values flagged above 1,000 µg/m³ were excluded; <span id="excluded"></span> records in total. No targets from Test or SampleSubmission are used.</p></section></div>
 <section class="panel"><h2>Weekly detail</h2><p class="sub">Sortable by date through the date filters above; the newest week appears first.</p><div class="tablewrap"><table><thead><tr><th>Week starting</th><th class="num">Median</th><th class="num">Mean</th><th class="num">Observed hours</th><th class="num">Coverage</th></tr></thead><tbody id="weekRows"></tbody></table></div><p class="foot">Source: Zindi Google Mumbai Data Challenge Train (2).csv. Hourly PM2.5 in µg/m³; timestamp marks the end of the hour. Weekly values aggregate original hourly observations.</p></section>
</main>
<script id="dataset" type="application/json">__DATA__</script>
<script>
const D=JSON.parse(document.getElementById('dataset').textContent);
const station=document.getElementById('station'),metric=document.getElementById('metric'),from=document.getElementById('from'),to=document.getElementById('to');
const fmt=n=>Number(n).toLocaleString('en-IN',{maximumFractionDigits:1});
const iso=t=>new Date(t+'T12:00:00Z').getTime();
const dateLabel=s=>new Date(s+'T12:00:00Z').toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
D.stations.forEach(s=>{const o=document.createElement('option');o.textContent=s;o.value=s;station.appendChild(o)});
from.min=to.min=D.first;from.max=to.max=D.last;from.value=D.first;to.value=D.last;
document.getElementById('excluded').textContent=fmt(D.excluded);
function selected(kind){return D[kind].filter(r=>r[1]===station.value&&r[0]>=from.value&&r[0]<=to.value).map(r=>({date:r[0],median:r[2],mean:r[3],hours:r[4],expected:r[5],value:r[metric.value==='median'?2:3]}));}
function el(name,attrs={}){const x=document.createElementNS('http://www.w3.org/2000/svg',name);for(const [k,v] of Object.entries(attrs))x.setAttribute(k,v);return x}
function chart(id,rows,isCoverage,weekly){
 const box=document.getElementById(id),tip=box.querySelector('.tooltip');box.querySelector('svg')?.remove();
 const w=Math.max(300,box.clientWidth),h=box.clientHeight,m={l:47,r:15,t:13,b:31},pw=w-m.l-m.r,ph=h-m.t-m.b;
 const svg=el('svg',{viewBox:`0 0 ${w} ${h}`,'aria-hidden':'true'});box.insertBefore(svg,tip);
 if(!rows.length){const t=el('text',{x:w/2,y:h/2,'text-anchor':'middle'});t.textContent='No observations in this range';svg.append(t);return}
 const xx=rows.map(r=>iso(r.date)),xmin=iso(from.value),xmax=iso(to.value),span=Math.max(86400000,xmax-xmin);
 const yvals=rows.map(r=>isCoverage?r.hours/r.expected*100:r.value),high=isCoverage?100:Math.max(...yvals),ymax=isCoverage?100:Math.max(10,Math.ceil(high/25)*25);
 const x=t=>m.l+(t-xmin)/span*pw,y=v=>m.t+ph-v/ymax*ph;
 for(let i=0;i<=4;i++){const val=ymax*i/4,yy=y(val);svg.append(el('line',{class:'grid',x1:m.l,x2:w-m.r,y1:yy,y2:yy}));let lab=el('text',{x:m.l-7,y:yy+4,'text-anchor':'end'});lab.textContent=isCoverage?Math.round(val)+'%':fmt(val);svg.append(lab)}
 const nTicks=w<470?3:5;for(let i=0;i<nTicks;i++){const t=xmin+span*i/(nTicks-1),s=new Date(t).toISOString().slice(0,10),lab=el('text',{x:x(t),y:h-6,'text-anchor':i===0?'start':i===nTicks-1?'end':'middle'});lab.textContent=new Date(s+'T12:00:00Z').toLocaleDateString('en-IN',{month:'short',year:'2-digit',timeZone:'UTC'});svg.append(lab)}
 const festival=iso('2025-10-20');if(festival>=xmin&&festival<=xmax){svg.append(el('line',{class:'marker',x1:x(festival),x2:x(festival),y1:m.t,y2:m.t+ph}));let lab=el('text',{x:Math.min(w-51,Math.max(m.l+4,x(festival)+4)),y:m.t+12});lab.textContent='Diwali';svg.append(lab)}
 if(isCoverage){const bw=Math.max(1,Math.min(9,pw/Math.max(rows.length,1)*.78));rows.forEach((r,i)=>{const v=yvals[i],px=x(xx[i]);svg.append(el('rect',{class:'coverage',x:px-bw/2,y:y(v),width:bw,height:m.t+ph-y(v),opacity:.8}))})}
 else{let segment=[];const flush=()=>{if(segment.length){svg.append(el('path',{class:'trend',d:segment.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ')}));segment=[]}};rows.forEach((r,i)=>{if(i&&xx[i]-xx[i-1]>(weekly?8:2)*86400000)flush();segment.push([x(xx[i]),y(yvals[i])])});flush()}
 let hover=el('line',{class:'hoverline',y1:m.t,y2:m.t+ph,display:'none'}),dot=el('circle',{class:'dot',r:4,display:'none'});svg.append(hover,dot);
 const move=e=>{const rect=svg.getBoundingClientRect(),px=(e.clientX-rect.left)*w/rect.width;let best=0,dist=Infinity;rows.forEach((r,i)=>{const d=Math.abs(x(xx[i])-px);if(d<dist){dist=d;best=i}});const r=rows[best],cx=x(xx[best]),cy=y(yvals[best]);hover.setAttribute('x1',cx);hover.setAttribute('x2',cx);hover.removeAttribute('display');dot.setAttribute('cx',cx);dot.setAttribute('cy',cy);dot.removeAttribute('display');if(isCoverage)dot.setAttribute('display','none');tip.innerHTML=`<strong>${dateLabel(r.date)}${weekly?' week':''}</strong><br>${isCoverage?'Coverage: '+fmt(r.hours/r.expected*100)+'%':(metric.value==='median'?'Median':'Mean')+': '+fmt(r.value)+' µg/m³'}<br>${fmt(r.hours)} of ${fmt(r.expected)} hours`;tip.style.display='block';tip.style.left=Math.min(box.clientWidth-165,Math.max(0,e.clientX-rect.left+12))+'px';tip.style.top=Math.max(0,e.clientY-rect.top-48)+'px'};
 svg.addEventListener('pointermove',move);svg.addEventListener('pointerleave',()=>{tip.style.display='none';hover.setAttribute('display','none');dot.setAttribute('display','none')});
}
function render(){if(from.value>to.value)return;const daily=selected('daily'),weekly=selected('weekly');
 const ordered=daily.map(r=>r.value).sort((a,b)=>a-b),mid=Math.floor(ordered.length/2),typical=ordered.length%2?ordered[mid]:(ordered[mid-1]+ordered[mid])/2;
 document.getElementById('kLevel').textContent=ordered.length?fmt(typical):'—';
 const hours=daily.reduce((a,r)=>a+r.hours,0),days=Math.round((iso(to.value)-iso(from.value))/86400000)+1,possible=days*24*(station.value==='All stations'?D.stations.length-1:1);document.getElementById('kHours').textContent=fmt(hours);document.getElementById('kCoverage').textContent=possible?fmt(hours/possible*100)+'%':'—';
 const top=daily.length?daily.reduce((a,b)=>a.value>b.value?a:b):null;document.getElementById('kHigh').textContent=top?fmt(top.value):'—';document.getElementById('kHighDate').textContent=top?dateLabel(top.date)+' · µg/m³':'—';
 chart('dailyChart',daily,false,false);chart('weeklyChart',weekly,false,true);chart('coverageChart',daily,true,false);
 document.getElementById('weekRows').innerHTML=weekly.slice().reverse().map(r=>`<tr><td>${dateLabel(r.date)}</td><td class="num">${fmt(r.median)}</td><td class="num">${fmt(r.mean)}</td><td class="num">${fmt(r.hours)}</td><td class="num">${fmt(r.hours/r.expected*100)}%</td></tr>`).join('');
}
for(const e of [station,metric,from,to])e.addEventListener('change',render);
document.querySelectorAll('[data-range]').forEach(b=>b.addEventListener('click',()=>{let r=b.dataset.range;to.value=r==='diwali'?'2025-10-27':D.last;from.value=r==='diwali'?'2025-10-10':r==='90'?new Date(iso(D.last)-89*86400000).toISOString().slice(0,10):D.first;document.querySelectorAll('[data-range]').forEach(x=>x.classList.toggle('active',x===b));render()}));
let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(render,120)});document.querySelector('[data-range="all"]').classList.add('active');render();
</script>
</body></html>'''

html = html.replace("__DATA__", json.dumps(payload, separators=(",", ":")))
target = OUT / "daily_weekly_eda.html"
target.write_text(html)
shutil.copy2(__file__, OUT / "build_eda_dashboard_code.py")
print(target)
print(f"Daily series: {len(payload['daily'])}; weekly series: {len(payload['weekly'])}; HTML bytes: {target.stat().st_size}")
