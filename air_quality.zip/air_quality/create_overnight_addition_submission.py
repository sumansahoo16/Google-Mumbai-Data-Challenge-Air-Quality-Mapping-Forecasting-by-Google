"""Create a manual overnight-addition submission from the fixed hourly median.

Rule, using the target hour start in IST on every date:
00:00–07:00 Malad West +15, Shivaji Nagar +10, all other stations +0.
08:00–23:00 every station +0. No training data or recent text files are read.

Run: python3.11 air_quality/create_overnight_addition_submission.py
All submission prediction logic lives in this file.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT, OUTPUT = ROOT / "input", ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
BASE_RUN = OUTPUT / "fixed_hourly_median_20261109_190846_076430_IST"
START_HOUR, END_HOUR = 0, 7  # Inclusive target-start hours in IST.
ADDITIONS = {"Malad West, Mumbai - IITM": 15.0,
             "Shivaji Nagar, Mumbai - BMC": 10.0}


def newest(stem: str) -> Path:
    files = list(INPUT.glob(f"{stem}*.csv"))
    if not files:
        raise FileNotFoundError(f"Missing {stem} CSV in {INPUT}")
    return max(files, key=lambda path: (path.stat().st_mtime_ns, path.name))


def only(folder: Path, pattern: str) -> Path:
    files = list(folder.glob(pattern))
    if len(files) != 1:
        raise ValueError(f"Expected exactly one {pattern} in {folder}")
    return files[0]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"overnight_addition_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"create_overnight_addition_submission_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"creation_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("overnight_addition")

    base_file = only(BASE_RUN, "submission_*.csv")
    base = pd.read_csv(base_file)
    sample = pd.read_csv(newest("SampleSubmission"))
    test = pd.read_csv(newest("Test"))
    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    assert base.columns.tolist() == ["ID", "Target"]
    assert sample.columns.tolist() == ["ID", "Target"]
    assert len(base) == len(sample) == len(test) == 2592
    assert base.ID.is_unique and sample.ID.is_unique and test.ID.is_unique
    assert base.ID.tolist() == sample.ID.tolist()
    assert set(test.ID) == set(sample.ID)
    assert set(ADDITIONS).issubset(set(stations.station_name))
    assert base.Target.notna().all() and np.isfinite(base.Target).all()

    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["hour"] = test.target_start_ist.dt.hour
    test = test.merge(stations, on="location_id", how="left", validate="many_to_one")
    assert test.station_name.notna().all()
    test["base_prediction_pm25"] = test.ID.map(base.set_index("ID").Target)
    test["addition_pm25"] = np.where(
        test.hour.between(START_HOUR, END_HOUR), test.station_name.map(ADDITIONS).fillna(0.0), 0.0)
    test["prediction_pm25"] = test.base_prediction_pm25 + test.addition_pm25
    assert test.prediction_pm25.notna().all() and np.isfinite(test.prediction_pm25).all()
    assert (test.prediction_pm25 >= 0).all()
    assert test.loc[~test.hour.between(START_HOUR, END_HOUR), "addition_pm25"].eq(0).all()
    assert test.groupby(["location_id", "hour"]).prediction_pm25.nunique().eq(1).all()

    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(test.set_index("ID").prediction_pm25)
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    submission_file = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_file, index=False, float_format="%.6f")
    reloaded = pd.read_csv(submission_file)
    assert reloaded.columns.tolist() == ["ID", "Target"]
    assert reloaded.ID.tolist() == sample.ID.tolist()
    assert reloaded.Target.notna().all()

    profile = test[["location_id", "station_name", "hour", "base_prediction_pm25",
                    "addition_pm25", "prediction_pm25"]].drop_duplicates(["location_id", "hour"])
    assert len(profile) == 4 * 24
    profile = profile.sort_values(["location_id", "hour"])
    profile.to_csv(run_dir / f"station_hour_profile_{stamp}.csv", index=False, float_format="%.6f")
    changed = test.loc[test.addition_pm25 != 0]
    station_summary = changed.groupby(["location_id", "station_name", "addition_pm25"]).size().reset_index(name="changed_submission_rows")
    station_summary.to_csv(run_dir / f"adjustment_summary_{stamp}.csv", index=False)
    metrics = {"run_timestamp_ist": stamp, "method": "manual fixed overnight addition to saved hourly-median submission",
               "base_run": BASE_RUN.name, "base_submission": base_file.name,
               "target_hour_basis": "target_start_ist in Asia/Kolkata",
               "adjusted_hours_inclusive": [START_HOUR, END_HOUR],
               "station_additions_pm25": ADDITIONS, "same_profile_every_day": True,
               "submission_rows": len(submission), "changed_rows": len(changed),
               "changed_station_hours": len(profile.loc[profile.addition_pm25 != 0]),
               "adjustment_summary": station_summary.to_dict(orient="records"),
               "prediction_min": float(submission.Target.min()),
               "prediction_max": float(submission.Target.max()),
               "input_note": "No Train CSV or last_days_data text files were read; predictions come only from the saved base submission and the stated rule."}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Base %s; %d IDs; %d changed rows across %d station-hours",
             base_file, len(submission), len(changed), metrics["changed_station_hours"])
    log.info("Rule: target-start hours %02d–%02d IST, additions %s",
             START_HOUR, END_HOUR, ADDITIONS)
    log.info("Submission %s; range %.3f–%.3f", submission_file,
             submission.Target.min(), submission.Target.max())
    print(run_dir)


if __name__ == "__main__":
    main()
