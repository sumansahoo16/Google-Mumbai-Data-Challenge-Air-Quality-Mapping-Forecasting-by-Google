"""Create a sourced 2022–2026 Mumbai PM2.5 monthly comparison.

Run: python3 air_quality/analyze_five_year_pm25.py

OpenCity's CPCB-derived 2024–25 quarter-hour PM2.5 is aggregated to
hour-ending values only when at least three readings exist. For each of
the four competition station names, use OpenCity through February 2025
and Zindi Train from March 2025 onward. The separate AirNow monitor is
retained as a separate series throughout; no values are filled or
blended across monitors. All months are in Asia/Kolkata.
"""

from __future__ import annotations

import calendar
import csv
import json
import shutil
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean, median
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
IST = ZoneInfo("Asia/Kolkata")
RAW = sorted((ROOT / "input").glob("opencity_cpcb_2024_2025_*"))[-1]
TEN_YEAR = sorted((ROOT / "input").glob("mumbai_pm25_ten_year_*/monthly_pm25_2017_2026.csv"))[-1]
TRAIN = ROOT / "input" / "Train (2).csv"
STATIONS = {
    "borivali": ("Borivali East", "site_5400", "12236418"),
    "malad": ("Malad West", "site_5402", "12236426"),
    "byculla": ("Byculla", "site_5960", "12238567"),
    "shivaji": ("Shivaji Nagar", "site_5961", "12238576"),
}
STATION_BY_SENSOR = {ids[2]: ids[0] for ids in STATIONS.values()}


def open_city_months() -> tuple[dict, dict]:
    monthly = defaultdict(list)
    excluded = defaultdict(int)
    for key, (station, site_id, _) in STATIONS.items():
        hourly = defaultdict(list)
        with (RAW / f"{key}.csv").open(newline="", encoding="utf-8-sig") as stream:
            for row in csv.DictReader(stream):
                timestamp = row.get("Timestamp")
                raw_value = row.get("PM2.5 (µg/m³)")
                if not timestamp or not raw_value:
                    continue
                if row["Station ID"] != site_id:
                    raise ValueError(f"Unexpected OpenCity station ID: {row['Station ID']}")
                try:
                    value = float(raw_value)
                except ValueError:
                    excluded[station] += 1
                    continue
                if not 0 <= value <= 1000:
                    excluded[station] += 1
                    continue
                observed_at = datetime.fromisoformat(timestamp).astimezone(IST)
                hour_end = observed_at.replace(minute=0, second=0, microsecond=0)
                if observed_at.minute or observed_at.second or observed_at.microsecond:
                    hour_end += timedelta(hours=1)
                hourly[hour_end].append(value)
        for hour_end, values in hourly.items():
            if len(values) >= 3:
                monthly[(station, hour_end.strftime("%Y-%m"))].append(mean(values))
    return monthly, dict(excluded)


def train_months() -> tuple[dict, int]:
    monthly = defaultdict(list)
    excluded = 0
    with TRAIN.open(newline="") as stream:
        for row in csv.DictReader(stream):
            station = STATION_BY_SENSOR.get(row["sensor_id"])
            if station is None:
                continue
            value = float(row["pm25"])
            if row["flag_high_1000"].lower() == "true" or not 0 <= value <= 1000:
                excluded += 1
                continue
            monthly[(station, row["timestamp_ist"][:7])].append(value)
    return monthly, excluded


def main() -> None:
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    out = ROOT / "output" / f"five_year_pm25_{stamp}"
    out.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, out / "analyze_five_year_pm25_code.py")
    open_city, open_city_excluded = open_city_months()
    train, train_excluded = train_months()
    with TEN_YEAR.open(newline="") as stream:
        airnow = {row["month_ist"]: row for row in csv.DictReader(stream)
                  if row["series_id"] == "openaq_airnow_8039_23320"}

    records = []
    for year in range(2022, 2027):
        for number in range(1, 13):
            month = f"{year}-{number:02d}"
            hours = calendar.monthrange(year, number)[1] * 24
            history = airnow[month]
            records.append({
                "month_ist": month, "station_name": "US Diplomatic Post: Mumbai",
                "source": "OpenAQ archive / AirNow", "source_station_id": "8039",
                "source_sensor_id": "23320", "mean_pm25_ug_m3": history["mean_pm25_ug_m3"],
                "median_pm25_ug_m3": history["median_pm25_ug_m3"],
                "observed_hours": history["observed_hours"], "calendar_hours": hours,
                "coverage_pct": history["coverage_pct"],
                "coverage_status": history["coverage_status"],
            })
            for key, (station, site_id, train_id) in STATIONS.items():
                if month < "2024-01":
                    source, sensor_id, values = "No PM2.5 station data found", "", []
                elif month <= "2025-02":
                    source, sensor_id = "OpenCity / CPCB repository", site_id
                    values = open_city.get((station, month), [])
                else:
                    source, sensor_id = "Zindi Train / CPCB", train_id
                    values = train.get((station, month), [])
                coverage = 100 * len(values) / hours
                records.append({
                    "month_ist": month, "station_name": station,
                    "source": source, "source_station_id": sensor_id if source.startswith("OpenCity") else "",
                    "source_sensor_id": sensor_id if source.startswith("Zindi") else "",
                    "mean_pm25_ug_m3": round(mean(values), 3) if values else "",
                    "median_pm25_ug_m3": round(median(values), 3) if values else "",
                    "observed_hours": len(values), "calendar_hours": hours,
                    "coverage_pct": round(coverage, 1),
                    "coverage_status": "no data" if not values else "sparse (<75%)" if coverage < 75 else "at least 75%",
                })

    csv_path = out / "monthly_pm25_2022_2026.csv"
    with csv_path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)

    comparison = []
    for station, _, _ in STATIONS.values():
        for month in sorted({month for name, month in open_city if name == station and month >= "2025-03"}):
            a, b = open_city[(station, month)], train.get((station, month), [])
            if a and b:
                comparison.append({"station_name": station, "month_ist": month,
                                   "opencity_mean": round(mean(a), 3),
                                   "zindi_mean": round(mean(b), 3),
                                   "difference_opencity_minus_zindi": round(mean(a) - mean(b), 3),
                                   "opencity_coverage_pct": round(100 * len(a) / (calendar.monthrange(int(month[:4]), int(month[5:]))[1] * 24), 1),
                                   "zindi_coverage_pct": round(100 * len(b) / (calendar.monthrange(int(month[:4]), int(month[5:]))[1] * 24), 1)})
    with (out / "overlap_check_2025.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(comparison[0]))
        writer.writeheader()
        writer.writerows(comparison)

    provenance = {
        "created_at_ist": datetime.now(IST).isoformat(),
        "period": "2022-01 to 2026-12 calendar grid; future/unobserved months are blank",
        "sources": [
            {"name": "OpenAQ public archive / AirNow", "local_monthly_file": str(TEN_YEAR),
             "location_id": "8039", "sensor_id": "23320",
             "url": "https://docs.openaq.org/aws/year-guide"},
            {"name": "OpenCity / CPCB repository", "local_raw_folder": str(RAW),
             "stations": {v[0]: v[1] for v in STATIONS.values()},
             "url": "https://data.opencity.in/dataset/mumbai-hourly-air-quality-reports"},
            {"name": "Zindi Train / CPCB", "local_file": str(TRAIN),
             "stations": {v[0]: v[2] for v in STATIONS.values()},
             "url": "https://zindi.world/competitions/google-mumbai-data-challenge/data"},
        ],
        "method": "All values are PM2.5 concentration in µg/m³ and grouped by IST calendar month. "
                  "OpenCity UTC quarter-hour records are converted to IST, assigned to their ending hour, "
                  "and averaged if >=3 valid readings exist. For four named stations use OpenCity "
                  "2024-01 through 2025-02, Zindi 2025-03 onward. AirNow remains a separate series. "
                  "Values outside 0–1000 µg/m³ are excluded. Blank means missing, never zero.",
        "limitations": "OpenCity site IDs and Zindi sensor IDs differ; matching station names do not prove "
                       "identical instrument or data processing. OpenCity/Zindi overlap is reported separately. "
                       "AirNow is a different monitor and cannot be spliced with the four CPCB stations. "
                       "OpenCity's 2017–23 station files contain AQI rather than PM2.5 concentration and were excluded.",
        "open_city_excluded": open_city_excluded,
        "train_excluded": train_excluded,
    }
    (out / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(out)
    print("OpenCity valid monthly station periods:", len(open_city))
    print("Zindi valid monthly station periods:", len(train))


if __name__ == "__main__":
    main()
