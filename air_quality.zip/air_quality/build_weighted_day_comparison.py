"""Make four one-day comparison graphs for fixed and weighted submissions.

This is visualization only. Prediction and submission logic is entirely in
train_weighted_recent_days.py.
"""

from __future__ import annotations

import argparse
import html
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input"
DAY = "2026-11-11"
TOP = 100.0  # Shared Y axis keeps all four station profiles comparable.


def only(folder: Path, glob: str) -> Path:
    found = list(folder.glob(glob))
    if len(found) != 1:
        raise ValueError(f"Expected one {glob} in {folder}")
    return found[0]


def station_chart(name: str, block: pd.DataFrame, difference_scale: float) -> str:
    width, height = 1170, 305
    left, right = 58, 25
    top, main_bottom = 20, 198
    delta_top, delta_bottom = 226, 280
    plot_width = width - left - right
    x = lambda hour: left + plot_width * (hour + 0.5) / 24
    y = lambda value: main_bottom - min(max(value, 0), TOP) / TOP * (main_bottom - top)
    delta_mid = (delta_top + delta_bottom) / 2
    delta_y = lambda value: delta_mid - value / difference_scale * (delta_bottom - delta_top) / 2
    pieces = [f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{html.escape(name)} fixed and weighted hourly PM2.5 predictions and their difference">']
    for value in (0, 25, 50, 75, 100):
        yy = y(value)
        pieces.append(f'<line class="grid" x1="{left}" x2="{width-right}" y1="{yy:.1f}" y2="{yy:.1f}"/>')
        pieces.append(f'<text class="axis-label" x="{left-8}" y="{yy+4:.1f}" text-anchor="end">{value}</text>')
    pieces.append(f'<text class="axis-title" x="{left}" y="13">PM2.5 (µg/m³)</text>')
    base_points, new_points = [], []
    for row in block.itertuples(index=False):
        xx = x(row.hour)
        base_points.append(f'{xx:.1f},{y(row.fixed_hourly_median_pm25):.1f}')
        new_points.append(f'{xx:.1f},{y(row.weighted_prediction_pm25):.1f}')
        pieces.append(f'<line class="tick" x1="{xx:.1f}" x2="{xx:.1f}" y1="{main_bottom}" y2="{main_bottom+4}"/>')
        pieces.append(f'<text class="hour" x="{xx:.1f}" y="{height-8}" text-anchor="middle">{row.hour:02d}</text>')
        bar_top, bar_bottom = sorted((delta_mid, delta_y(row.difference_pm25)))
        bar_height = max(bar_bottom - bar_top, 0.8)
        bar_class = "positive" if row.difference_pm25 >= 0 else "negative"
        pieces.append(f'<rect class="{bar_class}" x="{xx-11:.1f}" y="{bar_top:.1f}" width="22" height="{bar_height:.1f}"><title>{row.hour:02d}:00 IST · first {row.fixed_hourly_median_pm25:.2f} · weighted {row.weighted_prediction_pm25:.2f} · difference {row.difference_pm25:+.2f} µg/m³</title></rect>')
    pieces.append(f'<polyline class="base-line" points="{" ".join(base_points)}"/>')
    pieces.append(f'<polyline class="weighted-line" points="{" ".join(new_points)}"/>')
    for row in block.itertuples(index=False):
        xx = x(row.hour)
        for value, css, label in ((row.fixed_hourly_median_pm25, "base-dot", "Fixed hourly median"),
                                  (row.weighted_prediction_pm25, "weighted-dot", "Weighted average")):
            pieces.append(f'<circle class="{css}" cx="{xx:.1f}" cy="{y(value):.1f}" r="3"><title>{row.hour:02d}:00 IST · {label}: {value:.2f} µg/m³</title></circle>')
    pieces.append(f'<line class="delta-zero" x1="{left}" x2="{width-right}" y1="{delta_mid:.1f}" y2="{delta_mid:.1f}"/>')
    pieces.append(f'<text class="axis-title" x="{left}" y="{delta_top-5}">Weighted − fixed (µg/m³)</text>')
    pieces.append(f'<text class="axis-label" x="{left-7}" y="{delta_top+3}" text-anchor="end">+{difference_scale:g}</text>')
    pieces.append(f'<text class="axis-label" x="{left-7}" y="{delta_mid+4:.1f}" text-anchor="end">0</text>')
    pieces.append(f'<text class="axis-label" x="{left-7}" y="{delta_bottom+4}" text-anchor="end">−{difference_scale:g}</text>')
    pieces.append('</svg>')
    mean_difference = float(block.difference_pm25.mean())
    return (f'<section class="panel"><div class="panel-heading"><h2>{html.escape(name)}</h2>'
            f'<span>Mean change {mean_difference:+.2f} µg/m³ · range '
            f'{block.difference_pm25.min():+.2f} to {block.difference_pm25.max():+.2f}</span></div>'
            + "".join(pieces) + '</section>')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-run", type=Path, required=True)
    parser.add_argument("--weighted-run", type=Path, required=True)
    args = parser.parse_args()
    base_run, weighted_run = args.base_run.resolve(), args.weighted_run.resolve()
    stamp = weighted_run.name.removeprefix("weighted_recent_days_")
    base = pd.read_csv(only(base_run, "submission_*.csv")).rename(columns={"Target": "fixed_hourly_median_pm25"})
    weighted = pd.read_csv(only(weighted_run, "submission_*.csv")).rename(columns={"Target": "weighted_prediction_pm25"})
    test = pd.read_csv(max(INPUT.glob("Test*.csv"), key=lambda p: p.stat().st_mtime_ns))
    stations = pd.read_csv(max(INPUT.glob("Stations*.csv"), key=lambda p: p.stat().st_mtime_ns))[["location_id", "station_name"]]
    test["day"] = test.target_start_ist.str.slice(0, 10)
    test["hour"] = test.target_start_ist.str.slice(11, 13).astype(int)
    day = test.loc[test.day == DAY, ["ID", "location_id", "hour", "target_start_ist"]]
    joined = day.merge(base, on="ID", validate="one_to_one").merge(weighted, on="ID", validate="one_to_one")
    joined = joined.merge(stations, on="location_id", validate="many_to_one").sort_values(["location_id", "hour"])
    joined["difference_pm25"] = joined.weighted_prediction_pm25 - joined.fixed_hourly_median_pm25
    assert len(joined) == 4 * 24 and joined.groupby("location_id").hour.nunique().eq(24).all()
    # Confirm the source CSV and the one-day plotted values are the same predictions.
    profile = pd.read_csv(only(weighted_run, "hourly_profile_comparison_*.csv"))
    check = joined.merge(profile[["location_id", "hour", "weighted_prediction_pm25"]],
                         on=["location_id", "hour"], suffixes=("", "_profile"), validate="one_to_one")
    assert np.allclose(check.weighted_prediction_pm25, check.weighted_prediction_pm25_profile, atol=1e-6)
    csv_file = weighted_run / f"one_day_prediction_difference_{DAY.replace('-', '')}_{stamp}.csv"
    joined[["ID", "location_id", "station_name", "hour", "target_start_ist",
            "fixed_hourly_median_pm25", "weighted_prediction_pm25", "difference_pm25"]].to_csv(
        csv_file, index=False, float_format="%.6f")
    scale = max(5.0, float(np.ceil(joined.difference_pm25.abs().max() / 5) * 5))
    charts = "".join(station_chart(name, block.sort_values("hour"), scale)
                     for name, block in joined.groupby("station_name", sort=True))
    metrics = json.loads(only(weighted_run, "metrics_*.json").read_text())
    base_metrics = json.loads(only(base_run, "metrics_*.json").read_text())
    effective = metrics["effective_weight_on_source_day_by_station"]
    weight_note = ", ".join(f'{day[-2:]} Nov: {weight:.0%}' for day, weight in
                            sorted(next(iter(effective.values())).items(), reverse=True))
    base_rmse = base_metrics["validation"]["pooled_rmse"]
    weighted_rmse = metrics["validation"]["weighted_pooled_rmse"]
    page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Weighted recent days vs fixed hourly median · {DAY}</title>
<style>:root{{--ink:#172338;--muted:#56657a;--bg:#f3f6fa;--line:#dce5ee;--blue:#2563d8;--green:#078573;--red:#c95646}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}}main{{max-width:1260px;margin:auto;padding:25px 20px 55px}}h1{{font-size:27px;margin:0 0 5px}}h2{{font-size:17px;margin:0}}p{{margin:0 0 10px}}.muted{{color:var(--muted)}}.note{{background:#eaf4f2;border-left:4px solid var(--green);padding:12px 15px;border-radius:7px;margin:17px 0}}.panel{{background:white;border:1px solid var(--line);border-radius:11px;padding:17px 18px;margin:15px 0;box-shadow:0 1px 3px #1b334408}}.panel-heading{{display:flex;align-items:baseline;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:5px}}.panel-heading span{{color:var(--muted);font-size:13px}}svg{{display:block;width:100%;height:auto}}svg text{{font:11px system-ui,sans-serif;fill:var(--muted)}}svg .axis-title{{font-weight:600;fill:#384c61}}svg .grid{{stroke:#e4ebf2;stroke-width:1}}svg .tick{{stroke:#b2c2d0}}svg .base-line{{fill:none;stroke:var(--blue);stroke-width:2.5}}svg .weighted-line{{fill:none;stroke:var(--green);stroke-width:2.8}}svg .base-dot{{fill:var(--blue)}}svg .weighted-dot{{fill:var(--green)}}svg .positive{{fill:#78bea8}}svg .negative{{fill:#e8a398}}svg .delta-zero{{stroke:#8093a6;stroke-width:1}}.legend{{display:flex;gap:20px;flex-wrap:wrap;color:var(--muted);font-size:13px;margin:13px 0}}.swatch{{display:inline-block;width:19px;height:3px;vertical-align:middle;margin-right:5px}}.small{{font-size:12px;color:var(--muted)}}@media(max-width:700px){{main{{padding:14px 10px}}.panel{{padding:10px}}}}</style></head><body><main>
<h1>Weighted average vs fixed hourly median</h1><p class="muted">24 target hours on 11 November 2026 · repeated unchanged on every prediction day · µg/m³ · IST</p>
<div class="note"><strong>What the weights actually mean with current data:</strong> You requested 40% November 8, 30% November 7, and 30% split equally across November 6, 5, and 4. No November 7 or 8 station readings are present. With the agreed carry-forward from November 6, the effective weights are <strong>{html.escape(weight_note)}</strong>. Any missing hour within a source day uses that station's seven-day median at the same hour. November 9 is excluded.</div>
<div class="legend"><span><i class="swatch" style="background:var(--blue)"></i>Fixed hourly median</span><span><i class="swatch" style="background:var(--green)"></i>Weighted recent days</span><span><i class="swatch" style="background:#78bea8"></i>Difference: weighted − fixed</span></div>
{charts}
<div class="panel"><h2>Validation and interpretation</h2><p>Retrospective two-day-gap RMSE: fixed hourly median <strong>{base_rmse:.2f}</strong>, weighted recent days <strong>{weighted_rmse:.2f}</strong> µg/m³ over 897 observed station-hours. Lower is better. This weighted version is more responsive to the high November 6 readings, but it did not improve pooled historical accuracy.</p><p class="small">All four charts use the same 0–100 PM2.5 axis and the same ±{scale:g} difference axis. Hover over a point or difference bar for exact values. The companion CSV contains all 96 plotted station-hours. Historical first-publication times are unverified, so backtest accuracy is indicative only.</p></div>
</main></body></html>'''
    html_file = weighted_run / f"four_station_one_day_difference_{DAY.replace('-', '')}_{stamp}.html"
    html_file.write_text(page, encoding="utf-8")
    shutil.copy2(__file__, weighted_run / f"build_weighted_day_comparison_code_{stamp}.py")
    print(html_file)
    print(csv_file)
    print(f"Four graphs; 96 station-hours; shared Y axis 0–{TOP:g}; difference axis ±{scale:g}")


if __name__ == "__main__":
    main()
