"""Basic statistical PM2.5 forecast: station/hour location from clean history.

Run: python3.11 air_quality/train_basic_30day_station_hour.py
This file alone validates, fits, predicts, and writes the timestamped submission.
"""

from __future__ import annotations

import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT, OUTPUT = ROOT / "input", ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
CUTOFF = pd.Timestamp("2026-11-08", tz=IST)
MAX_HISTORY_DAYS = 30
FOLD_STARTS = ("2026-10-17", "2026-10-22", "2026-10-27",
               "2026-11-01", "2026-11-03", "2026-11-05")
SELECTION_FOLDS = ("2026-10-27", "2026-11-01", "2026-11-03")
HOLDOUT_FOLD = "2026-11-05"
CANDIDATES = tuple((days, method) for days in (7, 14, 21, 30)
                   for method in ("mean", "median"))


def newest(prefix: str) -> Path:
    files = list(INPUT.glob(f"{prefix}*.csv"))
    if not files:
        raise FileNotFoundError(f"Missing {prefix} CSV")
    return max(files, key=lambda p: (p.stat().st_mtime_ns, p.name))


def load() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    train_path = newest("Train")
    train = pd.read_csv(train_path)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    train["available_at"] = pd.to_datetime(train.available_at, utc=True, format="mixed").dt.tz_convert(IST)
    train = train.loc[train.pm25.notna() & np.isfinite(train.pm25) & (train.pm25 >= 0) &
                      ~train.flag_high_1000.astype(bool)].copy()
    train["hour_start"] = train.timestamp_ist - pd.Timedelta(hours=1)
    train["hour"] = train.hour_start.dt.hour
    assert not train.duplicated(["location_id", "hour_start"]).any()
    test = pd.read_csv(newest("Test"))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["hour"] = test.target_start_ist.dt.hour
    sample = pd.read_csv(newest("SampleSubmission"))
    assert test.ID.is_unique and sample.ID.is_unique and set(test.ID) == set(sample.ID)
    return train, test, sample, train_path


def history(train: pd.DataFrame, cutoff: pd.Timestamp, days: int,
            as_of: pd.Timestamp | None = None) -> pd.DataFrame:
    keep = ((train.hour_start >= cutoff - pd.Timedelta(days=days)) &
            (train.hour_start < cutoff))
    if as_of is not None:
        keep &= train.available_at <= as_of
    return train.loc[keep].copy()


def fit(data: pd.DataFrame, method: str) -> pd.DataFrame:
    if method not in ("mean", "median"):
        raise ValueError(method)
    by_hour = data.groupby(["location_id", "hour"]).pm25.agg(["size", method]).rename(
        columns={"size": "training_rows", method: "prediction_pm25"}).reset_index()
    stations = sorted(data.location_id.unique())
    if len(stations) != 4:
        raise ValueError(f"Expected four stations, got {len(stations)}")
    all_hours = pd.MultiIndex.from_product([stations, range(24)],
                                           names=["location_id", "hour"]).to_frame(index=False)
    profile = all_hours.merge(by_hour, on=["location_id", "hour"], how="left", validate="one_to_one")
    fallback = data.groupby("location_id").pm25.agg(method)
    profile["prediction_pm25"] = profile.prediction_pm25.fillna(profile.location_id.map(fallback))
    profile["training_rows"] = profile.training_rows.fillna(0).astype(int)
    assert len(profile) == 96 and profile.prediction_pm25.notna().all()
    return profile


def predict(rows: pd.DataFrame, profile: pd.DataFrame) -> np.ndarray:
    mapped = rows[["location_id", "hour"]].merge(
        profile[["location_id", "hour", "prediction_pm25"]],
        on=["location_id", "hour"], how="left", sort=False, validate="many_to_one")
    result = mapped.prediction_pm25.to_numpy(dtype=float)
    if len(result) != len(rows) or not np.isfinite(result).all():
        raise ValueError("Missing forecast")
    return result


def score(y: np.ndarray, pred: np.ndarray) -> dict:
    error = pred - y
    return {"rows": int(len(y)), "rmse": float(np.sqrt(np.mean(error ** 2))),
            "mae": float(np.mean(np.abs(error))), "bias_prediction_minus_actual": float(error.mean())}


def validate(train: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    parts = []
    fold_info = []
    for day in FOLD_STARTS:
        start = pd.Timestamp(day, tz=IST)
        cutoff = start - pd.Timedelta(days=3)
        # Simulate the final situation: fit before the excluded three days,
        # and use only observations published by the evening before scoring.
        as_of = start - pd.Timedelta(seconds=1)
        valid = train.loc[(train.hour_start >= start) &
                          (train.hour_start < start + pd.Timedelta(days=2))]
        fold = pd.DataFrame({"fold": day, "location_id": valid.location_id.to_numpy(),
                             "hour_start": valid.hour_start.to_numpy(),
                             "actual_pm25": valid.pm25.to_numpy()})
        for days, method in CANDIDATES:
            past = history(train, cutoff, days, as_of)
            model = fit(past, method)
            fold[f"{method}_{days}d"] = predict(valid, model)
        parts.append(fold)
        fold_info.append({"fold": day, "cutoff": str(cutoff), "as_of": str(as_of),
                          "scored_rows": len(valid),
                          "30d_training_rows": len(history(train, cutoff, 30, as_of))})
    combined = pd.concat(parts, ignore_index=True)
    candidates = [f"{method}_{days}d" for days, method in CANDIDATES]
    selection = combined.loc[combined.fold.isin(SELECTION_FOLDS)]
    full = pd.DataFrame([{"candidate": name, **score(combined.actual_pm25.to_numpy(),
                                                     combined[name].to_numpy())}
                         for name in candidates]).sort_values(["rmse", "mae"])
    recent = pd.DataFrame([{"candidate": name, **score(selection.actual_pm25.to_numpy(),
                                                       selection[name].to_numpy())}
                           for name in candidates]).sort_values(["rmse", "mae"])
    return combined, full, recent, pd.DataFrame(fold_info)


def main() -> None:
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = OUTPUT / f"basic_30day_station_hour_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_basic_30day_station_hour_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("basic_30day_station_hour")
    train, test, sample, train_path = load()
    validation, full_scores, selection_scores, folds = validate(train)
    winner = str(selection_scores.iloc[0].candidate)
    method, days_text = winner.split("_")
    days = int(days_text.removesuffix("d"))
    if days > MAX_HISTORY_DAYS:
        raise AssertionError("History window exceeded 30 days")
    past = history(train, CUTOFF, days)
    model = fit(past, method)
    test_pred = predict(test, model)
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(pd.Series(test_pred, index=test.ID))
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    assert (submission.Target >= 0).all()
    submission_path = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_path, index=False, float_format="%.6f")
    assert pd.read_csv(submission_path).ID.tolist() == sample.ID.tolist()

    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    model.merge(stations, on="location_id", validate="many_to_one").to_csv(
        run_dir / f"station_hour_profile_{stamp}.csv", index=False, float_format="%.6f")
    past.assign(day=past.hour_start.dt.strftime("%Y-%m-%d")).groupby(
        ["location_id", "day"]).pm25.agg(["size", "mean", "median"]).reset_index().to_csv(
        run_dir / f"training_days_{stamp}.csv", index=False, float_format="%.6f")
    validation.to_csv(run_dir / f"validation_predictions_{stamp}.csv", index=False, float_format="%.6f")
    full_scores.to_csv(run_dir / f"validation_all_folds_{stamp}.csv", index=False, float_format="%.6f")
    selection_scores.to_csv(run_dir / f"validation_selection_{stamp}.csv", index=False, float_format="%.6f")
    folds.to_csv(run_dir / f"validation_folds_{stamp}.csv", index=False)
    holdout = validation.loc[validation.fold == HOLDOUT_FOLD]
    metrics = {"run_timestamp_ist": stamp, "method": "one stationary station-by-hour statistic, no trend or learned residual correction",
               "train_file": train_path.name, "training_window_start_ist": str(CUTOFF - pd.Timedelta(days=days)),
               "training_window_end_exclusive_ist": str(CUTOFF),
               "excluded_diwali_and_after": "2026-11-08 onward", "selected_candidate": winner,
               "training_rows": len(past), "station_hour_profiles": len(model),
               "missing_station_hours_using_station_fallback": int((model.training_rows == 0).sum()),
               "selection_folds": list(SELECTION_FOLDS),
               "selection_score": selection_scores.iloc[0].to_dict(),
               "full_period_score": full_scores.loc[full_scores.candidate == winner].iloc[0].to_dict(),
               "nov5_holdout": score(holdout.actual_pm25.to_numpy(), holdout[winner].to_numpy()),
               "nov5_7d_median": score(holdout.actual_pm25.to_numpy(), holdout.median_7d.to_numpy()),
               "validation_note": "Every fold has a three-day pre-target history cutoff and respects available_at. Window and statistic selected on three recent folds; November 5 is untouched holdout. Earlier rising-regime folds are reported separately.",
               "submission_rows": len(submission), "prediction_min": float(submission.Target.min()),
               "prediction_max": float(submission.Target.max()),
               "input_note": "Only Train, Test, SampleSubmission, and Stations CSVs read; no last_days_data used."}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Selected %s from %d candidates; training rows %d; window %s to %s", winner,
             len(CANDIDATES), len(past), metrics["training_window_start_ist"], CUTOFF)
    log.info("Selection RMSE %.3f; untouched Nov5 RMSE %.3f; full-period RMSE %.3f",
             metrics["selection_score"]["rmse"], metrics["nov5_holdout"]["rmse"],
             metrics["full_period_score"]["rmse"])
    log.info("Submission %s; %d rows", submission_path, len(submission))
    print(run_dir)


if __name__ == "__main__":
    main()
