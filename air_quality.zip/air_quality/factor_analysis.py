"""Describe Mumbai PM2.5 station, hour, seasonal, and recent trends.

Run: MPLCONFIGDIR=/private/tmp/mumbai-mpl python3.11 air_quality/factor_analysis.py
The script writes a timestamped report, data tables, figures, and an exact code copy.
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
IST = ZoneInfo("Asia/Kolkata")
STAMP = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
OUT = ROOT / "output" / f"factors_{STAMP}"
OUT.mkdir(parents=True, exist_ok=False)
shutil.copy2(__file__, OUT / f"factor_analysis_code_{STAMP}.py")

train_path, = (ROOT / "input").glob("Train*.csv")
raw = pd.read_csv(train_path)
raw["time"] = pd.to_datetime(raw.timestamp_ist, utc=True).dt.tz_convert(IST)
data = raw.loc[~raw.flag_high_1000.astype(bool)].copy()
data["day"] = data.time.dt.floor("D")
data["hour"] = data.time.dt.hour
data["month"] = data.time.dt.strftime("%Y-%m")
names = {11606: "Borivali East", 11611: "Malad West",
         3409510: "Byculla", 3409511: "Shivaji Nagar"}
data["station"] = data.location_id.map(names)


def period(start: str, end: str) -> pd.DataFrame:
    return data.loc[(data.time >= pd.Timestamp(start, tz=IST)) &
                    (data.time < pd.Timestamp(end, tz=IST))].copy()


periods = {
    "Sep 2026": ("2026-09-01", "2026-10-01"),
    "Oct 1–15": ("2026-10-01", "2026-10-16"),
    "Oct 17–23": ("2026-10-17", "2026-10-24"),
    "Oct 27–Nov 2": ("2026-10-27", "2026-11-03"),
    "Oct 30–Nov 2": ("2026-10-30", "2026-11-03"),
}

station_rows = []
for label, (start, end) in periods.items():
    frame = period(start, end)
    for station, group in frame.groupby("station"):
        station_rows.append({"period": label, "station": station,
                             "rows": len(group), "mean": group.pm25.mean(),
                             "median": group.pm25.median(),
                             "p90": group.pm25.quantile(.9)})
station_table = pd.DataFrame(station_rows)
station_table.to_csv(OUT / f"station_periods_{STAMP}.csv", index=False)

# Station-day demeaning removes each day's overall level before comparing hours.
hour_rows = []
for label in ("Sep 2026", "Oct 1–15", "Oct 17–23", "Oct 27–Nov 2"):
    frame = period(*periods[label])
    frame["hour_offset"] = frame.pm25 - frame.groupby(["station", "day"]).pm25.transform("mean")
    for (station, hour), group in frame.groupby(["station", "hour"]):
        hour_rows.append({"period": label, "station": station, "hour": hour,
                          "n": len(group), "mean_pm25": group.pm25.mean(),
                          "mean_hour_offset": group.hour_offset.mean()})
hour_table = pd.DataFrame(hour_rows)
hour_table.to_csv(OUT / f"hourly_profiles_{STAMP}.csv", index=False)

daily = data.loc[data.day >= pd.Timestamp("2026-10-01", tz=IST)].groupby(
    ["day", "station"], as_index=False).agg(rows=("pm25", "size"), mean=("pm25", "mean"),
                                            median=("pm25", "median"))
daily["day"] = daily.day.dt.strftime("%Y-%m-%d")
daily.to_csv(OUT / f"daily_station_{STAMP}.csv", index=False)
city = daily.groupby("day").agg(stations=("station", "nunique"),
                                station_balanced_mean=("mean", "mean"),
                                observed_rows=("rows", "sum")).reset_index()
city.to_csv(OUT / f"daily_city_{STAMP}.csv", index=False)

monthly = data.groupby("month").agg(rows=("pm25", "size"), mean=("pm25", "mean"),
                                    median=("pm25", "median")).reset_index()
monthly.to_csv(OUT / f"monthly_{STAMP}.csv", index=False)

# The two comparison windows have different hour coverage. Restrict both to
# 02:00–23:00, which are present throughout the latest observed week.
matched = {}
for label in ("Oct 17–23", "Oct 27–Nov 2", "Oct 30–Nov 2"):
    frame = period(*periods[label])
    frame = frame.loc[frame.hour >= 2]
    matched[label] = (len(frame), float(frame.pm25.mean()))

latest = data.time.max()
window_rows = []
for days in (30, 60, 90, 180, 365):
    group = data.loc[data.time > latest - pd.Timedelta(days=days)]
    window_rows.append({"days": days, "rows": len(group),
                        "min_station_rows": int(group.groupby("station").size().min())})
window_table = pd.DataFrame(window_rows)
window_table.to_csv(OUT / f"training_window_counts_{STAMP}.csv", index=False)

fig, ax = plt.subplots(figsize=(11, 5))
for station, group in daily.groupby("station"):
    series = group.set_index(pd.to_datetime(group.day))["mean"]
    series = series.reindex(pd.date_range(series.index.min(), series.index.max(), freq="D"))
    ax.plot(series.index, series, marker=".", linewidth=1.5, label=station)
ax.set(title="Daily PM2.5 by station, October–November 2026", ylabel="PM2.5 (µg/m³)", xlabel="Observation day")
ax.grid(alpha=.25)
ax.legend(ncol=2, fontsize=8)
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(OUT / f"daily_station_trend_{STAMP}.png", dpi=150)
plt.close(fig)

fig, ax = plt.subplots(figsize=(10, 5))
for label in ("Sep 2026", "Oct 17–23", "Oct 27–Nov 2"):
    group = hour_table.loc[hour_table.period == label]
    profile = group.groupby("hour").apply(
        lambda x: np.average(x.mean_hour_offset, weights=x.n), include_groups=False)
    ax.plot(profile.index, profile.values, marker="o", markersize=3, label=label)
ax.axhline(0, color="black", linewidth=.8)
ax.set(title="Hour-of-day effect after removing each station's daily mean",
       xlabel="Hour ending (IST)", ylabel="Difference from station-day mean (µg/m³)",
       xticks=range(0, 24, 2))
ax.grid(alpha=.25)
ax.legend()
fig.tight_layout()
fig.savefig(OUT / f"hourly_effect_{STAMP}.png", dpi=150)
plt.close(fig)

def md_table(frame: pd.DataFrame, decimals: int = 1) -> str:
    formatted = frame.round(decimals).astype(str)
    columns = list(formatted.columns)
    lines = ["| " + " | ".join(columns) + " |",
             "| " + " | ".join("---" for _ in columns) + " |"]
    lines.extend("| " + " | ".join(row) + " |" for row in formatted.itertuples(index=False, name=None))
    return "\n".join(lines)


last_daily = city.loc[city.day >= "2026-10-17"].copy()
report = f"""# Mumbai PM2.5 factor and trend analysis

Generated: {datetime.now(IST).isoformat()}. Source: {train_path.name}. Flagged values above 1,000 µg/m³ excluded: {len(raw)-len(data)}.

## What this data can show

Train contains station, observation hour, PM2.5, and source metadata. It has no weather, traffic, emissions, wind, rainfall, or holiday columns. Station and time patterns below are associations; the source of any rise or fall cannot be identified from these columns alone. Every timestamp here is the **end** of an observed hour in IST.

## Seasonal scale

{md_table(monthly.loc[monthly.month.isin(['2025-09','2025-10','2025-11','2026-09','2026-10','2026-11'])])}

November 2026 has only observations through {latest.strftime('%Y-%m-%d %H:%M')} IST and is not a full-month comparison. Both years show a jump from September into October; 2025 rose further in November. This gives a strong seasonal prior but does not determine the next few days.

## Four stations across recent regimes

{md_table(station_table)}

Same-hour comparison (02:00–23:00): Oct 17–23 mean {matched['Oct 17–23'][1]:.2f} on {matched['Oct 17–23'][0]} observations; Oct 27–Nov 2 mean {matched['Oct 27–Nov 2'][1]:.2f} on {matched['Oct 27–Nov 2'][0]}; Oct 30–Nov 2 mean {matched['Oct 30–Nov 2'][1]:.2f} on {matched['Oct 30–Nov 2'][0]}. This is a sharp decline followed by a short, roughly level period. It does not establish a continued decline into the private target dates.

## Daily level and coverage

{md_table(last_daily)}

The current seven-day segment has {matched['Oct 27–Nov 2'][0]} observed station-hours from 02:00–23:00 out of {7*22*4} possible (90%). Hours 00:00–01:00 have no observations in this segment; do not estimate their recent hourly effect from this week. Station-balanced daily means reduce changes due to a missing station, though gaps within a station-day still matter.

## Hour of day

The CSV `hourly_profiles_{STAMP}.csv` has every station, hour and period. Mean hour offsets subtract each station-day mean, reducing confusion from shifting daily levels. The plotted hour is the observation **end hour**. For Oct 27–Nov 2, the pooled peak is near 09:00–10:00 and the trough near 16:00–19:00 IST; the recent profile has no 00:00–01:00 observations. This pattern varies by station and period, so an hour feature should interact with station and season.

## How much labeled history exists

{md_table(window_table, 0)}

The latest observed target ends at {latest}. The full clean dataset has {len(data):,} station-hours. History should be compared with forecast-origin backtests; row count alone cannot decide the best training span.

![Daily station trend](daily_station_trend_{STAMP}.png)

![Hourly effect](hourly_effect_{STAMP}.png)
"""
(OUT / f"factor_report_{STAMP}.md").write_text(report)
print(f"Report: {OUT / f'factor_report_{STAMP}.md'}")
print(f"Same-hour mean: Oct 17–23 {matched['Oct 17–23'][1]:.2f}; Oct 27–Nov 2 {matched['Oct 27–Nov 2'][1]:.2f}; Oct 30–Nov 2 {matched['Oct 30–Nov 2'][1]:.2f}")
