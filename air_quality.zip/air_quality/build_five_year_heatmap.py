"""Build an offline, source-labeled five-year PM2.5 heatmap.

Run after analyze_five_year_pm25.py:
python3 air_quality/build_five_year_heatmap.py
"""

import csv
import json
import shutil
from pathlib import Path


root = Path(__file__).resolve().parent
output = sorted((root / "output").glob("five_year_pm25_*/monthly_pm25_2022_2026.csv"))[-1]
with output.open(newline="") as stream:
    records = list(csv.DictReader(stream))
target = output.parent / "five_year_pm25_heatmap.html"
shutil.copy2(__file__, output.parent / "build_five_year_heatmap_code.py")

html = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mumbai PM2.5, 2022–2026</title><style>
*{box-sizing:border-box}body{margin:0;background:#f6f8f7;color:#173027;font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.wrap{max-width:1180px;margin:auto;padding:26px}h1{font-size:clamp(24px,3vw,36px);margin:0 0 4px}p{color:#5b7067;margin:5px 0}.panel{background:white;border:1px solid #dce6df;border-radius:16px;margin-top:20px;padding:22px;box-shadow:0 8px 32px #183c2c0b}.controls{display:flex;gap:18px;flex-wrap:wrap}.controls label{display:grid;gap:5px;color:#5b7067;font-size:12px;font-weight:650}select{font:inherit;color:#173027;border:1px solid #c7d6cb;border-radius:8px;background:white;padding:9px 12px;min-height:42px}.scroll{overflow-x:auto;margin-top:20px}.matrix{display:grid;grid-template-columns:62px repeat(12,minmax(70px,1fr));gap:5px;min-width:900px}.head{text-align:center;color:#5b7067;font-size:12px;font-weight:650;padding:8px 0}.year{font-weight:700;padding:16px 5px}.cell{border-radius:7px;min-height:56px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px}.cell.sparse{outline:2px dashed #ad5d41;outline-offset:-4px}.cell.empty{background:#f0f3f1;color:#a4b1aa;font-weight:400}.legend{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:18px;color:#5b7067;font-size:12px}.gradient{width:190px;height:12px;border-radius:8px;background:linear-gradient(90deg,#e5f1eb,#9acdb9,#409b83,#175b71,#473a87)}.note{font-size:13px;margin-top:14px}.chart{width:100%;height:auto;display:block;max-height:380px}.chartTitle{font-size:18px;margin:26px 0 8px}.yearLegend{display:flex;gap:16px;flex-wrap:wrap;margin-top:5px}.yearLegend span{font-size:13px;font-weight:650}.yearLegend i{display:inline-block;width:13px;height:13px;border-radius:50%;vertical-align:-2px;margin-right:5px}.plotNote{font-size:12px}a{color:#086e58}@media(max-width:600px){.wrap{padding:14px}.panel{padding:14px}}
</style></head><body><main class="wrap"><h1>Mumbai PM2.5 · 2022–2026</h1><p>Monthly concentration (µg/m³). Select a monitor to see the seasonal rise and missing periods.</p><section class="panel"><div class="controls"><label>Monitor<select id="series"><option>US Diplomatic Post: Mumbai</option><option>Borivali East</option><option>Malad West</option><option>Byculla</option><option>Shivaji Nagar</option></select></label><label>Statistic<select id="stat"><option value="mean_pm25_ug_m3">Monthly mean</option><option value="median_pm25_ug_m3">Monthly median</option></select></label></div><div class="scroll"><div class="matrix" id="matrix" role="img" aria-label="Mumbai monthly PM2.5 heatmap"></div></div><div class="legend"><span>0</span><span class="gradient"></span><span>100+ µg/m³</span><span>Dashed border: below 75% hourly coverage</span><span>Grey: no data</span></div><p class="note" id="note"></p><h2 class="chartTitle">September to November, by year</h2><svg id="seasonPlot" class="chart" viewBox="0 0 760 320" role="img" aria-label="Monthly PM2.5 for September, October and November across years"></svg><div class="yearLegend" id="yearLegend"></div><p class="plotNote">Open circles and dashed segments mark months with under 75% coverage. November 2026 is a partial month; hover a point for its value and coverage. The y-axis stays fixed at 0–140 µg/m³.</p><p class="note">The AirNow monitor is separate from the four CPCB stations. For those four stations, 2024–February 2025 uses OpenCity CPCB data; March 2025 onward uses Zindi competition training data. Source and coverage appear when you hover over a month.</p><p class="note">Sources: <a href="https://data.opencity.in/dataset/mumbai-hourly-air-quality-reports">OpenCity / CPCB</a>, <a href="https://docs.openaq.org/aws/year-guide">OpenAQ / AirNow</a>, <a href="https://zindi.world/competitions/google-mumbai-data-challenge/data">Zindi competition</a>.</p></section></main><script type="application/json" id="data">__DATA__</script><script>
const rows=JSON.parse(document.getElementById('data').textContent),lookup=new Map(rows.map(r=>[r.station_name+'|'+r.month_ist,r]));
const series=document.getElementById('series'),stat=document.getElementById('stat'),matrix=document.getElementById('matrix'),note=document.getElementById('note');
const names=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const plot=document.getElementById('seasonPlot'),yearLegend=document.getElementById('yearLegend');
const yearColors={2022:'#8b5e3c',2023:'#3465ad',2024:'#7b4ca8',2025:'#d66032',2026:'#087a61'};
function svg(tag,attrs,content){let e=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(content!==undefined)e.textContent=content;return e}
function drawSeason(){plot.replaceChildren();yearLegend.replaceChildren();const xs=[100,380,660],y=v=>270-v/140*220;
 for(let tick=0;tick<=140;tick+=20){let yy=y(tick);plot.append(svg('line',{x1:70,y1:yy,x2:700,y2:yy,stroke:'#e0e8e2','stroke-width':1}));plot.append(svg('text',{x:62,y:yy+4,'text-anchor':'end',fill:'#597067','font-size':12},String(tick)))}
 ['Sep','Oct','Nov'].forEach((m,i)=>plot.append(svg('text',{x:xs[i],y:294,'text-anchor':'middle',fill:'#173027','font-size':14,'font-weight':650},m)));
 plot.append(svg('text',{x:14,y:18,fill:'#597067','font-size':12},'PM2.5 µg/m³'));
 for(let year=2022;year<=2026;year++){let points=[9,10,11].map((month,i)=>{let key=year+'-'+String(month).padStart(2,'0'),r=lookup.get(series.value+'|'+key),v=r&&r[stat.value]!==''?Number(r[stat.value]):null;return {r,v,x:xs[i],month:key,sparse:r&&Number(r.coverage_pct)<75}});let valid=points.filter(p=>p.v!==null);if(!valid.length)continue;
  let label=document.createElement('span'),dot=document.createElement('i');dot.style.background=yearColors[year];label.append(dot,document.createTextNode(year));yearLegend.append(label);
  for(let i=0;i<2;i++){let a=points[i],b=points[i+1];if(a.v===null||b.v===null)continue;let line=svg('line',{x1:a.x,y1:y(a.v),x2:b.x,y2:y(b.v),stroke:yearColors[year],'stroke-width':3,'stroke-linecap':'round'});if(a.sparse||b.sparse)line.setAttribute('stroke-dasharray','7 6');plot.append(line)}
  for(const p of valid){let circle=svg('circle',{cx:p.x,cy:y(p.v),r:6,fill:p.sparse?'#fff':yearColors[year],stroke:yearColors[year],'stroke-width':2.5});let title=svg('title',{},`${p.month}: ${p.v.toFixed(1)} µg/m³; ${p.r.coverage_pct}% coverage; ${p.r.source}`);circle.append(title);plot.append(circle)}
 }
}
function color(v){let p=Math.min(1,Math.max(0,v/100)),a=p<.5?[229,241,235]:[64,155,131],b=p<.5?[64,155,131]:[71,58,135],q=p<.5?p*2:(p-.5)*2;return 'rgb('+a.map((x,i)=>Math.round(x+(b[i]-x)*q)).join(',')+')'}
function render(){matrix.replaceChildren();matrix.append(document.createElement('div'));for(const name of names){let e=document.createElement('div');e.className='head';e.textContent=name;matrix.append(e)}let measured=0,sparse=0;
 for(let year=2022;year<=2026;year++){let label=document.createElement('div');label.className='year';label.textContent=year;matrix.append(label);for(let m=1;m<=12;m++){let month=year+'-'+String(m).padStart(2,'0'),r=lookup.get(series.value+'|'+month),v=r&&r[stat.value]!==''?Number(r[stat.value]):null;let cell=document.createElement('div');cell.className='cell'+(v===null?' empty':'')+(v!==null&&Number(r.coverage_pct)<75?' sparse':'');if(v===null){cell.textContent='—';cell.title=month+': no PM2.5 data'}else{cell.textContent=v.toFixed(1);cell.style.background=color(v);cell.style.color=v>=45?'#fff':'#173027';cell.title=month+': '+v.toFixed(3)+' µg/m³; '+r.coverage_pct+'% hourly coverage; '+r.observed_hours+' hours; '+r.source+'; ID '+(r.source_sensor_id||r.source_station_id);measured++;if(Number(r.coverage_pct)<75)sparse++}matrix.append(cell)}}note.textContent=measured+' months with data; '+sparse+' below 75% hourly coverage.';drawSeason()}
series.addEventListener('change',render);stat.addEventListener('change',render);render();
</script></body></html>'''
target.write_text(html.replace("__DATA__", json.dumps(records, separators=(",", ":"))))
print(target)
