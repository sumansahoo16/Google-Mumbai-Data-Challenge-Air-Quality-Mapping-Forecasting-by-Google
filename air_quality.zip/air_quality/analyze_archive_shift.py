"""Compare fresh OpenAQ archive PM2.5 with the same hours in prior days.

Run: python3.11 air_quality/analyze_archive_shift.py
Writes a timestamped report, matched-hour table, and exact code copy.
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
snapshot = sorted((ROOT / "input").glob("openaq_archive_*/archive_hourly_pm25_*.csv"))[-1]
IST = ZoneInfo("Asia/Kolkata")
stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
out = ROOT / "output" / f"source_shift_{stamp}"
out.mkdir(parents=True, exist_ok=False)
shutil.copy2(__file__, out / f"analyze_archive_shift_code_{stamp}.py")

data = pd.read_csv(snapshot)
data = data.loc[data.quality_eligible].copy()
data["time"] = pd.to_datetime(data.hour_end_ist, utc=True).dt.tz_convert(IST)
data["day"] = data.time.dt.strftime("%Y-%m-%d")
data["hour"] = data.time.dt.hour
names = {11606: "Borivali East", 11611: "Malad West",
         3409510: "Byculla", 3409511: "Shivaji Nagar"}

def compare(previous_day: str, recent_day: str) -> pd.DataFrame:
    old = data.loc[data.day == previous_day, ["location_id", "hour", "pm25"]].rename(
        columns={"pm25": "previous_pm25"})
    new = data.loc[data.day == recent_day, ["location_id", "hour", "pm25"]].rename(
        columns={"pm25": "recent_pm25"})
    pair = old.merge(new, on=["location_id", "hour"], validate="one_to_one")
    pair["previous_day"] = previous_day
    pair["recent_day"] = recent_day
    pair["change_pm25"] = pair.recent_pm25 - pair.previous_pm25
    pair["station"] = pair.location_id.map(names)
    return pair


pairs = pd.concat([compare("2026-11-02", "2026-11-03"),
                   compare("2026-11-02", "2026-11-04")], ignore_index=True)
pairs.to_csv(out / f"matched_hours_{stamp}.csv", index=False)
summary = pairs.groupby(["previous_day", "recent_day", "station"], as_index=False).agg(
    matched_hours=("change_pm25", "size"), previous_mean=("previous_pm25", "mean"),
    recent_mean=("recent_pm25", "mean"), mean_change=("change_pm25", "mean"))
summary.to_csv(out / f"station_shift_{stamp}.csv", index=False)
daily = data.groupby(["day", "location_id"], as_index=False).agg(
    observed_hours=("pm25", "size"), mean_pm25=("pm25", "mean"))
daily["station"] = daily.location_id.map(names)
daily = daily.loc[daily.day >= "2026-11-02", ["day", "station", "observed_hours", "mean_pm25"]]

def markdown(frame: pd.DataFrame) -> str:
    display = frame.round(2).astype(str)
    columns = display.columns.tolist()
    return "\n".join(["| " + " | ".join(columns) + " |",
                      "| " + " | ".join("---" for _ in columns) + " |",
                      *("| " + " | ".join(row) + " |" for row in display.itertuples(index=False, name=None))])


city = pairs.groupby("recent_day").agg(matched_hours=("change_pm25", "size"),
                                       previous_mean=("previous_pm25", "mean"),
                                       recent_mean=("recent_pm25", "mean"),
                                       mean_change=("change_pm25", "mean")).reset_index()
report = f"""# OpenAQ source shift, 3–4 November 2026

Generated {datetime.now(IST).isoformat()} from `{snapshot.parent.name}`. This is an exploratory source snapshot, separate from the organizer's Train.csv. It includes values for fixed Test-grid hours and should not be silently merged into model training.

## Published observations

{markdown(daily)}

The 3 November archive has only morning observations and 4 November mostly late-morning through evening observations. Whole-day means are therefore not directly comparable.

## Same-station, same-hour comparisons with 2 November

{markdown(city)}

{markdown(summary)}

On 3 November the matched mean was approximately level overall, with a decline at Borivali and increases at Malad and Byculla. On 4 November the matched mean increased by about 8.25 µg/m³ across 54 matched station-hours, driven mainly by Shivaji Nagar and Byculla. These are partial-day findings; they do not establish the trend through 8 November.
"""
path = out / f"shift_report_{stamp}.md"
path.write_text(report)
print(f"Report: {path}")
print(city.round(2).to_string(index=False))
