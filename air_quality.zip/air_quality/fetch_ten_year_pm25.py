"""Fetch and aggregate Mumbai PM2.5 history for 2017–2026.

The public OpenAQ S3 archive supplies one AirNow monitor (location 8039,
sensor 23320). The competition Train file supplies four separate CPCB target
sensors from 2025 onward. The outputs retain source and sensor identity;
they never splice different monitors into a single series.

Run: python3 air_quality/fetch_ten_year_pm25.py
"""

from __future__ import annotations

import calendar
import csv
import gzip
import io
import json
import shutil
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean, median
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input"
TRAIN = INPUT / "Train (2).csv"
IST = ZoneInfo("Asia/Kolkata")
START_YEAR = 2017
END_YEAR = 2026
LOCATION = "8039"
SENSOR = "23320"
BUCKET = "https://openaq-data-archive.s3.amazonaws.com"
PREFIX = f"records/csv.gz/locationid={LOCATION}"
STATIONS = {
    "12236418": "Borivali East",
    "12236426": "Malad West",
    "12238567": "Byculla",
    "12238576": "Shivaji Nagar",
}


def get(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "MumbaiPM25YearOnYear/1.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                return response.read()
        except Exception:
            if attempt == 3:
                raise
            time.sleep(1.5**attempt)
    raise AssertionError("Unreachable retry exit")


def list_keys(year: int) -> list[str]:
    keys = []
    token = None
    while True:
        query = {"list-type": "2", "prefix": f"{PREFIX}/year={year}/", "max-keys": "1000"}
        if token:
            query["continuation-token"] = token
        root = ET.fromstring(get(f"{BUCKET}/?{urllib.parse.urlencode(query)}"))
        ns = {"s": "http://s3.amazonaws.com/doc/2006-03-01/"}
        keys.extend(item.text for item in root.findall("s:Contents/s:Key", ns))
        token = root.findtext("s:NextContinuationToken", namespaces=ns)
        if not token:
            return keys


def fetch_file(key: str) -> tuple[str, list[tuple[str, float]], int]:
    body = get(f"{BUCKET}/{key}")
    values = []
    excluded = 0
    with gzip.open(io.BytesIO(body), "rt", newline="") as stream:
        for row in csv.DictReader(stream):
            sensor = row.get("sensors_id") or row.get("sensor_id")
            if row["location_id"] != LOCATION or sensor != SENSOR or row["parameter"].lower() != "pm25":
                continue
            value = float(row["value"])
            if not 0 <= value <= 1000:
                excluded += 1
                continue
            timestamp = datetime.fromisoformat(row["datetime"]).astimezone(IST)
            values.append((timestamp.strftime("%Y-%m-%d %H:%M:%S%z"), value))
    return key, values, excluded


def write_csv(path: Path, fieldnames: list[str], records: list[dict]) -> None:
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def main() -> None:
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    out = INPUT / f"mumbai_pm25_ten_year_{stamp}"
    out.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, out / "fetch_ten_year_pm25_code.py")

    yearly_keys = {year: list_keys(year) for year in range(START_YEAR, END_YEAR + 1)}
    keys = [key for year_keys in yearly_keys.values() for key in year_keys]
    print(f"OpenAQ archive files to read: {len(keys)}", flush=True)
    airnow = {}
    excluded = 0
    duplicates = 0
    with ThreadPoolExecutor(max_workers=16) as pool:
        futures = {pool.submit(fetch_file, key): key for key in keys}
        for done, future in enumerate(as_completed(futures), 1):
            key, observations, bad = future.result()
            excluded += bad
            for timestamp, value in observations:
                if timestamp in airnow:
                    if airnow[timestamp] != value:
                        raise ValueError(f"Conflicting duplicate at {timestamp} in {key}")
                    duplicates += 1
                else:
                    airnow[timestamp] = value
            if done % 250 == 0 or done == len(keys):
                print(f"Read {done}/{len(keys)} files", flush=True)

    airnow_hourly = defaultdict(list)
    for timestamp, value in airnow.items():
        observed_at = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S%z")
        hour_end = observed_at.replace(minute=0, second=0)
        if observed_at.minute or observed_at.second:
            hour_end += timedelta(hours=1)
        airnow_hourly[hour_end].append(value)
    series = defaultdict(list)
    for hour_end, values in airnow_hourly.items():
        series[(hour_end.strftime("%Y-%m"), "openaq_airnow_8039_23320")].append(mean(values))
    train_rows = 0
    train_excluded = 0
    with TRAIN.open(newline="") as stream:
        for row in csv.DictReader(stream):
            sensor = row["sensor_id"]
            if sensor not in STATIONS:
                continue
            value = float(row["pm25"])
            if row["flag_high_1000"].lower() == "true" or not 0 <= value <= 1000:
                train_excluded += 1
                continue
            series[(row["timestamp_ist"][:7], f"zindi_cpcb_{sensor}")].append(value)
            train_rows += 1

    records = []
    series_ids = ["openaq_airnow_8039_23320"] + [f"zindi_cpcb_{x}" for x in STATIONS]
    for year in range(START_YEAR, END_YEAR + 1):
        for month_number in range(1, 13):
            month = f"{year}-{month_number:02d}"
            calendar_hours = calendar.monthrange(year, month_number)[1] * 24
            for series_id in series_ids:
                values = series.get((month, series_id), [])
                sensor = series_id.rsplit("_", 1)[-1]
                records.append({
                    "month_ist": month,
                    "series_id": series_id,
                    "station_name": "US Diplomatic Post: Mumbai" if sensor == SENSOR else STATIONS[sensor],
                    "source": "OpenAQ archive / AirNow" if sensor == SENSOR else "Zindi Train / CPCB",
                    "sensor_id": sensor,
                    "mean_pm25_ug_m3": round(mean(values), 3) if values else "",
                    "median_pm25_ug_m3": round(median(values), 3) if values else "",
                    "observed_hours": len(values),
                    "calendar_hours": calendar_hours,
                    "coverage_pct": round(100 * len(values) / calendar_hours, 1),
                    "coverage_status": "no data" if not values else "sparse (<75%)" if len(values) / calendar_hours < 0.75 else "at least 75%",
                })

    csv_path = out / "monthly_pm25_2017_2026.csv"
    write_csv(csv_path, list(records[0]), records)
    manifest = {
        "created_at_ist": datetime.now(IST).isoformat(),
        "period": "2017-01 to 2026-12 calendar grid; no observations beyond source publication date",
        "sources": [
            {"name": "OpenAQ public archive; upstream AirNow", "url": f"{BUCKET}/{PREFIX}/",
             "location_id": LOCATION, "sensor_id": SENSOR, "station": "US Diplomatic Post: Mumbai",
             "archive_files_by_year": {str(year): len(yearly_keys[year]) for year in yearly_keys},
             "valid_readings": len(airnow), "valid_hourly_values": len(airnow_hourly),
             "excluded_out_of_range": excluded,
             "duplicate_identical_readings": duplicates},
            {"name": "Zindi Google Mumbai Data Challenge Train.csv; upstream CPCB",
             "url": "https://zindi.world/competitions/google-mumbai-data-challenge/data",
             "local_file": str(TRAIN), "sensors": STATIONS,
             "valid_readings": train_rows, "excluded_flagged_or_out_of_range": train_excluded},
        ],
        "method": "Mean and median of valid hourly PM2.5 readings in each IST calendar month. "
                  "OpenAQ AirNow readings within the same ending hour are averaged first. "
                  "AirNow and CPCB series are kept separate. Empty months are blank, not zero. "
                  "Coverage is observed hours divided by all hours in the month; partial source months have low coverage.",
        "limitations": "The AirNow monitor is not one of the four competition targets. "
                       "Its record may have gaps and should not be spliced with CPCB targets for trend estimation. "
                       "The last two calendar years are incomplete as of the snapshot date.",
    }
    (out / "provenance.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Monthly CSV: {csv_path}", flush=True)
    print(f"AirNow readings: {len(airnow)} into {len(airnow_hourly)} hours; CPCB target readings: {train_rows}", flush=True)


if __name__ == "__main__":
    main()
