"""Build an offline November 1–12 review for a static station-median submission.

Run: python3.11 air_quality/build_static_station_dashboard.py --run-dir OUTPUT_RUN
This file makes the diagnostic HTML only; submission logic is in train_static_station_median.py.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT = ROOT / "input"
START = pd.Timestamp("2026-11-01", tz="Asia/Kolkata")
END = pd.Timestamp("2026-11-13", tz="Asia/Kolkata")

HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Static station median | Mumbai PM2.5 | November 2026</title>
<style>
:root{--bg:#f3f6fa;--card:#fff;--ink:#172235;--muted:#56657b;--grid:#dce4ed;--blue:#155bd8;--red:#d4513c;--teal:#087e76}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}main{max-width:1320px;margin:auto;padding:25px 22px 55px}
h1{font-size:27px;margin:0 0 4px}h2{font-size:18px;margin:0 0 12px}h3{font-size:15px;margin:0 0 3px}p{margin:0 0 9px}.muted{color:var(--muted)}
.hero{display:flex;justify-content:space-between;gap:18px;align-items:start;margin-bottom:18px}.stamp{font-size:12px;color:var(--muted);white-space:nowrap}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:11px;margin:15px 0}.card,.panel{background:var(--card);border:1px solid var(--grid);border-radius:11px;box-shadow:0 1px 2px #12263c0a}.card{padding:13px 16px}.card strong{display:block;font-size:21px}.card span{font-size:12px;color:var(--muted)}
.panel{padding:17px;margin:15px 0}.note{border-left:4px solid var(--teal);background:#eaf5f3;padding:10px 13px;border-radius:6px;margin:13px 0;color:#244b49}
.controls{display:flex;flex-wrap:wrap;align-items:end;gap:16px;margin:11px 0}.controls label{display:flex;flex-direction:column;gap:4px;color:var(--muted);font-size:12px}.controls select{font:inherit;color:var(--ink);background:white;border:1px solid #bbc9da;border-radius:6px;padding:6px 8px}.slide{min-width:250px;flex:1}.slide input{width:100%;accent-color:var(--blue)}
.legend{display:flex;gap:18px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin:9px 0 11px}.key{display:inline-block;width:19px;height:3px;vertical-align:middle;margin-right:5px}.key.base{background:var(--blue)}.key.obs{background:var(--red)}.key.shade{height:12px;background:#dceef1}
.plot{margin:0 0 22px}.plot:last-child{margin-bottom:0}.plot .caption{color:var(--muted);font-size:12px;margin:0 0 2px}.plot svg{display:block;width:100%;height:auto}.plot text{font:11px system-ui,sans-serif;fill:var(--muted)}.grid{stroke:#e4eaf1}.axis{stroke:#aab9ca}.base-line{stroke:var(--blue);stroke-width:2.5;stroke-dasharray:7 4}.actual-line{fill:none;stroke:var(--red);stroke-width:1.7}.actual-dot{fill:var(--red);stroke:#fff;stroke-width:.6}.clip{fill:var(--red)}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:7px 9px;text-align:left;border-bottom:1px solid #e7edf3}thead th{background:#edf2f8;position:sticky;top:0}td.num{text-align:right;font-variant-numeric:tabular-nums}.tablewrap{overflow:auto;max-height:550px;border:1px solid var(--grid);border-radius:7px}.small{font-size:12px;color:var(--muted)}
@media(max-width:720px){main{padding:15px 11px}.hero{display:block}.stamp{margin-top:7px}.cards{grid-template-columns:repeat(2,1fr)}.panel{padding:12px}.slide{min-width:100%}}
</style></head><body><main>
<div class="hero"><div><h1>One fixed PM2.5 forecast per station</h1><p class="muted">November 1–12, 2026 · hourly target intervals · µg/m³ · IST</p></div><div class="stamp">Run __STAMP__</div></div>
<div class="cards" id="cards"></div>
<div class="note"><strong>How to read this:</strong> Dashed blue is a single median level per station, repeated for every submitted hour. Red is observed PM2.5 where Train has a value. The forecast uses November 2–8 observations and excludes November 9. Values for November 1–6 are shown retrospectively, including training observations; visual fit there is <em>not</em> an independent forecast test. November 11–12 are the private scoring dates.</div>
<section class="panel"><h2>Predictions and actuals</h2>
<div class="controls"><label>Visible span<select id="span"><option value="1">1 day</option><option value="3">3 days</option><option value="5">5 days</option><option value="7" selected>7 days</option><option value="12">12 days</option></select></label><label>Station<select id="station"><option value="all">All four stations</option>__STATION_OPTIONS__</select></label><label>Y axis<select id="axis"><option value="120">0–120: recent levels</option><option value="__FULL_MAX__">0–__FULL_MAX__: all observed values</option></select></label><label class="slide">Slide through the data <span id="rangeLabel"></span><input id="slider" type="range" min="1" max="6" step="1" value="1"></label></div>
<div class="legend"><span><i class="key base"></i>Submitted forecast</span><span><i class="key obs"></i>Observed hourly PM2.5</span><span><i class="key shade"></i>Training period, November 2–8</span></div><div id="plots"></div>
<p class="small">The Y axis is fixed across stations and while sliding. A red triangle marks an observed value above the selected scale. Hover over any red point for its exact reading. X labels show local date and hour.</p></section>
<section class="panel"><h2>What went into the four fixed values</h2><div class="tablewrap"><table><thead><tr><th>Station</th><th>Forecast</th><th>History hours</th><th>History days</th><th>History dates</th></tr></thead><tbody id="profileRows"></tbody></table></div>
<p class="small">Median of valid, nonnegative hourly readings within November 2–8, separately for each station. Readings flagged above 1,000 µg/m³ are removed. No daily aggregation, hour adjustment, smoothing, trend, or extra day filtering is used.</p></section>
<section class="panel"><h2>Daily coverage and level</h2><div class="tablewrap"><table><thead><tr><th>Day</th><th>Station</th><th>Observed hours</th><th>Actual median</th><th>Actual mean</th><th>Fixed forecast</th><th>Used to train?</th></tr></thead><tbody id="dailyRows"></tbody></table></div>
<p class="small">Daily actuals use the Train snapshot. Missing days are blank, not zero. This table separates the station forecast from observed day-to-day changes.</p></section>
<section class="panel"><h2>Submission and validation</h2><p id="validation"></p><p class="small">The validation is a retrospective two-day-ahead check on six historical windows, using only prior observation timestamps. The source's first publication times at those historical origins are unverified. This does not estimate private leaderboard performance.</p><p class="small">Source files: __TRAIN_FILE__, __TEST_FILE__. Companion CSV contains every station-hour prediction and available actual for November 1–12.</p></section>
</main><script>
const data=__DATA__,stations=__STATIONS__,profile=__PROFILE__,validation=__VALIDATION__;
const NS='http://www.w3.org/2000/svg',fmt=v=>v===null?'—':Number(v).toFixed(2);
const byId=Object.fromEntries(stations.map(s=>[s.id,s.name]));
function svg(parent,tag,attrs={},label=''){const e=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(label)e.textContent=label;parent.appendChild(e);return e}
function path(points){return points.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ')}
function dayLabel(n){return String(n).padStart(2,'0')+' Nov'}
function render(){
 const width=+document.getElementById('span').value,slider=document.getElementById('slider');slider.max=13-width;
 if(+slider.value>13-width)slider.value=13-width;
 const first=+slider.value,last=first+width-1,ymax=+document.getElementById('axis').value;
 document.getElementById('rangeLabel').textContent=dayLabel(first)+' – '+dayLabel(last);
 const selected=document.getElementById('station').value,host=document.getElementById('plots');host.innerHTML='';
 const chosen=selected==='all'?stations:stations.filter(s=>String(s.id)===selected);
 const start=Date.parse(`2026-11-${String(first).padStart(2,'0')}T00:00:00+05:30`),end=start+width*86400000;
 const W=1100,H=220,L=54,R=16,T=18,B=42,pw=W-L-R,ph=H-T-B;
 const x=t=>L+(t-start)/(end-start)*pw,y=v=>T+ph-Math.min(Math.max(v,0),ymax)/ymax*ph;
 for(const st of chosen){
  const level=profile.find(p=>p.location_id===st.id).prediction_pm25;
  const series=data.filter(r=>r.location_id===st.id&&r.day>=first&&r.day<=last);
  const wrap=document.createElement('div');wrap.className='plot';
  const title=document.createElement('h3');title.textContent=st.name+' · fixed forecast '+fmt(level);wrap.appendChild(title);
  const sub=document.createElement('p');sub.className='caption';sub.textContent=series.filter(r=>r.actual!==null).length+' observed of '+series.length+' target hours in this view';wrap.appendChild(sub);
  const g=svg(wrap,'svg',{viewBox:`0 0 ${W} ${H}`,role:'img','aria-label':st.name+' fixed prediction and observed PM2.5'});
  const trainingStart=Date.parse('2026-11-02T00:00:00+05:30'),trainingEnd=Date.parse('2026-11-09T00:00:00+05:30');
  const a=Math.max(start,trainingStart),b=Math.min(end,trainingEnd);if(b>a)svg(g,'rect',{x:x(a),y:T,width:x(b)-x(a),height:ph,fill:'#dceef1'});
  for(const v of [0,Math.round(ymax/2),ymax]){svg(g,'line',{x1:L,y1:y(v),x2:W-R,y2:y(v),class:'grid'});svg(g,'text',{x:L-7,y:y(v)+4,'text-anchor':'end'},String(v))}
  const tick=width===1?3:width===3?6:width<=7?12:24;
  for(let h=0;h<=width*24;h+=tick){const t=start+h*3600000,xx=x(t),d=new Date(t+19800000);svg(g,'line',{x1:xx,y1:T,x2:xx,y2:T+ph,class:'grid'});const label=width===1?`${String(d.getUTCHours()).padStart(2,'0')}:00`:`${d.getUTCDate()} Nov ${String(d.getUTCHours()).padStart(2,'0')}`;svg(g,'text',{x:xx,y:H-12,'text-anchor':h===0?'start':h===width*24?'end':'middle'},label)}
  svg(g,'line',{x1:L,y1:T+ph,x2:W-R,y2:T+ph,class:'axis'});svg(g,'line',{x1:L,y1:y(level),x2:W-R,y2:y(level),class:'base-line'});
  const tag=svg(g,'text',{x:W-R-3,y:y(level)-5,'text-anchor':'end',fill:'#155bd8'},fmt(level));tag.setAttribute('style','fill:#155bd8;font-weight:700');
  let segment=[],prev=null;function flush(){if(segment.length>1)svg(g,'path',{d:path(segment),class:'actual-line'});segment=[]}
  for(const r of series){if(r.actual===null){flush();prev=null;continue}const t=Date.parse(r.time);if(prev!==null&&t-prev!==3600000)flush();const xx=x(t),yy=y(r.actual);segment.push([xx,yy]);prev=t;const clipped=r.actual>ymax;const dot=clipped?svg(g,'path',{d:`M ${xx-4} ${T+9} L ${xx} ${T} L ${xx+4} ${T+9} Z`,class:'clip'}):svg(g,'circle',{cx:xx,cy:yy,r:3,class:'actual-dot'});svg(dot,'title',{},`${r.label} · actual ${fmt(r.actual)} · fixed forecast ${fmt(level)}${r.training?' · in training window':''}`)}flush();host.appendChild(wrap)
 }
}
document.getElementById('cards').innerHTML=profile.map(p=>`<div class="card"><strong>${fmt(p.prediction_pm25)}</strong><span>${byId[p.location_id]}<br>${p.history_hours} readings · ${p.history_days} days</span></div>`).join('');
document.getElementById('profileRows').innerHTML=profile.map(p=>`<tr><td>${byId[p.location_id]}</td><td class="num">${fmt(p.prediction_pm25)}</td><td class="num">${p.history_hours}</td><td class="num">${p.history_days}</td><td>${p.history_dates.join(', ')}</td></tr>`).join('');
const daily=[];for(let d=1;d<=12;d++)for(const st of stations){const v=data.filter(r=>r.day===d&&r.location_id===st.id&&r.actual!==null).map(r=>r.actual).sort((a,b)=>a-b),n=v.length,med=n?(v[Math.floor((n-1)/2)]+v[Math.floor(n/2)])/2:null,mean=n?v.reduce((a,b)=>a+b,0)/n:null,training=d>=2&&d<=8;daily.push(`<tr><td>${dayLabel(d)}</td><td>${st.name}</td><td class="num">${n}</td><td class="num">${fmt(med)}</td><td class="num">${fmt(mean)}</td><td class="num">${fmt(profile.find(p=>p.location_id===st.id).prediction_pm25)}</td><td>${training&&n?'Yes':'No'}</td></tr>`)}document.getElementById('dailyRows').innerHTML=daily.join('');
document.getElementById('validation').textContent=`${validation.rows} scored historical station-hours: RMSE ${fmt(validation.pooled_rmse)} µg/m³, MAE ${fmt(validation.pooled_mae)} µg/m³. The new submission has 2,592 rows and exactly four distinct forecast values.`;
for(const id of ['span','station','axis'])document.getElementById(id).addEventListener('change',render);document.getElementById('slider').addEventListener('input',render);render();
</script></body></html>'''


def newest(stem: str) -> Path:
    return max(INPUT.glob(f"{stem}*.csv"), key=lambda p: (p.stat().st_mtime_ns, p.name))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    submission_files = list(run_dir.glob("submission_*.csv"))
    metrics_files = list(run_dir.glob("metrics_*.json"))
    if len(submission_files) != 1 or len(metrics_files) != 1:
        raise ValueError("Expected exactly one submission and metrics file")
    stamp = run_dir.name.removeprefix("static_station_median_")
    metrics = json.loads(metrics_files[0].read_text())
    submission = pd.read_csv(submission_files[0])
    train_file, test_file = newest("Train"), newest("Test")
    train, test = pd.read_csv(train_file), pd.read_csv(test_file)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert("Asia/Kolkata")
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert("Asia/Kolkata")
    test["target_end_ist"] = pd.to_datetime(test.target_end_ist, utc=True).dt.tz_convert("Asia/Kolkata")
    assert train.set_index(["location_id", "timestamp_ist"]).index.is_unique
    paired = test.loc[(test.target_start_ist >= START) & (test.target_start_ist < END)].copy()
    paired = paired.merge(submission.rename(columns={"Target": "prediction_pm25"}), on="ID", how="left", validate="one_to_one")
    paired = paired.merge(train[["location_id", "timestamp_ist", "pm25"]].rename(columns={"timestamp_ist": "target_end_ist", "pm25": "actual_pm25"}), on=["location_id", "target_end_ist"], how="left", validate="one_to_one")
    assert len(paired) == 12 * 24 * 4 and paired.prediction_pm25.notna().all()
    paired = paired.sort_values(["target_start_ist", "location_id"]).reset_index(drop=True)
    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]].sort_values("location_id")
    paired = paired.merge(stations, on="location_id", how="left", validate="many_to_one")
    paired["in_training_window"] = ((paired.target_start_ist >= pd.Timestamp("2026-11-02", tz="Asia/Kolkata")) &
                                   (paired.target_start_ist < pd.Timestamp("2026-11-09", tz="Asia/Kolkata")) &
                                   paired.actual_pm25.notna())
    paired["actual_minus_prediction"] = paired.actual_pm25 - paired.prediction_pm25
    csv_file = run_dir / f"predicted_vs_actual_20261101_20261112_{stamp}.csv"
    paired[["ID", "location_id", "station_name", "target_start_ist", "target_end_ist",
            "prediction_pm25", "actual_pm25", "actual_minus_prediction", "in_training_window"]].to_csv(csv_file, index=False, float_format="%.6f")
    rows = [{"location_id": int(r.location_id), "day": int(r.target_start_ist.day),
             "time": r.target_start_ist.isoformat(), "label": r.target_start_ist.strftime("%d Nov %H:%M"),
             "actual": None if pd.isna(r.actual_pm25) else round(float(r.actual_pm25), 4),
             "training": bool(r.in_training_window)} for r in paired.itertuples(index=False)]
    profile = metrics["station_profile"]
    training_days = pd.read_csv(next(run_dir.glob("training_days_*.csv")))
    for item in profile:
        item["history_dates"] = sorted(training_days.loc[
            training_days.location_id == item["location_id"], "day"].tolist())
    full_max = int(np.ceil(max(paired.actual_pm25.max(), paired.prediction_pm25.max()) / 50) * 50)
    station_options = "".join(f'<option value="{r.location_id}">{r.station_name}</option>' for r in stations.itertuples(index=False))
    html = (HTML.replace("__STAMP__", stamp).replace("__STATION_OPTIONS__", station_options)
            .replace("__FULL_MAX__", str(full_max)).replace("__TRAIN_FILE__", train_file.name)
            .replace("__TEST_FILE__", test_file.name)
            .replace("__STATIONS__", json.dumps([{"id": int(r.location_id), "name": r.station_name} for r in stations.itertuples(index=False)]))
            .replace("__PROFILE__", json.dumps(profile)).replace("__VALIDATION__", json.dumps(metrics["validation"]))
            .replace("__DATA__", json.dumps(rows).replace("</", "<\\/")))
    html_file = run_dir / f"static_station_review_20261101_20261112_{stamp}.html"
    html_file.write_text(html, encoding="utf-8")
    shutil.copy2(__file__, run_dir / f"build_static_station_dashboard_code_{stamp}.py")
    print(html_file)
    print(csv_file)
    print(f"Hourly rows: {len(paired)}; observed: {paired.actual_pm25.notna().sum()}; full Y axis: {full_max}")


if __name__ == "__main__":
    main()
