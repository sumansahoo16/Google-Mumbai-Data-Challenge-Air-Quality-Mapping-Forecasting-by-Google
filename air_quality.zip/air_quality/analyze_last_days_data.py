"""Score saved submissions against local same-source November 10 readings.

Run: python3.11 air_quality/analyze_last_days_data.py
This is analysis only; it does not modify any submission.
"""

from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
INPUT, OUTPUT = ROOT / "input", ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
TARGET_DAY = "2026-11-10"  # Day on which the target hour starts, not the file's hour-end date.
RUNS = {
    "fixed_hourly_median": "fixed_hourly_median_20261109_190846_076430_IST",
    "recent_level_adjusted": "recent_level_adjusted_median_20261109_191623_492183_IST",
    "weighted_8_7_proxy": "weighted_recent_days_20261109_193002_129993_IST",
    "weighted_nov1_6": "weighted_nov1_6_20261109_193245_213862_IST",
}


def newest(stem: str) -> Path:
    return max(INPUT.glob(f"{stem}*.csv"), key=lambda p: (p.stat().st_mtime_ns, p.name))


def score(g: pd.DataFrame) -> pd.Series:
    error = g.prediction_pm25 - g.actual_pm25
    return pd.Series({"rows": len(g), "rmse": float(np.sqrt(np.mean(error ** 2))),
                      "mae": float(np.mean(np.abs(error))),
                      "bias_prediction_minus_actual": float(error.mean()),
                      "actual_mean": float(g.actual_pm25.mean()),
                      "predicted_mean": float(g.prediction_pm25.mean()),
                      "prediction_high_hours": int((error > 0).sum()),
                      "prediction_low_hours": int((error < 0).sum())})


def main() -> None:
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = OUTPUT / f"last_days_data_analysis_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"analyze_last_days_data_code_{stamp}.py")

    blocks = []
    for path in sorted((INPUT / "last_days_data").glob("*.txt")):
        block = pd.read_csv(path, sep="\t")
        block["station_name"] = path.stem
        block["target_end_ist"] = pd.to_datetime(
            block.Date + " " + block.Time, format="%d-%m-%Y %H:%M").dt.tz_localize(IST)
        assert block.target_end_ist.is_unique and block.Unit.eq("µg/m³").all()
        blocks.append(block[["station_name", "target_end_ist", "Value"]])
    readings = pd.concat(blocks, ignore_index=True).rename(columns={"Value": "actual_pm25"})
    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    test = pd.read_csv(newest("Test"))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["target_end_ist"] = pd.to_datetime(test.target_end_ist, utc=True).dt.tz_convert(IST)
    test = test.merge(stations, on="location_id", how="left", validate="many_to_one")
    paired = test.merge(readings, on=["station_name", "target_end_ist"], how="inner", validate="one_to_one")
    paired["target_day"] = paired.target_start_ist.dt.strftime("%Y-%m-%d")
    assert paired.ID.is_unique

    train = pd.read_csv(newest("Train"))
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    overlap = readings.merge(train[["station_name", "timestamp_ist", "pm25"]],
                             left_on=["station_name", "target_end_ist"],
                             right_on=["station_name", "timestamp_ist"],
                             how="inner", validate="one_to_one")
    source_check = {"matched_rows": len(overlap),
                    "pearson_correlation": float(overlap.actual_pm25.corr(overlap.pm25)),
                    "mean_absolute_difference_ugm3": float((overlap.actual_pm25 - overlap.pm25).abs().mean()),
                    "note": "Text values are rounded and may reflect source revisions; this is a proxy, not an official organizer label file."}
    (run_dir / f"source_overlap_{stamp}.json").write_text(json.dumps(source_check, indent=2) + "\n")

    day = paired.loc[paired.target_day == TARGET_DAY].copy()
    assert len(day) > 0
    all_scores = []
    by_station = []
    matches = []
    for model, folder in RUNS.items():
        submission_files = list((OUTPUT / folder).glob("submission_*.csv"))
        if len(submission_files) != 1:
            raise ValueError(f"Expected one submission in {folder}")
        submission = pd.read_csv(submission_files[0]).rename(columns={"Target": "prediction_pm25"})
        matched = day.merge(submission, on="ID", validate="one_to_one")
        assert len(matched) == len(day) and matched.prediction_pm25.notna().all()
        matched["model"] = model
        matched["error_prediction_minus_actual"] = matched.prediction_pm25 - matched.actual_pm25
        matches.append(matched)
        all_scores.append({"model": model, **score(matched).to_dict()})
        for station, block in matched.groupby("station_name"):
            by_station.append({"model": model, "station_name": station, **score(block).to_dict()})
    overall = pd.DataFrame(all_scores).sort_values("rmse")
    sites = pd.DataFrame(by_station).sort_values(["model", "station_name"])
    overall.to_csv(run_dir / f"nov10_overall_scores_{stamp}.csv", index=False, float_format="%.6f")
    sites.to_csv(run_dir / f"nov10_station_scores_{stamp}.csv", index=False, float_format="%.6f")
    pd.concat(matches)[["model", "ID", "station_name", "target_start_ist", "target_end_ist",
                        "actual_pm25", "prediction_pm25", "error_prediction_minus_actual"]].to_csv(
        run_dir / f"nov10_matched_hours_{stamp}.csv", index=False, float_format="%.6f")

    readings["source_end_day"] = readings.target_end_ist.dt.strftime("%Y-%m-%d")
    daily = readings.loc[readings.source_end_day.between("2026-11-07", "2026-11-10")].groupby(
        ["source_end_day", "station_name"]).actual_pm25.agg(["size", "mean", "median", "max"]).reset_index()
    daily.to_csv(run_dir / f"recent_daily_levels_{stamp}.csv", index=False, float_format="%.6f")

    # Check corrections fitted on the preceding day and scored only on Nov 10.
    calibration = []
    prior = paired.loc[paired.target_day == "2026-11-09"]
    for model in ("fixed_hourly_median", "weighted_nov1_6"):
        submission = pd.read_csv(next((OUTPUT / RUNS[model]).glob("submission_*.csv"))).rename(
            columns={"Target": "prediction_pm25"})
        history = prior.merge(submission, on="ID", validate="one_to_one")
        history["residual"] = history.actual_pm25 - history.prediction_pm25
        history["ratio"] = history.actual_pm25 / history.prediction_pm25
        shift = history.groupby("location_id").residual.median()
        multiplier = history.groupby("location_id").ratio.median()
        target = day.merge(submission, on="ID", validate="one_to_one")
        variants = {"raw": target.prediction_pm25,
                    "station_median_addition": target.prediction_pm25 + target.location_id.map(shift),
                    "station_median_multiplier": target.prediction_pm25 * target.location_id.map(multiplier)}
        for method, values in variants.items():
            error = np.maximum(values, 0) - target.actual_pm25
            calibration.append({"model": model, "method": method, "train_day": "2026-11-09",
                                "test_day": TARGET_DAY, "rows": len(target),
                                "rmse": float(np.sqrt(np.mean(error ** 2))),
                                "mae": float(np.mean(np.abs(error)))})
    pd.DataFrame(calibration).to_csv(run_dir / f"prior_day_correction_check_{stamp}.csv",
                                     index=False, float_format="%.6f")

    latest = sites.loc[sites.model == "weighted_nov1_6"].copy()
    lines = ["# November 10 PM2.5 proxy score", "",
             f"Text-file observations matched to {len(day)}/96 competition target intervals starting on {TARGET_DAY}. "
             "The latest matched target hour starts at 20:00 IST. All November 10 IDs are marked unscored in Test; these RMSE values are diagnostic, not Zindi leaderboard scores.",
             "", f"Source overlap with Train: {source_check['matched_rows']} rows, "
             f"correlation {source_check['pearson_correlation']:.5f}, "
             f"MAE {source_check['mean_absolute_difference_ugm3']:.3f} µg/m³.",
             "", "## Overall", "", "| Model | RMSE | MAE | Prediction − actual bias |", "|---|---:|---:|---:|"]
    for row in overall.itertuples(index=False):
        lines.append(f"| {row.model} | {row.rmse:.2f} | {row.mae:.2f} | {row.bias_prediction_minus_actual:.2f} |")
    lines += ["", "## Latest weighted model by station", "",
              "| Station | Observed hours | RMSE | Prediction − actual bias | Low hours |",
              "|---|---:|---:|---:|---:|"]
    for row in latest.itertuples(index=False):
        lines.append(f"| {row.station_name.split(',')[0]} | {int(row.rows)} | {row.rmse:.2f} | "
                     f"{row.bias_prediction_minus_actual:.2f} | {int(row.prediction_low_hours)} |")
    lines += ["", "Malad accounts for about 84% of latest model squared error. Its early-hours spike dominates the daily RMSE; after 14:00, observations are much closer to predictions. A single all-hours adjustment is therefore unstable.",
              "", "The prior-day correction check fits on November 9 and scores November 10. A station-wise median multiplier slightly outperforms a station-wise median addition on this one transition, but both are exposed to festival-period changes. See CSVs for the full calculations."]
    (run_dir / f"report_{stamp}.md").write_text("\n".join(lines) + "\n")
    print(run_dir)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
