"""Estimate weekday effects in Zindi Mumbai PM2.5 training data.

Run: python3 air_quality/analyze_day_of_week.py
Matches station, ISO week, and hour to reduce seasonal and diurnal bias.
"""

from __future__ import annotations

import csv
import random
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from statistics import mean, median
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
TRAIN = ROOT / "input" / "Train (2).csv"
NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
STATIONS = {
    "12236418": "Borivali East",
    "12236426": "Malad West",
    "12238567": "Byculla",
    "12238576": "Shivaji Nagar",
}


def interval(values: list[float], seed: int, iterations: int = 5000) -> tuple[float, float]:
    rng = random.Random(seed)
    draws = sorted(mean(rng.choices(values, k=len(values))) for _ in range(iterations))
    return draws[int(0.025 * iterations)], draws[int(0.975 * iterations)]


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    stamp = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
    out = ROOT / "output" / f"weekday_effect_{stamp}"
    out.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, out / "analyze_day_of_week_code.py")

    raw = defaultdict(list)
    week_hour = defaultdict(dict)
    first = last = None
    with TRAIN.open(newline="") as stream:
        for row in csv.DictReader(stream):
            value = float(row["pm25"])
            if row["flag_high_1000"].lower() == "true" or not 0 <= value <= 1000:
                continue
            timestamp = datetime.fromisoformat(row["timestamp_ist"])
            first = min(first, timestamp) if first else timestamp
            last = max(last, timestamp) if last else timestamp
            iso = timestamp.isocalendar()
            day = timestamp.weekday()
            raw[day].append(value)
            key = (row["sensor_id"], iso.year, iso.week, timestamp.hour)
            if day in week_hour[key]:
                raise ValueError(f"Duplicate station-week-hour-weekday: {key}, {day}")
            week_hour[key][day] = value

    # Each station-week-hour compares observed weekend and weekday days.
    weekend_by_station_week = defaultdict(list)
    residual_by_station_week_day = defaultdict(list)
    for (station, year, week, hour), days in week_hour.items():
        weekdays = [value for day, value in days.items() if day < 5]
        weekends = [value for day, value in days.items() if day >= 5]
        if len(weekdays) >= 3 and weekends:
            weekend_by_station_week[(station, year, week)].append(mean(weekends) - mean(weekdays))
        if len(days) >= 4:
            reference = mean(days.values())
            for day, value in days.items():
                residual_by_station_week_day[(station, year, week, day)].append(value - reference)

    station_week_effect = {
        key: mean(hour_effects) for key, hour_effects in weekend_by_station_week.items()
        if len(hour_effects) >= 18
    }
    weekly_effects = defaultdict(list)
    for (_, year, week), effect in station_week_effect.items():
        weekly_effects[(year, week)].append(effect)
    weekly = [mean(effects) for effects in weekly_effects.values()]
    low, high = interval(weekly, seed=42)

    raw_weekday = []
    adjusted_weekday = []
    valid_day = {
        key: mean(hour_residuals) for key, hour_residuals in residual_by_station_week_day.items()
        if len(hour_residuals) >= 18
    }
    for day, name in enumerate(NAMES):
        values = raw[day]
        raw_weekday.append({"day": name, "observed_hours": len(values),
                            "raw_mean_pm25_ug_m3": round(mean(values), 3),
                            "raw_median_pm25_ug_m3": round(median(values), 3)})
        per_week = defaultdict(list)
        for (_, year, week, observed_day), effect in valid_day.items():
            if observed_day == day:
                per_week[(year, week)].append(effect)
        weekly_day = [mean(effects) for effects in per_week.values()]
        lo, hi = interval(weekly_day, seed=99 + day, iterations=3000)
        adjusted_weekday.append({
            "day": name, "weeks": len(weekly_day),
            "adjusted_deviation_ug_m3": round(mean(weekly_day), 3),
            "bootstrap_low_95": round(lo, 3), "bootstrap_high_95": round(hi, 3),
        })
    write_csv(out / "raw_weekday.csv", raw_weekday)
    write_csv(out / "adjusted_weekday.csv", adjusted_weekday)

    station_rows = []
    for sensor, station in STATIONS.items():
        values = [effect for (sid, _, _), effect in station_week_effect.items() if sid == sensor]
        station_rows.append({"station_name": station, "matched_weeks": len(values),
                             "weekend_minus_weekday_ug_m3": round(mean(values), 3),
                             "median_weekly_difference": round(median(values), 3)})
    write_csv(out / "station_weekend_effect.csv", station_rows)

    weekday_values = [v for day in range(5) for v in raw[day]]
    weekend_values = [v for day in (5, 6) for v in raw[day]]
    report = f"""# Day-of-week analysis of competition PM2.5

Source: Zindi Train.csv, four CPCB target sensors, {first:%Y-%m-%d} to {last:%Y-%m-%d} IST. Valid hourly readings: {sum(map(len, raw.values())):,}; values flagged above 1000 µg/m³ were excluded.

## Answer

The raw weekend mean is {mean(weekend_values):.2f} µg/m³ and raw weekday mean is {mean(weekday_values):.2f} µg/m³ (difference {mean(weekend_values)-mean(weekday_values):+.2f}). After matching station, ISO week, and hour of day, the weekend minus weekday effect is **{mean(weekly):+.2f} µg/m³** across {len(weekly)} weeks (approximate 95% week-cluster bootstrap interval **{low:+.2f} to {high:+.2f}**). This does not establish a consistent weekend effect.

## Adjusted day pattern

| Day | Relative to station-week-hour mean (µg/m³) | Approximate 95% interval | Weeks |
|---|---:|---:|---:|
"""
    for item in adjusted_weekday:
        report += (f"| {item['day']} | {item['adjusted_deviation_ug_m3']:+.2f} | "
                   f"{item['bootstrap_low_95']:+.2f} to {item['bootstrap_high_95']:+.2f} | "
                   f"{item['weeks']} |\n")
    report += """
None of the seven intervals excludes zero. Station-level weekend differences are in `station_weekend_effect.csv`. The analysis is observational: a weekday can coincide with weather, festivals, and changing data coverage. The interval is a week-level bootstrap summary, not a causal estimate.

## Method

- Raw means use all valid hourly competition readings.
- Weekend comparison: within each station × ISO week × hour, require at least three weekday readings and one weekend reading; average hour differences only when a station-week has at least 18 matched hours. Average stations within week, then weeks equally.
- Seven-day comparison: subtract each observed station × ISO week × hour mean when at least four weekdays are observed; retain a station-week-day with at least 18 hours; average stations within week, then weeks equally.
- Bootstrap resamples the resulting week estimates 5,000 times for weekends and 3,000 times for each weekday.
"""
    (out / "report.md").write_text(report)
    print(out)
    print(f"Matched weeks: {len(weekly)}, weekend minus weekday: {mean(weekly):+.2f} [{low:+.2f}, {high:+.2f}] µg/m³")


if __name__ == "__main__":
    main()
