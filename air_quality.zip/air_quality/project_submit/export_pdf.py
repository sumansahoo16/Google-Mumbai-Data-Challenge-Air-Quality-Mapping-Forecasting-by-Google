"""Export the cached, offline data story as a print-ready PDF.

Run after build.py. Requires a local Chrome or Chromium installation; no
network access or API key is used. The source HTML is not modified.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "index.html"
OUTPUT = HERE / "four_breaths_of_mumbai.pdf"
MAX_BYTES = 10_000_000

PRINT_CSS = r"""
<style id="pdf-print-layout">
@page { size: A4; margin: 0; }
@media print {
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
  html, body { width: 210mm; margin: 0; overflow: visible; }
  body { font-size: 16px; line-height: 1.46; }
  .wrap { width: calc(100% - 88px); max-width: none; }
  .top { padding: 18px 0; }
  .hero { min-height: 1040px; padding: 125px 0 65px; break-after: page; }
  .hero:after { right: -15%; }
  .hero h1 { font-size: 82px; }
  .hero-deck { font-size: 22px; }
  .hero-strip { margin-top: 95px; }
  .hero-stat strong { font-size: 32px; }
  .chapter { break-before: page; break-inside: avoid; padding: 66px 0 50px; }
  .chapter-head { grid-template-columns: 150px 1fr; gap: 24px; }
  .chapter h2 { font-size: 47px; margin-bottom: 18px; }
  .chapter .lede { font-size: 19px; line-height: 1.37; }
  .chapter-body { margin-left: 0; }
  .chart-frame { margin: 30px 0 12px; padding: 19px 18px 12px; break-inside: avoid; }
  .map-area { grid-template-columns: 3fr 2fr; gap: 22px; }
  .map-area .chart-frame { margin-top: 12px; }
  .map-area .callout { font-size: 28px; }
  .map-area .map-note { font-size: 13px; }
  .station-ledger { margin-top: 24px; }
  .station-row { grid-template-columns: minmax(140px,1fr) 65px 90px 125px; gap: 9px; padding: 10px 0; }
  .station-row strong { font-size: 20px; }
  .station-name { font-size: 13px; }
  .number-pair { margin: 20px 0; }
  .number-pair b { font-size: 34px; }
  .caption { font-size: 12px; }
  .insight { font-size: 17px; margin-top: 20px; }
  .copy { font-size: 15px; }
  .method .chapter-body { grid-template-columns: 1fr 1fr; gap: 22px; }
  .method-card { padding-top: 12px; font-size: 14px; break-inside: avoid; }
  .method-card h3 { font-size: 20px; }
  .source-list li { margin: 6px 0; }
  .footer { padding: 25px 0 30px; font-size: 11px; }
}
</style>
"""


def find_chrome() -> str:
    for candidate in (
        shutil.which("google-chrome"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    ):
        if candidate and Path(candidate).is_file():
            return str(candidate)
    raise RuntimeError("Chrome or Chromium is required to export the PDF")


def main() -> None:
    html = SOURCE.read_text(encoding="utf-8")
    if "</head>" not in html:
        raise ValueError(f"Missing </head> in {SOURCE}")
    print_html = html.replace("</head>", PRINT_CSS + "</head>", 1)

    # Keep the temporary HTML beside assets so its local font URLs still work.
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", suffix=".html", prefix=".print_",
        dir=HERE, delete=False,
    ) as temporary:
        temporary.write(print_html)
        print_path = Path(temporary.name)

    try:
        with tempfile.TemporaryDirectory(prefix="four_breaths_chrome_") as profile:
            command = [
                find_chrome(), "--headless", "--disable-gpu", "--no-sandbox",
                "--disable-background-networking", "--no-first-run",
                "--no-default-browser-check", "--no-pdf-header-footer",
                f"--user-data-dir={profile}", f"--print-to-pdf={OUTPUT}",
                print_path.as_uri(),
            ]
            subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
    finally:
        print_path.unlink(missing_ok=True)

    size = OUTPUT.stat().st_size
    if size >= MAX_BYTES:
        OUTPUT.unlink()
        raise RuntimeError(f"PDF exceeded 10 MB: {size:,} bytes")
    print(f"Wrote {OUTPUT} ({size:,} bytes; under 10 MB)")


if __name__ == "__main__":
    main()
