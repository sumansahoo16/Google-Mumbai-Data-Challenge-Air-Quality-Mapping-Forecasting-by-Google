"""Download official OpenAQ archive records for Mumbai shift analysis.

Example: python3.11 air_quality/fetch_openaq_archive.py --start 2026-10-30 --end 2026-11-04
Writes a timestamped, separate snapshot under input/. It never changes Train.csv.
"""

from __future__ import annotations

import argparse
import gzip
import json
import shutil
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT = ROOT / "input"
IST = ZoneInfo("Asia/Kolkata")
ARCHIVE = "https://openaq-data-archive.s3.amazonaws.com/records/csv.gz"


def download(url: str) -> tuple[bytes | None, int]:
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "MumbaiAirQualityResearch/1.0"})
            with urllib.request.urlopen(request, timeout=30) as response:
                return response.read(), response.status
        except urllib.error.HTTPError as error:
            if error.code == 404:
                return None, 404
            if error.code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise
        except (TimeoutError, urllib.error.URLError):
            if attempt == 2:
                raise
        time.sleep(2 ** attempt)
    raise RuntimeError("Download retry loop ended unexpectedly")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--start", default="2026-10-30", help="First archive day, YYYY-MM-DD")
    parser.add_argument("--end", default="2026-11-04", help="Last archive day, YYYY-MM-DD")
    args = parser.parse_args()
    days = pd.date_range(args.start, args.end, freq="D")
    if days.empty or len(days) > 31:
        raise ValueError("Choose an inclusive range of 1–31 days")
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    out = INPUT / f"openaq_archive_{stamp}"
    raw_dir = out / "raw"
    raw_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, out / f"fetch_openaq_archive_code_{stamp}.py")

    stations_path, = INPUT.glob("Stations*.csv")
    train_path, = INPUT.glob("Train*.csv")
    test_path, = INPUT.glob("Test*.csv")
    stations = pd.read_csv(stations_path)
    train = pd.read_csv(train_path)
    test = pd.read_csv(test_path)
    station_sensors = dict(zip(stations.location_id, stations.selected_sensor))

    records = []
    manifest = []
    for day in days:
        year, month, ymd = day.strftime("%Y"), day.strftime("%m"), day.strftime("%Y%m%d")
        for location_id, sensor_id in station_sensors.items():
            filename = f"location-{location_id}-{ymd}.csv.gz"
            url = f"{ARCHIVE}/locationid={location_id}/year={year}/month={month}/{filename}"
            content, status = download(url)
            item = {"archive_day": day.strftime("%Y-%m-%d"), "location_id": int(location_id),
                    "sensor_id": int(sensor_id), "url": url, "status": status,
                    "bytes": len(content) if content else 0}
            if content:
                path = raw_dir / filename
                path.write_bytes(content)
                try:
                    frame = pd.read_csv(path, compression="gzip")
                except (gzip.BadGzipFile, ValueError) as error:
                    raise ValueError(f"Invalid OpenAQ archive file: {url}") from error
                sensor_col = "sensors_id" if "sensors_id" in frame else "sensor_id"
                selected = frame.loc[(frame[sensor_col] == sensor_id) &
                                     (frame.parameter.str.lower() == "pm25")].copy()
                item["selected_pm25_readings"] = len(selected)
                if not selected.empty:
                    selected = selected.rename(columns={sensor_col: "sensor_id"})
                    records.append(selected[["location_id", "sensor_id", "datetime", "value"]])
            manifest.append(item)
            print(f"{ymd} location={location_id} HTTP {status}, selected readings={item.get('selected_pm25_readings', 0)}")

    if not records:
        raise RuntimeError("No target PM2.5 sensor readings were found in the downloaded files")
    source = pd.concat(records, ignore_index=True)
    source["timestamp_ist"] = pd.to_datetime(source.datetime, utc=True).dt.tz_convert(IST)
    source["value"] = pd.to_numeric(source.value, errors="coerce")
    source = source.loc[np.isfinite(source.value) & (source.value >= 0)].copy()
    source = source.drop_duplicates(["location_id", "sensor_id", "timestamp_ist"])
    source = source.sort_values(["location_id", "timestamp_ist"])
    source[["location_id", "sensor_id", "timestamp_ist", "value"]].to_csv(
        out / f"quarter_hour_pm25_{stamp}.csv", index=False)

    # OpenAQ timestamps mark the end of each quarter-hour interval. Therefore
    # readings ending at 09:00 belong to the hour ending 09:00.
    source["hour_end_ist"] = source.timestamp_ist.dt.ceil("h")
    hourly = source.groupby(["location_id", "sensor_id", "hour_end_ist"], as_index=False).agg(
        pm25=("value", "mean"), count=("value", "size"))
    hourly["quality_eligible"] = hourly["count"].between(3, 4)
    hourly["flag_high_1000"] = hourly.pm25 > 1000

    train["hour_end_ist"] = pd.to_datetime(train.timestamp_ist, utc=True).dt.tz_convert(IST)
    test["hour_end_ist"] = pd.to_datetime(test.target_end_ist, utc=True).dt.tz_convert(IST)
    train_keys = set(zip(train.location_id, train.hour_end_ist))
    test_keys = set(zip(test.location_id, test.hour_end_ist))
    hourly["in_organizer_train"] = [key in train_keys for key in zip(hourly.location_id, hourly.hour_end_ist)]
    hourly["in_fixed_test_grid"] = [key in test_keys for key in zip(hourly.location_id, hourly.hour_end_ist)]
    hourly.to_csv(out / f"archive_hourly_pm25_{stamp}.csv", index=False)

    overlap = hourly.loc[hourly.quality_eligible].merge(
        train[["location_id", "hour_end_ist", "pm25"]],
        on=["location_id", "hour_end_ist"], how="inner", suffixes=("_archive", "_train"))
    overlap["absolute_difference"] = (overlap.pm25_archive - overlap.pm25_train).abs()
    overlap.to_csv(out / f"overlap_validation_{stamp}.csv", index=False)

    eligible = hourly.loc[hourly.quality_eligible].copy()
    eligible["day_ist"] = eligible.hour_end_ist.dt.strftime("%Y-%m-%d")
    daily = eligible.groupby(["day_ist", "location_id"], as_index=False).agg(
        hours=("pm25", "size"), mean_pm25=("pm25", "mean"),
        median_pm25=("pm25", "median"))
    daily.to_csv(out / f"daily_shift_{stamp}.csv", index=False)

    report = {
        "snapshot_ist": datetime.now(IST).isoformat(), "archive_days": [str(days.min().date()), str(days.max().date())],
        "organizer_train_latest_hour_ist": str(train.hour_end_ist.max()),
        "archive_files_downloaded": sum(x["status"] == 200 for x in manifest),
        "archive_files_missing": sum(x["status"] == 404 for x in manifest),
        "quarter_hour_target_readings": len(source),
        "hourly_rows_all": len(hourly), "hourly_rows_quality_eligible": len(eligible),
        "new_eligible_hours_absent_from_train": int((~eligible.in_organizer_train).sum()),
        "new_eligible_hours_in_fixed_test_grid": int((~eligible.in_organizer_train & eligible.in_fixed_test_grid).sum()),
        "overlap_hours": len(overlap),
        "overlap_median_absolute_difference": float(overlap.absolute_difference.median()) if len(overlap) else None,
        "overlap_max_absolute_difference": float(overlap.absolute_difference.max()) if len(overlap) else None,
        "source": "OpenAQ official open-data archive; CPCB is the upstream provider",
        "use": "Exploratory shift analysis only. This file contains values for fixed Test IDs and is not organizer Train.csv.",
        "manifest": manifest,
    }
    (out / f"provenance_{stamp}.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Snapshot: {out}")
    print(f"Eligible hours: {len(eligible)}; new vs Train: {report['new_eligible_hours_absent_from_train']}; "
          f"of those in Test: {report['new_eligible_hours_in_fixed_test_grid']}")
    print(f"Train overlap: {len(overlap)} hours; median absolute difference: {report['overlap_median_absolute_difference']}")


if __name__ == "__main__":
    main()
