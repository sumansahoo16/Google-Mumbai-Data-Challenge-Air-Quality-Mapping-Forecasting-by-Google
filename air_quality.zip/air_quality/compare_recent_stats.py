"""Compare station-only statistical forecasts on recent two-day windows.

This is analysis code. Submission generation stays in one separate Python file.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from train_recent_hourly_median import load_data, predict_block, VALIDATION_STARTS


ROOT = Path(__file__).resolve().parent
IST = ZoneInfo("Asia/Kolkata")


def robust_days(station: pd.DataFrame, cutoff: pd.Timestamp, days: int) -> pd.DataFrame:
    recent = station.loc[(station.timestamp_ist <= cutoff) &
                         (station.hour_start > cutoff - pd.Timedelta(days=days))].copy()
    by_day = recent.groupby("day").pm25.agg(["size", "median"])
    eligible = by_day.loc[by_day["size"] >= 12]
    if eligible.empty:
        eligible = by_day.loc[by_day["size"] >= 6]
    if eligible.empty:
        eligible = by_day
    centre = eligible["median"].median()
    scale = max(1.4826 * (eligible["median"] - centre).abs().median(), 5.0)
    keep = (eligible["median"] - centre).abs() <= 3.5 * scale
    if keep.sum() < 3:
        keep[:] = True
    return recent.loc[recent.day.isin(eligible.index[keep])]


def level_hour_profile(history: pd.DataFrame, cutoff: pd.Timestamp,
                       target_day, half_life: float, trend: bool,
                       shrink: float) -> dict[int, float]:
    daily = history.groupby("day").pm25.median()
    days_ago = np.array([(cutoff.date() - day).days for day in daily.index], dtype=float)
    weights = 0.5 ** (days_ago / half_life)
    level = float(np.average(daily.to_numpy(), weights=weights))
    if trend and len(daily) >= 3:
        dates = np.array([(day - daily.index[0]).days for day in daily.index])
        slopes = [(daily.iloc[j] - daily.iloc[i]) / (dates[j] - dates[i])
                  for i in range(len(daily)) for j in range(i + 1, len(daily))]
        slope = float(np.clip(np.median(slopes), -4.0, 4.0))
        # Extrapolate only three days; longer trends are too unstable here.
        level += slope * min((target_day - daily.index[-1]).days, 3)
    centered = history.join(daily.rename("daily_level"), on="day")
    centered["offset"] = centered.pm25 - centered.daily_level
    offsets = centered.groupby("hour").offset.median()
    return {hour: max(0.0, level + shrink * float(offsets.get(hour, 0.0)))
            for hour in range(24)}


def predict_variant(train: pd.DataFrame, valid: pd.DataFrame,
                    cutoff: pd.Timestamp, days: int, half_life: float,
                    trend: bool, shrink: float) -> np.ndarray:
    output = pd.Series(index=valid.index, dtype=float)
    for station_id, block in valid.groupby("location_id"):
        history = robust_days(train.loc[train.location_id == station_id], cutoff, days)
        for day, day_block in block.groupby("day"):
            profile = level_hour_profile(history, cutoff, day, half_life, trend, shrink)
            output.loc[day_block.index] = [profile[hour] for hour in day_block.hour]
    return output.loc[valid.index].to_numpy()


def main() -> None:
    train, _, _, train_path = load_data()
    variants = {
        "hour_median_7d": None,
        "level_hour_7d": (7, 2.0, False, 1.0),
        "level_hour_14d": (14, 2.0, False, 1.0),
        "level_hour_shrunk_14d": (14, 2.0, False, 0.7),
        "damped_trend_7d": (7, 2.0, True, 1.0),
        "damped_trend_14d": (14, 2.0, True, 1.0),
    }
    results = {name: [] for name in variants}
    for date in VALIDATION_STARTS:
        start = pd.Timestamp(date, tz=IST)
        cutoff = start - pd.Timedelta(days=2)
        valid = train.loc[(train.hour_start >= start) &
                          (train.hour_start < start + pd.Timedelta(days=2))]
        for name, params in variants.items():
            if params is None:
                prediction, _ = predict_block(train, valid, cutoff, 7)
            else:
                prediction = predict_variant(train, valid, cutoff, *params)
            results[name].append({"start": date, "rows": len(valid),
                                  "sse": float(np.sum((valid.pm25.to_numpy() - prediction) ** 2))})
    report = {"input": train_path.name, "note": "Retrospective timestamps; source availability at origins is not verified.",
              "variants": {}}
    for name, folds in results.items():
        report["variants"][name] = {
            "october_rmse": float(np.sqrt(sum(f["sse"] for f in folds[:3]) /
                                          sum(f["rows"] for f in folds[:3]))),
            "november_rmse": float(np.sqrt(sum(f["sse"] for f in folds[3:]) /
                                           sum(f["rows"] for f in folds[3:]))),
            "fold_rmse": {f["start"]: float(np.sqrt(f["sse"] / f["rows"])) for f in folds}}
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    path = ROOT / "output" / f"stats_comparison_{stamp}.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(path)
    for name, data in report["variants"].items():
        print(name, "October", round(data["october_rmse"], 2),
              "November", round(data["november_rmse"], 2))


if __name__ == "__main__":
    main()
