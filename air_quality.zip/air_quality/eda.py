"""Reproducible EDA for the Zindi Google Mumbai air quality challenge."""

from __future__ import annotations

import argparse
import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent  # Exact code copies inside output/eda_<timestamp> also run.
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"


def input_file(stem: str) -> Path:
    matches = sorted(INPUT.glob(f"{stem}*.csv"))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one {stem} CSV in {INPUT}; found {matches}")
    return matches[0]


def table(frame: pd.DataFrame) -> str:
    def cell(value: object) -> str:
        if isinstance(value, (float, np.floating)):
            return f"{value:.2f}"
        return str(value).replace("|", "\\|")
    lines = ["| " + " | ".join(map(str, frame.columns)) + " |",
             "| " + " | ".join("---" for _ in frame.columns) + " |"]
    lines.extend("| " + " | ".join(cell(value) for value in row) + " |"
                 for row in frame.itertuples(index=False, name=None))
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"eda_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"eda_code_{stamp}.py")

    train = pd.read_csv(input_file("Train"))
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert("Asia/Kolkata")
    train["available_at"] = pd.to_datetime(train.available_at, utc=True, format="mixed").dt.tz_convert("Asia/Kolkata")
    test = pd.read_csv(input_file("Test"), parse_dates=["target_start_ist", "target_end_ist"])
    sample = pd.read_csv(input_file("SampleSubmission"))
    stations = pd.read_csv(input_file("Stations"))
    train["target_start_ist"] = train["timestamp_ist"] - pd.Timedelta(hours=1)
    train["day"] = train["target_start_ist"].dt.date
    train["hour"] = train["target_start_ist"].dt.hour
    test["day"] = test["target_start_ist"].dt.date
    delayed_hours = (train["available_at"] - train["timestamp_ist"]).dt.total_seconds() / 3600
    clean = train.loc[~train["flag_high_1000"].astype(bool)].copy()
    last_30 = clean.loc[clean.timestamp_ist >= clean.timestamp_ist.max() - pd.Timedelta(days=30)]

    station_summary = (
        clean.groupby("location_id")
        .agg(observations=("pm25", "size"), first_hour=("timestamp_ist", "min"),
             last_hour=("timestamp_ist", "max"), median_pm25=("pm25", "median"),
             p95_pm25=("pm25", lambda x: x.quantile(.95)))
        .reset_index()
        .merge(stations[["location_id", "station_name"]], on="location_id", how="left")
    )
    station_summary["first_hour"] = station_summary.first_hour.astype(str)
    station_summary["last_hour"] = station_summary.last_hour.astype(str)
    daily = last_30.groupby(["day", "location_id"], as_index=False).pm25.median()
    fig, ax = plt.subplots(figsize=(12, 5))
    for loc, group in daily.groupby("location_id"):
        name = stations.set_index("location_id").loc[loc, "station_name"].split(",")[0]
        ax.plot(group.day, group.pm25, label=name)
    ax.set(title="Daily median PM2.5 by station, last 30 observed days", ylabel="PM2.5 (µg/m³)", xlabel="IST date")
    ax.legend(fontsize=8)
    ax.grid(alpha=.2)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(run_dir / f"daily_median_{stamp}.png", dpi=150)
    plt.close(fig)

    hourly = last_30.groupby(["location_id", "hour"], as_index=False).pm25.median()
    fig, ax = plt.subplots(figsize=(12, 5))
    for loc, group in hourly.groupby("location_id"):
        name = stations.set_index("location_id").loc[loc, "station_name"].split(",")[0]
        ax.plot(group.hour, group.pm25, label=name)
    ax.set(title="Median PM2.5 by start hour, last 30 observed days", ylabel="PM2.5 (µg/m³)", xlabel="Start hour (IST)")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(fontsize=8)
    ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(run_dir / f"hourly_profile_{stamp}.png", dpi=150)
    plt.close(fig)

    target = clean.pm25
    overlap = len(set(zip(train.location_id, train.timestamp_ist)) & set(zip(test.location_id, test.target_end_ist)))
    test_counts = test.groupby(["day", "scoring_block"], as_index=False).size()
    report = [
        "# Google Mumbai Air Quality Challenge: EDA",
        "",
        f"Generated: {datetime.now(ZoneInfo('Asia/Kolkata')).isoformat()}",
        "",
        "## Data and metric",
        "",
        "Forecast hourly PM2.5 concentration in µg/m³ at four Mumbai stations. "
        "The competition metric is root mean squared error (RMSE); lower is better. "
        "The submission must have the sample's 2,592 IDs in order with finite, non-negative Target predictions.",
        "",
        f"Train rows: **{len(train):,}**; test rows: **{len(test):,}**; stations: **{len(stations)}**.",
        f"Training hour ends: **{train.timestamp_ist.min()}** through **{train.timestamp_ist.max()}**.",
        f"Duplicate station-hour training keys: **{train.duplicated(['location_id', 'timestamp_ist']).sum():,}**.",
        f"Test station-hours already in the latest Train file: **{overlap:,}**. These are historical test-grid rows, not current hidden labels.",
        f"Missing values: Train **{int(train.isna().sum().sum()):,}**, Test **{int(test.isna().sum().sum()):,}**, sample Target **{sample.Target.isna().sum():,}**.",
        "",
        "## Target distribution and data quality",
        "",
        table(pd.DataFrame({"measure": ["min", "median", "mean", "p95", "p99", "max"],
                            "pm25": [target.min(), target.median(), target.mean(), target.quantile(.95), target.quantile(.99), target.max()]})),
        "",
        f"Flagged concentrations >1,000 µg/m³: **{train.flag_high_1000.astype(bool).sum():,}**. "
        "They include extreme spikes and are excluded from the model fitting and rolling history.",
        f"Source available_at minus observation end: median **{delayed_hours.median():.1f} h**, "
        f"p95 **{delayed_hours.quantile(.95):.1f} h**. The dictionary says this is not a verified first-publication time.",
        "",
        "## Stations",
        "",
        table(station_summary[["location_id", "station_name", "observations", "first_hour", "last_hour", "median_pm25", "p95_pm25"]]),
        "",
        "## Test allocation by target start date",
        "",
        table(test_counts),
        "",
        "The `scoring_block` field records the original allocation; the data dictionary says later public "
        "updates can score dates marked `unscored` in this file. It is not a prediction feature.",
        "",
        "## Modeling implications",
        "",
        "- Use a chronological holdout with a forecast gap. Random row splitting would leak nearby station-hour conditions.",
        "- Keep `mean`, `count`, `available_at`, and the high-value flag out of features because they describe observed target hours.",
        "- Historical PM2.5 has a strong seasonal and recent-level component; use lagged aggregates available before the forecast origin.",
        "- Match predictions to the sample by ID and verify all 2,592 values.",
        "",
        f"![Recent daily medians](daily_median_{stamp}.png)",
        "",
        f"![Recent hourly profile](hourly_profile_{stamp}.png)",
    ]
    (run_dir / f"eda_report_{stamp}.md").write_text("\n".join(report) + "\n")
    print(f"EDA saved to {run_dir}")
    print(f"Rows: train={len(train):,}, test={len(test):,}; flagged spikes={train.flag_high_1000.astype(bool).sum():,}")


if __name__ == "__main__":
    main()
