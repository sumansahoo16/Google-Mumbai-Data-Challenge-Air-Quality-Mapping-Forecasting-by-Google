"""Second statistical forecast: fixed station/hour medians plus a recent level shift.

Run: python3.11 air_quality/train_recent_level_adjusted_median.py
This is the complete training, validation, and submission program.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT, OUTPUT = ROOT / "input", ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
WINDOW_DAYS = 7
EXCLUDED_DAY = "2026-11-09"
MIN_RECENT_DAY_HOURS = 12
MAX_ABS_SHIFT = 20.0
VALIDATION_STARTS = ("2026-10-17", "2026-10-22", "2026-10-27",
                     "2026-11-01", "2026-11-03", "2026-11-05")


def newest(stem: str) -> Path:
    files = list(INPUT.glob(f"{stem}*.csv"))
    if not files:
        raise FileNotFoundError(f"Missing {stem} CSV in {INPUT}")
    return max(files, key=lambda p: (p.stat().st_mtime_ns, p.name))


def load() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    train_path = newest("Train")
    train = pd.read_csv(train_path)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    train = train.loc[(~train.flag_high_1000.astype(bool)) & train.pm25.notna() &
                      np.isfinite(train.pm25) & (train.pm25 >= 0)].copy()
    train["hour_start"] = train.timestamp_ist - pd.Timedelta(hours=1)
    train["day"] = train.hour_start.dt.strftime("%Y-%m-%d")
    train["hour"] = train.hour_start.dt.hour
    assert not train.duplicated(["location_id", "timestamp_ist"]).any()
    test = pd.read_csv(newest("Test"))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["hour"] = test.target_start_ist.dt.hour
    sample = pd.read_csv(newest("SampleSubmission"))
    assert train.location_id.nunique() == 4
    assert len(test) == len(sample) == 2592
    assert test.ID.is_unique and sample.ID.is_unique and set(test.ID) == set(sample.ID)
    return train, test, sample, train_path


def fit(train: pd.DataFrame, origin: pd.Timestamp) -> tuple[pd.Series, pd.DataFrame]:
    recent = train.loc[(train.hour_start >= origin - pd.Timedelta(days=WINDOW_DAYS)) &
                       (train.hour_start < origin) & (train.day != EXCLUDED_DAY)].copy()
    observed = recent.groupby(["location_id", "hour"]).pm25.median()
    station_fallback = recent.groupby("location_id").pm25.median()
    if len(station_fallback) != train.location_id.nunique():
        raise ValueError(f"A station has no history at {origin}")
    keys = pd.MultiIndex.from_product([sorted(station_fallback.index), range(24)],
                                      names=["location_id", "hour"])
    profile = observed.reindex(keys)
    # Only hours absent from the history use the station's overall median.
    fallback = pd.Series(keys.get_level_values("location_id").map(station_fallback).to_numpy(), index=keys)
    profile = profile.fillna(fallback)
    return profile, recent


def predict(rows: pd.DataFrame, profile: pd.Series) -> np.ndarray:
    keys = pd.MultiIndex.from_frame(rows[["location_id", "hour"]])
    result = profile.reindex(keys).to_numpy(dtype=float)
    if not np.isfinite(result).all():
        raise ValueError("Missing station-hour forecast")
    return result


def level_adjustment(recent: pd.DataFrame, base_profile: pd.Series) -> pd.DataFrame:
    """Median hourly residual on each station's latest day with >=12 readings."""
    recent = recent.copy()
    recent["base_prediction"] = predict(recent, base_profile)
    recent["residual"] = recent.pm25 - recent.base_prediction
    result = []
    for station_id, block in recent.groupby("location_id"):
        eligible = block.groupby("day").size()
        eligible = eligible[eligible >= MIN_RECENT_DAY_HOURS]
        if eligible.empty:
            result.append({"location_id": int(station_id), "recent_day": None,
                           "recent_hours": 0, "raw_median_residual": 0.0,
                           "level_shift": 0.0})
            continue
        recent_day = eligible.index.max()
        chosen = block.loc[block.day == recent_day]
        raw = float(chosen.residual.median())
        result.append({"location_id": int(station_id), "recent_day": recent_day,
                       "recent_hours": len(chosen), "raw_median_residual": raw,
                       "level_shift": float(np.clip(raw, -MAX_ABS_SHIFT, MAX_ABS_SHIFT))})
    return pd.DataFrame(result).sort_values("location_id")


def adjust_profile(base_profile: pd.Series, adjustment: pd.DataFrame) -> pd.Series:
    shift = adjustment.set_index("location_id").level_shift
    by_station = base_profile.index.get_level_values("location_id").map(shift).to_numpy()
    return (base_profile + by_station).clip(lower=0)


def validate(train: pd.DataFrame) -> dict:
    folds = []
    for day in VALIDATION_STARTS:
        start = pd.Timestamp(day, tz=IST)
        origin = start - pd.Timedelta(days=2)
        valid = train.loc[(train.hour_start >= start) &
                          (train.hour_start < start + pd.Timedelta(days=2))]
        base_profile, recent = fit(train, origin)
        adjustment = level_adjustment(recent, base_profile)
        profile = adjust_profile(base_profile, adjustment)
        error = valid.pm25.to_numpy() - predict(valid, profile)
        folds.append({"target_start_day": day, "origin_ist": str(origin),
                      "history_rows": len(recent), "scored_rows": len(valid),
                      "station_shifts": dict(zip(adjustment.location_id.astype(str), adjustment.level_shift)),
                      "rmse": float(np.sqrt(np.mean(error ** 2))),
                      "mae": float(np.mean(np.abs(error)))})
    n = sum(f["scored_rows"] for f in folds)
    return {"folds": folds, "rows": n,
            "pooled_rmse": float(np.sqrt(sum(f["scored_rows"] * f["rmse"] ** 2 for f in folds) / n)),
            "pooled_mae": float(sum(f["scored_rows"] * f["mae"] for f in folds) / n)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"recent_level_adjusted_median_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_recent_level_adjusted_median_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("recent_level_adjusted_median")
    train, test, sample, train_path = load()
    # Freeze both hourly shape and station level before November 9.
    origin = pd.Timestamp(EXCLUDED_DAY, tz=IST)
    base_profile, recent = fit(train, origin)
    adjustment = level_adjustment(recent, base_profile)
    profile = adjust_profile(base_profile, adjustment)
    check = validate(train)
    test_predictions = predict(test, profile)
    by_id = pd.Series(test_predictions, index=test.ID)
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(by_id)
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    assert (submission.Target >= 0).all()
    check_dates = test[["ID", "location_id", "hour"]].copy()
    check_dates["pred"] = test_predictions
    assert check_dates.groupby(["location_id", "hour"]).pred.nunique().eq(1).all()

    submission_file = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_file, index=False, float_format="%.6f")
    assert pd.read_csv(submission_file).ID.tolist() == sample.ID.tolist()
    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    counts = recent.groupby(["location_id", "hour"]).pm25.size().rename("history_rows")
    profile_table = profile.rename("prediction_pm25").to_frame().join(
        base_profile.rename("base_prediction_pm25")).join(counts).reset_index()
    profile_table["history_rows"] = profile_table.history_rows.fillna(0).astype(int)
    profile_table = profile_table.merge(stations, on="location_id", how="left", validate="many_to_one")
    profile_table = profile_table.merge(adjustment[["location_id", "level_shift"]],
                                        on="location_id", how="left", validate="many_to_one")
    profile_table.to_csv(run_dir / f"hourly_profile_{stamp}.csv", index=False, float_format="%.6f")
    adjustment.merge(stations, on="location_id", how="left", validate="one_to_one").to_csv(
        run_dir / f"station_adjustments_{stamp}.csv", index=False, float_format="%.6f")
    recent.groupby(["location_id", "day"]).pm25.agg(["size", "mean", "median"]).reset_index().to_csv(
        run_dir / f"training_days_{stamp}.csv", index=False, float_format="%.6f")
    metrics = {"run_timestamp_ist": stamp,
               "method": "seven-day per-station hourly median plus station median residual from latest day with >=12 readings; fixed across all target dates",
               "train_file": train_path.name, "latest_observation_ist": str(train.timestamp_ist.max()),
               "forecast_origin_ist": str(origin), "window_days": WINDOW_DAYS,
               "excluded_history_day": EXCLUDED_DAY, "training_rows": len(recent),
               "station_hour_profiles": len(profile),
               "hours_using_station_median_fallback": int((profile_table.history_rows == 0).sum()),
               "station_adjustments": adjustment.to_dict(orient="records"),
               "minimum_recent_day_hours": MIN_RECENT_DAY_HOURS,
               "maximum_absolute_level_shift": MAX_ABS_SHIFT,
               "smoothing": False, "trend": False,
               "validation": check,
               "validation_limit": "Retrospective by observation timestamp; historical first-publication times are not verified.",
               "submission_rows": len(submission), "prediction_min": float(submission.Target.min()),
               "prediction_max": float(submission.Target.max())}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Train %s; latest observation %s; history %d rows; profile %d station-hours",
             train_path.name, train.timestamp_ist.max(), len(recent), len(profile))
    log.info("Recent station adjustments: %s", adjustment.to_dict(orient="records"))
    log.info("Retrospective two-day-gap RMSE %.3f; MAE %.3f; n=%d",
             check["pooled_rmse"], check["pooled_mae"], check["rows"])
    log.info("Submission %s; %d rows; range %.3f–%.3f",
             submission_file, len(submission), submission.Target.min(), submission.Target.max())
    print(run_dir)


if __name__ == "__main__":
    main()
