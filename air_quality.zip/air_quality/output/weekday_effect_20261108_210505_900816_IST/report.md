# Day-of-week analysis of competition PM2.5

Source: Zindi Train.csv, four CPCB target sensors, 2025-02-19 to 2026-11-02 IST. Valid hourly readings: 47,830; values flagged above 1000 µg/m³ were excluded.

## Answer

The raw weekend mean is 29.56 µg/m³ and raw weekday mean is 30.29 µg/m³ (difference -0.73). After matching station, ISO week, and hour of day, the weekend minus weekday effect is **-0.11 µg/m³** across 83 weeks (approximate 95% week-cluster bootstrap interval **-3.21 to +2.98**). This does not establish a consistent weekend effect.

## Adjusted day pattern

| Day | Relative to station-week-hour mean (µg/m³) | Approximate 95% interval | Weeks |
|---|---:|---:|---:|
| Monday | -0.54 | -2.09 to +1.14 | 73 |
| Tuesday | +0.95 | -1.44 to +3.83 | 74 |
| Wednesday | +0.17 | -1.40 to +1.78 | 78 |
| Thursday | -0.33 | -1.87 to +1.22 | 80 |
| Friday | +0.14 | -1.67 to +1.93 | 81 |
| Saturday | -0.49 | -2.93 to +1.86 | 80 |
| Sunday | +0.89 | -1.32 to +3.31 | 79 |

None of the seven intervals excludes zero. Station-level weekend differences are in `station_weekend_effect.csv`. The analysis is observational: a weekday can coincide with weather, festivals, and changing data coverage. The interval is a week-level bootstrap summary, not a causal estimate.

## Method

- Raw means use all valid hourly competition readings.
- Weekend comparison: within each station × ISO week × hour, require at least three weekday readings and one weekend reading; average hour differences only when a station-week has at least 18 matched hours. Average stations within week, then weeks equally.
- Seven-day comparison: subtract each observed station × ISO week × hour mean when at least four weekdays are observed; retain a station-week-day with at least 18 hours; average stations within week, then weeks equally.
- Bootstrap resamples the resulting week estimates 5,000 times for weekends and 3,000 times for each weekday.
