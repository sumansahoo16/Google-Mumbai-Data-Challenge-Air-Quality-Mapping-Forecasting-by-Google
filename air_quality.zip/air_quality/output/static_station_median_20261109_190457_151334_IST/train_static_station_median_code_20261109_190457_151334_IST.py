"""One fixed PM2.5 prediction per station, using the previous seven calendar days.

Run: python3.11 air_quality/train_static_station_median.py
All submission training, prediction, validation, and output logic lives here.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
WINDOW_DAYS = 7
EXCLUDED_DAY = "2026-11-09"
VALIDATION_STARTS = ("2026-10-17", "2026-10-22", "2026-10-27",
                     "2026-11-01", "2026-11-03", "2026-11-05")


def newest(stem: str) -> Path:
    files = list(INPUT.glob(f"{stem}*.csv"))
    if not files:
        raise FileNotFoundError(f"Missing {stem} CSV in {INPUT}")
    return max(files, key=lambda p: (p.stat().st_mtime_ns, p.name))


def load() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    train_path = newest("Train")
    train = pd.read_csv(train_path)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    train = train.loc[(~train.flag_high_1000.astype(bool)) & train.pm25.notna() &
                      np.isfinite(train.pm25) & (train.pm25 >= 0)].copy()
    train["hour_start"] = train.timestamp_ist - pd.Timedelta(hours=1)
    train["day"] = train.hour_start.dt.strftime("%Y-%m-%d")
    assert not train.duplicated(["location_id", "timestamp_ist"]).any()
    test = pd.read_csv(newest("Test"))
    sample = pd.read_csv(newest("SampleSubmission"))
    assert train.location_id.nunique() == 4
    assert len(test) == len(sample) == 2592
    assert test.ID.is_unique and sample.ID.is_unique and set(test.ID) == set(sample.ID)
    return train, test, sample, train_path


def history(train: pd.DataFrame, origin: pd.Timestamp) -> pd.DataFrame:
    # origin is local midnight. The last included hour starts before origin.
    start = origin - pd.Timedelta(days=WINDOW_DAYS)
    return train.loc[(train.hour_start >= start) & (train.hour_start < origin) &
                     (train.day != EXCLUDED_DAY)].copy()


def station_medians(train: pd.DataFrame, origin: pd.Timestamp) -> tuple[pd.Series, pd.DataFrame]:
    recent = history(train, origin)
    values = recent.groupby("location_id").pm25.median()
    if set(values.index) != set(train.location_id.unique()):
        raise ValueError(f"A station has no observations in the {WINDOW_DAYS}-day window at {origin}")
    return values, recent


def validate(train: pd.DataFrame) -> dict:
    folds = []
    for day in VALIDATION_STARTS:
        start = pd.Timestamp(day, tz=IST)
        origin = start - pd.Timedelta(days=2)
        valid = train.loc[(train.hour_start >= start) &
                          (train.hour_start < start + pd.Timedelta(days=2))]
        values, recent = station_medians(train, origin)
        pred = valid.location_id.map(values).to_numpy()
        error = valid.pm25.to_numpy() - pred
        folds.append({"target_start_day": day, "origin_ist": str(origin),
                      "history_rows": len(recent), "scored_rows": len(valid),
                      "rmse": float(np.sqrt(np.mean(error ** 2))),
                      "mae": float(np.mean(np.abs(error)))})
    n = sum(f["scored_rows"] for f in folds)
    return {"folds": folds, "rows": n,
            "pooled_rmse": float(np.sqrt(sum(f["scored_rows"] * f["rmse"] ** 2 for f in folds) / n)),
            "pooled_mae": float(sum(f["scored_rows"] * f["mae"] for f in folds) / n)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"static_station_median_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_static_station_median_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("static_station_median")
    train, test, sample, train_path = load()
    latest = train.timestamp_ist.max()
    # November 9 is excluded even though early observations have arrived.
    # This origin fixes one forecast level for every target date and hour.
    origin = pd.Timestamp(EXCLUDED_DAY, tz=IST)
    if latest < origin:
        origin = latest.normalize()
    values, recent = station_medians(train, origin)
    check = validate(train)
    log.info("Train: %s; latest observation: %s; clean rows: %d", train_path.name, latest, len(train))
    log.info("Fixed origin: %s; history: %s through %s; rows: %d",
             origin, origin - pd.Timedelta(days=WINDOW_DAYS), origin - pd.Timedelta(hours=1), len(recent))
    log.info("Static station medians: %s", values.round(3).to_dict())
    log.info("Retrospective two-day-gap validation: RMSE %.3f, MAE %.3f, n=%d",
             check["pooled_rmse"], check["pooled_mae"], check["rows"])

    prediction = test.location_id.map(values)
    by_id = pd.Series(prediction.to_numpy(), index=test.ID)
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(by_id)
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    assert (submission.Target >= 0).all()
    assert submission.groupby(test.set_index("ID").loc[submission.ID, "location_id"].to_numpy()).Target.nunique().eq(1).all()
    submission_file = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_file, index=False, float_format="%.6f")
    reloaded = pd.read_csv(submission_file)
    assert reloaded.ID.tolist() == sample.ID.tolist() and reloaded.Target.notna().all()

    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    counts = recent.groupby("location_id").agg(history_hours=("pm25", "size"),
                                                history_days=("day", "nunique"))
    profile = stations.merge(values.rename("prediction_pm25"), left_on="location_id", right_index=True)
    profile = profile.merge(counts, left_on="location_id", right_index=True).sort_values("location_id")
    profile.to_csv(run_dir / f"station_profile_{stamp}.csv", index=False, float_format="%.6f")
    daily = recent.groupby(["location_id", "day"]).pm25.agg(["size", "mean", "median"])
    daily.reset_index().to_csv(run_dir / f"training_days_{stamp}.csv", index=False, float_format="%.6f")
    metrics = {"run_timestamp_ist": stamp, "method": "one station-wise median of all valid hourly observations in the previous seven calendar days",
               "train_file": train_path.name, "latest_observation_ist": str(latest),
               "forecast_origin_ist": str(origin), "window_days": WINDOW_DAYS,
               "excluded_history_day": EXCLUDED_DAY, "training_rows": len(recent),
               "station_profile": profile.to_dict(orient="records"),
               "validation": check,
               "validation_limit": "Retrospective by observation timestamp; historical first-publication times are not verified.",
               "submission_rows": len(submission), "distinct_predictions": int(submission.Target.nunique())}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Wrote %s (%d rows, %d distinct prediction levels)",
             submission_file, len(submission), submission.Target.nunique())
    print(run_dir)


if __name__ == "__main__":
    main()
