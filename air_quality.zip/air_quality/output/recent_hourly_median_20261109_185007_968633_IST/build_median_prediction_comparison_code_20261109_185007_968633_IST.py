"""Build an offline HTML and CSV of median predictions versus observed PM2.5.

Run with --run-dir pointing to a recent_hourly_median_<timestamp> output folder.
Training and submission generation remain entirely in train_recent_hourly_median.py.
"""

from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input"
IST = ZoneInfo("Asia/Kolkata")
START = pd.Timestamp("2026-11-05", tz=IST)
END = pd.Timestamp("2026-11-14", tz=IST)


HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mumbai PM2.5 | Predicted vs observed, 5–13 November 2026</title>
<style>
:root{--bg:#f6f8fb;--ink:#18243a;--muted:#526078;--card:#fff;--line:#dbe3ee;--pred:#2563eb;--actual:#dc4a37;--accent:#0d7a70}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
main{max-width:1240px;margin:auto;padding:26px 22px 55px}h1{font-size:27px;line-height:1.2;margin:0 0 7px}h2{font-size:18px;margin:0 0 12px}p{margin:0 0 10px}.sub{color:var(--muted)}
.top{display:flex;justify-content:space-between;gap:18px;align-items:start;margin-bottom:20px}.stamp{color:var(--muted);font-size:12px;white-space:nowrap}
.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:18px}.stat,.panel{background:var(--card);border:1px solid var(--line);border-radius:12px;box-shadow:0 1px 3px #24344b0a}.stat{padding:14px 17px}.stat strong{display:block;font-size:23px}.stat span{color:var(--muted);font-size:13px}
.panel{padding:18px;margin:16px 0}.note{background:#eef5f7;border-left:4px solid var(--accent);padding:11px 13px;border-radius:7px;color:#274450;margin:12px 0 18px}
.controls{display:flex;gap:13px;align-items:end;flex-wrap:wrap;margin:4px 0 14px}label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:var(--muted)}select{font:inherit;padding:7px 9px;border:1px solid #b9c8d9;border-radius:7px;background:white;color:var(--ink)}
.legend{display:flex;gap:17px;align-items:center;color:var(--muted);font-size:13px;margin:0 0 9px}.swatch{display:inline-block;width:19px;height:3px;vertical-align:middle;margin-right:6px}.swatch.pred{background:var(--pred)}.swatch.actual{background:var(--actual)}
.chart{margin:14px 0 22px}.chart:last-child{margin-bottom:0}.chart h3{font-size:15px;margin:0 0 4px}.chart p{font-size:12px;color:var(--muted);margin:0 0 3px}.chart svg{display:block;width:100%;height:auto;max-height:235px}.chart text{fill:var(--muted);font:11px system-ui,sans-serif}.grid{stroke:#e5ebf2;stroke-width:1}.axis{stroke:#aebbc9;stroke-width:1}.pred-line{fill:none;stroke:var(--pred);stroke-width:2.3}.pred-hit{fill:transparent;stroke:none}.actual-line{fill:none;stroke:var(--actual);stroke-width:2}.actual-dot{fill:var(--actual);stroke:#fff;stroke-width:.7}.clipped{fill:var(--actual)}
.tablewrap{max-height:620px;overflow:auto;border:1px solid var(--line);border-radius:8px}table{border-collapse:collapse;width:100%;font-size:13px}thead th{position:sticky;top:0;background:#edf2f8;z-index:1;text-align:left}th,td{padding:7px 9px;border-bottom:1px solid #e7edf3;white-space:nowrap}td.num{text-align:right;font-variant-numeric:tabular-nums}td.missing{color:#8a95a5}tr:hover{background:#f6f9fe}.foot{font-size:12px;color:var(--muted);margin-top:12px}
@media(max-width:700px){main{padding:17px 12px}.top{display:block}.stamp{margin-top:8px}.stats{grid-template-columns:1fr}.stat{padding:9px 12px}.stat strong{font-size:19px}.panel{padding:12px}.tablewrap{overflow:auto}}
</style>
</head>
<body>
<main>
  <div class="top"><div><h1>Mumbai PM2.5: predicted vs observed</h1><p class="sub">Hourly concentration, 5–13 November 2026 · µg/m³ · Asia/Kolkata time</p></div><div class="stamp">Run: __STAMP__</div></div>
  <div class="stats"><div class="stat"><strong id="predCount"></strong><span>Predictions in this view</span></div><div class="stat"><strong id="actualCount"></strong><span>Hours with observed values</span></div><div class="stat"><strong id="missingCount"></strong><span>Hours awaiting observations</span></div></div>
  <div class="note">The full submission includes dates through 20 November. The data dictionary identifies 11–12 November as private evaluation. Actual values currently end on 9 November; blank cells are unknown, not zero. The 9 November readings are displayed for comparison but were excluded from the median forecast history.</div>
  <section class="panel"><h2>Hourly lines by station</h2><div class="controls"><label>Visible dates<select id="rangeSelect"><option value="all">5–13 November</option>__DAY_OPTIONS__</select></label><label>Y axis maximum<select id="scaleSelect"><option value="120">120 µg/m³ — focus</option><option value="__FULL_MAX__">__FULL_MAX__ µg/m³ — all values</option></select></label></div><div class="legend"><span><i class="swatch pred"></i>Prediction, continuous</span><span><i class="swatch actual"></i>Observed, dots and segments</span></div><div id="charts"></div><p class="foot">▲ means an observed value exceeds the selected Y axis. Hover over an observed dot or prediction line point for its exact value. Dates on the X axis mark the start of the target hour.</p></section>
  <section class="panel"><h2>All hourly predictions and available actuals</h2><div class="controls"><label>Station<select id="stationSelect"><option value="all">All stations</option>__STATION_OPTIONS__</select></label><label>Day<select id="tableDay"><option value="all">All days</option>__DAY_OPTIONS__</select></label><span id="visibleRows" class="sub"></span></div><div class="tablewrap"><table><thead><tr><th>Target hour start (IST)</th><th>Station</th><th>Prediction</th><th>Actual</th><th>Actual − prediction</th></tr></thead><tbody id="rows"></tbody></table></div><p class="foot">Predictions are from the seven-calendar-day, station-specific hourly median method. A day needs at least 12 observed hours to enter the profile; flagged days are removed using a robust daily-median rule. Source: __TRAIN_FILE__ and __TEST_FILE__. Download the companion CSV for all rows.</p></section>
</main>
<script>
const records=__DATA__;
const stations=__STATIONS__;
const byId=Object.fromEntries(stations.map(s=>[s.id,s.name]));
document.getElementById('predCount').textContent=records.length.toLocaleString();
document.getElementById('actualCount').textContent=records.filter(r=>r.actual!==null).length.toLocaleString();
document.getElementById('missingCount').textContent=records.filter(r=>r.actual===null).length.toLocaleString();
const fmt=v=>v===null?'—':Number(v).toFixed(2);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SVG_NS='http://www.w3.org/2000/svg';
function add(parent,tag,attrs={},text=''){
  const el=document.createElementNS(SVG_NS,tag);
  for(const [k,v] of Object.entries(attrs))el.setAttribute(k,v);
  if(text)el.textContent=text;parent.appendChild(el);return el;
}
function linePath(points){return points.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ')}
function draw(){
  const day=document.getElementById('rangeSelect').value;
  const ymax=Number(document.getElementById('scaleSelect').value);
  const shown=day==='all'?records:records.filter(r=>r.day===day);
  const start=Date.parse(day==='all'?'2026-11-05T00:00:00+05:30':day+'T00:00:00+05:30');
  const end=Date.parse(day==='all'?'2026-11-14T00:00:00+05:30':new Date(start+86400000).toISOString());
  const endMs=day==='all'?end:start+86400000;
  const host=document.getElementById('charts');host.innerHTML='';
  const W=1060,H=214,L=56,R=14,T=17,B=36,plotW=W-L-R,plotH=H-T-B;
  const x=t=>L+(t-start)/(endMs-start)*plotW;
  const y=v=>T+plotH-Math.min(Math.max(v,0),ymax)/ymax*plotH;
  for(const station of stations){
    const data=shown.filter(r=>r.location_id===station.id);
    const wrap=document.createElement('div');wrap.className='chart';
    const h=document.createElement('h3');h.textContent=station.name;wrap.appendChild(h);
    const detail=document.createElement('p');detail.textContent=data.filter(r=>r.actual!==null).length+' observed of '+data.length+' target hours';wrap.appendChild(detail);
    const svg=add(wrap,'svg',{viewBox:`0 0 ${W} ${H}`,role:'img','aria-label':station.name+' hourly predicted and observed PM2.5'});
    for(const tick of [0,Math.round(ymax/2),ymax]){
      add(svg,'line',{x1:L,y1:y(tick),x2:W-R,y2:y(tick),class:'grid'});
      add(svg,'text',{x:L-8,y:y(tick)+4,'text-anchor':'end'},String(tick));
    }
    const tickHours=day==='all'?24:6;
    const totalHours=day==='all'?216:24;
    for(let hour=0;hour<=totalHours;hour+=tickHours){
      const t=start+hour*3600000;const xx=x(t);
      add(svg,'line',{x1:xx,y1:T,x2:xx,y2:T+plotH,class:'grid'});
      const d=new Date(t+19800000);
      const label=day==='all'?`${d.getUTCDate()} Nov`:`${String(d.getUTCHours()).padStart(2,'0')}:00`;
      add(svg,'text',{x:xx,y:H-10,'text-anchor':hour===0?'start':hour===totalHours?'end':'middle'},label);
    }
    add(svg,'line',{x1:L,y1:T+plotH,x2:W-R,y2:T+plotH,class:'axis'});
    const predicted=data.map(r=>[x(Date.parse(r.time)),y(r.pred)]);
    add(svg,'path',{d:linePath(predicted),class:'pred-line'});
    for(const r of data){
      const hit=add(svg,'circle',{cx:x(Date.parse(r.time)),cy:y(r.pred),r:4,class:'pred-hit'});
      add(hit,'title',{},`${r.time_label} · Prediction ${fmt(r.pred)} µg/m³`);
    }
    let segment=[];let prev=null;
    function flush(){if(segment.length>1)add(svg,'path',{d:linePath(segment),class:'actual-line'});segment=[]}
    for(const r of data){
      if(r.actual===null){flush();prev=null;continue}
      const t=Date.parse(r.time);
      if(prev!==null&&t-prev!==3600000)flush();
      segment.push([x(t),y(r.actual)]);prev=t;
      const clipped=r.actual>ymax;
      const mark=clipped?add(svg,'path',{d:`M ${x(t)-4} ${T+8} L ${x(t)} ${T} L ${x(t)+4} ${T+8} Z`,class:'clipped'}):add(svg,'circle',{cx:x(t),cy:y(r.actual),r:3.1,class:'actual-dot'});
      add(mark,'title',{},`${r.time_label} · Actual ${fmt(r.actual)} · Prediction ${fmt(r.pred)} µg/m³${clipped?' (above axis maximum)':''}`);
    }
    flush();host.appendChild(wrap);
  }
}
function drawTable(){
  const station=document.getElementById('stationSelect').value;
  const day=document.getElementById('tableDay').value;
  const selected=records.filter(r=>(station==='all'||String(r.location_id)===station)&&(day==='all'||r.day===day));
  document.getElementById('visibleRows').textContent=selected.length+' rows';
  document.getElementById('rows').innerHTML=selected.map(r=>`<tr><td>${esc(r.time_label)}</td><td>${esc(byId[r.location_id])}</td><td class="num">${fmt(r.pred)}</td><td class="num ${r.actual===null?'missing':''}">${fmt(r.actual)}</td><td class="num ${r.actual===null?'missing':''}">${r.actual===null?'—':fmt(r.actual-r.pred)}</td></tr>`).join('');
}
document.getElementById('rangeSelect').addEventListener('change',draw);
document.getElementById('scaleSelect').addEventListener('change',draw);
document.getElementById('stationSelect').addEventListener('change',drawTable);
document.getElementById('tableDay').addEventListener('change',drawTable);
draw();drawTable();
</script>
</body></html>'''


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    submission_files = list(run_dir.glob("submission_*.csv"))
    if len(submission_files) != 1:
        raise ValueError("Expected one submission CSV in the run folder")
    submission = pd.read_csv(submission_files[0])
    train_file = max(INPUT.glob("Train*.csv"), key=lambda p: (p.stat().st_mtime_ns, p.name))
    test_file = max(INPUT.glob("Test*.csv"), key=lambda p: (p.stat().st_mtime_ns, p.name))
    train = pd.read_csv(train_file)
    test = pd.read_csv(test_file)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["target_end_ist"] = pd.to_datetime(test.target_end_ist, utc=True).dt.tz_convert(IST)
    assert not train.duplicated(["location_id", "timestamp_ist"]).any()
    assert test.ID.is_unique and submission.ID.is_unique and set(test.ID) == set(submission.ID)
    train = train.loc[~train.flag_high_1000.astype(bool), ["location_id", "timestamp_ist", "pm25"]]
    paired = test.loc[(test.target_start_ist >= START) & (test.target_start_ist < END)].copy()
    paired = paired.merge(submission.rename(columns={"Target": "prediction_pm25"}), on="ID", how="left", validate="one_to_one")
    paired = paired.merge(train.rename(columns={"timestamp_ist": "target_end_ist", "pm25": "actual_pm25"}),
                          on=["location_id", "target_end_ist"], how="left", validate="one_to_one")
    paired = paired.sort_values(["target_start_ist", "location_id"]).reset_index(drop=True)
    assert len(paired) == 9 * 24 * 4 and paired.prediction_pm25.notna().all()
    station_file = max(INPUT.glob("Stations*.csv"), key=lambda p: (p.stat().st_mtime_ns, p.name))
    stations = pd.read_csv(station_file)[["location_id", "station_name"]].sort_values("location_id")
    station_names = dict(zip(stations.location_id, stations.station_name))
    paired["station_name"] = paired.location_id.map(station_names)
    paired["error_actual_minus_prediction"] = paired.actual_pm25 - paired.prediction_pm25
    stamp = run_dir.name.removeprefix("recent_hourly_median_")
    cols = ["ID", "location_id", "station_name", "target_start_ist", "target_end_ist",
            "prediction_pm25", "actual_pm25", "error_actual_minus_prediction"]
    csv_file = run_dir / f"predicted_vs_actual_20261105_20261113_{stamp}.csv"
    paired[cols].to_csv(csv_file, index=False, float_format="%.6f")
    rows = []
    for row in paired.itertuples(index=False):
        actual = None if pd.isna(row.actual_pm25) else round(float(row.actual_pm25), 3)
        rows.append({"location_id": int(row.location_id),
                     "time": row.target_start_ist.isoformat(),
                     "time_label": row.target_start_ist.strftime("%d Nov %Y %H:%M"),
                     "day": row.target_start_ist.strftime("%Y-%m-%d"),
                     "pred": round(float(row.prediction_pm25), 3), "actual": actual})
    station_data = [{"id": int(row.location_id), "name": row.station_name} for row in stations.itertuples(index=False)]
    full_max = int(np.ceil(max(paired.actual_pm25.max(), paired.prediction_pm25.max()) / 50) * 50)
    day_options = "".join(f'<option value="2026-11-{day:02d}">{day} November</option>' for day in range(5, 14))
    station_options = "".join(f'<option value="{s["id"]}">{s["name"]}</option>' for s in station_data)
    html = (HTML.replace("__STAMP__", stamp).replace("__DAY_OPTIONS__", day_options)
            .replace("__STATION_OPTIONS__", station_options).replace("__FULL_MAX__", str(full_max))
            .replace("__TRAIN_FILE__", train_file.name).replace("__TEST_FILE__", test_file.name)
            .replace("__STATIONS__", json.dumps(station_data, ensure_ascii=False))
            .replace("__DATA__", json.dumps(rows, ensure_ascii=False).replace("</", "<\\/")))
    html_file = run_dir / f"predicted_vs_actual_20261105_20261113_{stamp}.html"
    html_file.write_text(html, encoding="utf-8")
    shutil.copy2(__file__, run_dir / f"build_median_prediction_comparison_code_{stamp}.py")
    counts = paired.assign(day=paired.target_start_ist.dt.strftime("%Y-%m-%d")).groupby("day").actual_pm25.count()
    summary = {"run_timestamp_ist": stamp, "train_file": train_file.name, "test_file": test_file.name,
               "submission_file": submission_files[0].name, "view_start": str(START), "view_end_exclusive": str(END),
               "predicted_rows": len(paired), "observed_rows": int(paired.actual_pm25.notna().sum()),
               "observed_by_day": counts.to_dict(), "excluded_from_model_history": ["2026-11-09"],
               "test_last_target_start_ist": str(test.target_start_ist.max()),
               "private_evaluation_dates": ["2026-11-11", "2026-11-12"]}
    (run_dir / f"comparison_summary_{stamp}.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(html_file)
    print(csv_file)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
