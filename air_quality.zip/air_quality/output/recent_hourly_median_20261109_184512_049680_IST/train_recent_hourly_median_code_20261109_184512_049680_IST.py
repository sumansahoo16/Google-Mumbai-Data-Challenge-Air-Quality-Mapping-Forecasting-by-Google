"""One statistical Mumbai PM2.5 forecast: recent station/hour medians.

Run: python3.11 air_quality/train_recent_hourly_median.py
The script selects a 7- or 14-day window on past two-day forecasts, removes
low-coverage and robustly flagged days, predicts every test ID, and saves a
timestamped submission, diagnostics, log, and exact copy of this code.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
MIN_HOURS_PER_DAY = 12
WINDOW_CANDIDATES = (3, 5, 7, 10, 14)
EXCLUDED_HISTORY_DATES = frozenset({date(2026, 11, 9)})
OUTLIER_MAD_MULTIPLIER = 3.5
MIN_OUTLIER_SCALE = 5.0  # µg/m³: avoid calling tiny normal changes outliers.
VALIDATION_STARTS = ("2026-10-17", "2026-10-22", "2026-10-27",
                     "2026-11-01", "2026-11-03", "2026-11-05")


def input_file(stem: str) -> Path:
    matches = sorted(INPUT.glob(f"{stem}*.csv"))
    if not matches:
        raise FileNotFoundError(f"No {stem} CSV found in {INPUT}")
    # Train is refreshed in numbered files; Test and SampleSubmission are fixed.
    return max(matches, key=lambda path: (path.stat().st_mtime_ns, path.name))


def load_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    train_path = input_file("Train")
    train = pd.read_csv(train_path)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    train = train.loc[(~train.flag_high_1000.astype(bool)) &
                      train.pm25.notna() & np.isfinite(train.pm25) & (train.pm25 >= 0)].copy()
    train["hour_start"] = train.timestamp_ist - pd.Timedelta(hours=1)
    train["day"] = train.hour_start.dt.date
    train["hour"] = train.hour_start.dt.hour
    train = train.sort_values("timestamp_ist")
    test = pd.read_csv(input_file("Test"))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["day"] = test.target_start_ist.dt.date
    test["hour"] = test.target_start_ist.dt.hour
    sample = pd.read_csv(input_file("SampleSubmission"))
    assert train.location_id.nunique() == 4
    assert len(test) == len(sample) == 2592
    assert test.ID.is_unique and sample.ID.is_unique and set(test.ID) == set(sample.ID)
    return train, test, sample, train_path


def station_profile(station: pd.DataFrame, cutoff: pd.Timestamp,
                    window_days: int) -> tuple[dict[int, float], float, dict]:
    recent = station.loc[(station.timestamp_ist <= cutoff) &
                         (station.hour_start > cutoff - pd.Timedelta(days=window_days)) &
                         (~station.day.isin(EXCLUDED_HISTORY_DATES))].copy()
    daily = recent.groupby("day").pm25.agg(["size", "median"])
    eligible = daily.loc[daily["size"] >= MIN_HOURS_PER_DAY].copy()
    if eligible.empty:
        # A station can have a long outage; retain a defined fallback.
        eligible = daily.loc[daily["size"] >= 6].copy()
    if eligible.empty:
        eligible = daily.copy()
    if eligible.empty:
        raise ValueError(f"No station history before {cutoff}")

    centre = float(eligible["median"].median())
    mad = float((eligible["median"] - centre).abs().median())
    scale = max(1.4826 * mad, MIN_OUTLIER_SCALE)
    outlier = (eligible["median"] - centre).abs() > OUTLIER_MAD_MULTIPLIER * scale
    # Keep at least three days so an isolated high day cannot erase the profile.
    if len(eligible) - int(outlier.sum()) < 3:
        outlier[:] = False
    kept_days = eligible.index[~outlier]
    kept = recent.loc[recent.day.isin(kept_days)]
    hour_medians = {int(hour): float(value) for hour, value in
                    kept.groupby("hour").pm25.median().items()}
    station_median = float(kept.pm25.median())
    diagnostics = {"cutoff": str(cutoff), "window_days": window_days,
                   "eligible_days": len(eligible), "kept_days": len(kept_days),
                   "kept_hours": len(kept),
                   "excluded_low_coverage_days": [str(day) for day in daily.index.difference(eligible.index)],
                   "outlier_days": [str(day) for day in eligible.index[outlier]],
                   "station_median": station_median,
                   "hours_with_profile": len(hour_medians)}
    return hour_medians, station_median, diagnostics


def predict_block(train: pd.DataFrame, rows: pd.DataFrame, cutoff: pd.Timestamp,
                  window_days: int) -> tuple[np.ndarray, list[dict]]:
    predictions = pd.Series(index=rows.index, dtype=float)
    details = []
    for station_id, block in rows.groupby("location_id", sort=False):
        station = train.loc[train.location_id == station_id]
        hourly, fallback, info = station_profile(station, cutoff, window_days)
        predictions.loc[block.index] = [hourly.get(int(hour), fallback) for hour in block.hour]
        info["location_id"] = int(station_id)
        details.append(info)
    return predictions.loc[rows.index].to_numpy(), details


def validate(train: pd.DataFrame, window_days: int, gap_days: int) -> dict:
    folds = []
    for date in VALIDATION_STARTS:
        start = pd.Timestamp(date, tz=IST)
        end = start + pd.Timedelta(days=2)
        cutoff = start - pd.Timedelta(days=gap_days)
        valid = train.loc[(train.hour_start >= start) & (train.hour_start < end)]
        if valid.empty:
            continue
        pred, _ = predict_block(train, valid, cutoff, window_days)
        error = valid.pm25.to_numpy() - pred
        folds.append({"start": date, "origin": str(cutoff), "rows": len(valid),
                      "rmse": float(np.sqrt(np.mean(error ** 2))),
                      "mae": float(np.mean(np.abs(error)))})
    count = sum(fold["rows"] for fold in folds)
    return {"gap_days": gap_days, "window_days": window_days, "folds": folds,
            "rows": count,
            "pooled_rmse": float(np.sqrt(sum(f["rows"] * f["rmse"] ** 2 for f in folds) / count)),
            "pooled_mae": float(sum(f["rows"] * f["mae"] for f in folds) / count)}


def pooled_rmse(folds: list[dict]) -> float:
    count = sum(fold["rows"] for fold in folds)
    return float(np.sqrt(sum(fold["rows"] * fold["rmse"] ** 2 for fold in folds) / count))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"recent_hourly_median_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_recent_hourly_median_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("hourly_median")
    train, test, sample, train_path = load_data()
    log.info("Run %s; input %s; %d clean rows; latest observation %s",
             stamp, train_path.name, len(train), train.timestamp_ist.max())
    backtests = {str(days): validate(train, days, gap_days=2) for days in WINDOW_CANDIDATES}
    for days, result in backtests.items():
        log.info("%s-day window: two-day-gap RMSE %.3f, MAE %.3f over %d observations",
                 days, result["pooled_rmse"], result["pooled_mae"], result["rows"])
    # Choose with October folds, leaving the November folds as a separate check.
    chosen_days = min(WINDOW_CANDIDATES, key=lambda days:
                      pooled_rmse(backtests[str(days)]["folds"][:3]))
    selection_rmse = {str(days): pooled_rmse(backtests[str(days)]["folds"][:3])
                      for days in WINDOW_CANDIDATES}
    november_check_rmse = {str(days): pooled_rmse(backtests[str(days)]["folds"][3:])
                           for days in WINDOW_CANDIDATES}
    ten_day = validate(train, chosen_days, gap_days=10)
    log.info("Chosen %d-day window from October RMSE %s; November holdout RMSE %s",
             chosen_days, selection_rmse, november_check_rmse)
    log.info("Ten-day-gap diagnostic RMSE %.3f over %d observations",
             ten_day["pooled_rmse"], ten_day["rows"])

    latest = train.timestamp_ist.max()
    prediction = pd.Series(index=test.index, dtype=float)
    profiles = []
    for day, block in test.groupby("day", sort=True):
        cutoff = min(latest, pd.Timestamp(day, tz=IST) - pd.Timedelta(days=2))
        values, details = predict_block(train, block, cutoff, chosen_days)
        prediction.loc[block.index] = values
        for detail in details:
            detail["target_day"] = str(day)
        profiles.extend(details)
    by_id = pd.Series(prediction.to_numpy(), index=test.ID)
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(by_id)
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    assert (submission.Target >= 0).all()
    submission_file = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_file, index=False, float_format="%.6f")
    reloaded = pd.read_csv(submission_file)
    assert reloaded.ID.tolist() == sample.ID.tolist() and reloaded.Target.notna().all()
    pd.DataFrame(profiles).to_csv(run_dir / f"station_day_profiles_{stamp}.csv", index=False)
    metrics = {"run_timestamp_ist": stamp, "method": "station-wise recent hourly median",
               "train_file": train_path.name, "clean_rows": len(train),
               "latest_observation_ist": str(latest), "chosen_window_days": chosen_days,
               "excluded_history_dates": [str(day) for day in sorted(EXCLUDED_HISTORY_DATES)],
               "minimum_hours_per_day": MIN_HOURS_PER_DAY,
               "outlier_day_rule": f"abs(daily median - station window median) > {OUTLIER_MAD_MULTIPLIER} * max(1.4826*MAD, {MIN_OUTLIER_SCALE})",
               "selection_october_rmse": selection_rmse,
               "november_holdout_rmse": november_check_rmse,
               "two_day_gap_backtests": backtests, "ten_day_gap_diagnostic": ten_day,
               "submission_rows": len(submission),
               "prediction_min": float(submission.Target.min()),
               "prediction_median": float(submission.Target.median()),
               "prediction_max": float(submission.Target.max())}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Submission %s; %d rows; range %.3f to %.3f",
             submission_file, len(submission), submission.Target.min(), submission.Target.max())


if __name__ == "__main__":
    main()
