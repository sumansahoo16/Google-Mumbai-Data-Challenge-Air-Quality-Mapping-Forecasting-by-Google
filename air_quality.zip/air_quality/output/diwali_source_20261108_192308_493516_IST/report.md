# Diwali 2025: competition-source PM2.5

Source: `input/Train (2).csv`, four CPCB-derived Mumbai PM2.5 stations. All times IST; timestamps mark the end of each hour. Units: µg/m³.
Diwali was 20 October 2025. 3 flagged readings above 1,000 µg/m³ were excluded from this window.

| Window | Observed/possible station-hours | Coverage | Median PM2.5 | Change vs Oct 13–17 |
|---|---:|---:|---:|---:|
| baseline_oct13_17 | 430/480 | 89.6% | 52.8 | +0.0% |
| leadup_oct18_19 | 139/192 | 72.4% | 66.9 | +26.7% |
| diwali_oct20 | 58/96 | 60.4% | 97.0 | +83.5% |
| next_day_oct21 | 88/96 | 91.7% | 92.1 | +74.3% |
| days2_3_oct22_23 | 178/192 | 92.7% | 51.0 | -3.4% |
| days4_5_oct24_25 | 182/192 | 94.8% | 18.3 | -65.4% |

## Interpretation

The rise began before Diwali: Oct 18–19 was elevated relative to Oct 13–17. Oct 20 and Oct 21 remained elevated; levels declined by Oct 22–23 and were lower by Oct 24–25.

## Same-station, same-hour baseline

| Window | Matched observations | Observed median | Matched baseline median | Ratio |
|---|---:|---:|---:|---:|
| baseline_oct13_17 | 430 | 52.8 | 56.1 | 0.94× |
| leadup_oct18_19 | 139 | 66.9 | 56.7 | 1.18× |
| diwali_oct20 | 58 | 97.0 | 57.8 | 1.68× |
| next_day_oct21 | 88 | 92.1 | 55.5 | 1.66× |
| days2_3_oct22_23 | 178 | 51.0 | 55.8 | 0.91× |
| days4_5_oct24_25 | 182 | 18.3 | 56.0 | 0.33× |

These are observed associations, not a causal estimate of fireworks. Weather and other emissions can change at the same time, and station-hour coverage varies by window.
See `daily_station.csv`, `period_station.csv`, `hourly_festival.csv`, and `matched_hour_baseline.csv` for detail.
