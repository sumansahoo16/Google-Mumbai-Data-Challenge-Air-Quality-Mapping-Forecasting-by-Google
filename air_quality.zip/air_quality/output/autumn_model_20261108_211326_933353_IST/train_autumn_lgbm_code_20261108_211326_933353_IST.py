"""Train an October-November LightGBM model for the Mumbai PM2.5 submission.

Run with: python3.11 air_quality/train_autumn_lgbm.py
Every run writes a timestamped submission, log, metrics, model, and exact code copy.
Only October and November observations are used to fit models or build history features.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import root_mean_squared_error


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent  # Exact code copies inside output/model_<timestamp> also run.
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
GAP_DAYS = 10
TRAIN_MONTHS = (10, 11)
SEED = 42
PARAMS = dict(n_estimators=650, learning_rate=.035, num_leaves=15,
              max_depth=-1, min_child_samples=80, subsample=1.0,
              colsample_bytree=.85, reg_lambda=5.0, random_state=SEED,
              n_jobs=4, verbosity=-1)


def input_file(stem: str) -> Path:
    matches = sorted(INPUT.glob(f"{stem}*.csv"))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one {stem} CSV in {INPUT}; found {matches}")
    return matches[0]


def historical_features(history: pd.DataFrame, rows: pd.DataFrame) -> pd.DataFrame:
    """Join station history available at least GAP_DAYS before each target start."""
    h = history[["location_id", "timestamp_ist", "pm25"]].sort_values(["location_id", "timestamp_ist"])
    groups = []
    for location_id, group in h.groupby("location_id", sort=False):
        series = group.set_index("timestamp_ist")["pm25"]
        frame = pd.DataFrame({"location_id": location_id, "history_time": series.index,
                              "last_pm25": series.to_numpy()})
        for days in (3, 7, 14, 30):
            roll = series.rolling(f"{days}D", min_periods=1)
            frame[f"mean_{days}d"] = roll.mean().to_numpy()
            frame[f"count_{days}d"] = roll.count().to_numpy()
        frame["median_30d"] = series.rolling("30D", min_periods=1).median().to_numpy()
        groups.append(frame)
    lookup = pd.concat(groups, ignore_index=True).sort_values("history_time")
    query = rows[["location_id", "target_start_ist"]].copy()
    query["cutoff"] = query.target_start_ist - pd.Timedelta(days=GAP_DAYS)
    query["row_number"] = np.arange(len(query))
    query = query.sort_values("cutoff")
    joined = pd.merge_asof(query, lookup, by="location_id", left_on="cutoff",
                           right_on="history_time", direction="backward")
    joined = joined.sort_values("row_number").reset_index(drop=True)
    out = joined.drop(columns=["location_id", "target_start_ist", "cutoff", "row_number", "history_time"])
    out["history_age_hours"] = (joined.cutoff - joined.history_time).dt.total_seconds() / 3600
    return out


def make_features(rows: pd.DataFrame, history: pd.DataFrame, stations: pd.DataFrame) -> pd.DataFrame:
    time = rows.target_start_ist.dt
    day = time.dayofyear.to_numpy()
    hour = time.hour.to_numpy()
    features = pd.DataFrame({
        "location_id": rows.location_id.astype("category"),
        "hour": hour,
        "day_of_week": time.dayofweek.to_numpy(),
        "month": time.month.to_numpy(),
        "day_of_year": day,
        "hour_sin": np.sin(2 * np.pi * hour / 24),
        "hour_cos": np.cos(2 * np.pi * hour / 24),
        "year_sin": np.sin(2 * np.pi * day / 365.25),
        "year_cos": np.cos(2 * np.pi * day / 365.25),
    })
    coordinates = rows[["location_id"]].merge(
        stations[["location_id", "latitude", "longitude"]], on="location_id", how="left")
    features["latitude"] = coordinates.latitude.to_numpy()
    features["longitude"] = coordinates.longitude.to_numpy()
    historical = historical_features(history, rows)
    for column in historical:
        features[column] = historical[column].to_numpy()
    return features


def build_model() -> lgb.LGBMRegressor:
    return lgb.LGBMRegressor(**PARAMS)


def score(actual: pd.Series, prediction: np.ndarray) -> float:
    return float(root_mean_squared_error(actual.to_numpy(), np.maximum(prediction, 0)))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"autumn_model_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_autumn_lgbm_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("mumbai")
    log.info("Run: %s", stamp)
    log.info("Python %s; pandas %s; LightGBM %s", sys.version.split()[0], pd.__version__, lgb.__version__)
    log.info("Parameters: %s; historical feature gap: %d days", PARAMS, GAP_DAYS)
    train = pd.read_csv(input_file("Train"))
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert("Asia/Kolkata")
    train["available_at"] = pd.to_datetime(train.available_at, utc=True, format="mixed").dt.tz_convert("Asia/Kolkata")
    test = pd.read_csv(input_file("Test"), parse_dates=["target_start_ist", "target_end_ist"])
    for column in ("target_start_ist", "target_end_ist"):
        test[column] = pd.to_datetime(test[column], utc=True).dt.tz_convert("Asia/Kolkata")
    sample = pd.read_csv(input_file("SampleSubmission"))
    stations = pd.read_csv(input_file("Stations"))
    train["target_start_ist"] = train.timestamp_ist - pd.Timedelta(hours=1)
    assert not train.duplicated(["location_id", "timestamp_ist"]).any()
    assert np.isfinite(train.pm25).all() and (train.pm25 >= 0).all()
    assert len(test) == len(sample) and test.ID.is_unique and sample.ID.is_unique
    assert set(test.ID) == set(sample.ID)
    clean = train.loc[~train.flag_high_1000.astype(bool)].copy()
    seasonal = clean.loc[clean.timestamp_ist.dt.month.isin(TRAIN_MONTHS)].copy()
    log.info("Seasonal fit months: %s; rows: %d; excluded other-month rows: %d; "
             "excluded flagged spikes: %d; latest seasonal observation: %s",
             TRAIN_MONTHS, len(seasonal), len(clean) - len(seasonal),
             len(train) - len(clean), seasonal.timestamp_ist.max())

    # Each fold simulates a two-day forecast made ten days before its first target.
    # November 2025 supplies a direct calendar-season check; October 2026
    # supplies a recent-year check. Validation targets never enter the fit.
    fold_starts = ["2025-11-11", "2026-10-17", "2026-10-22", "2026-10-27"]
    fold_results = []
    for fold_start in fold_starts:
        start = pd.Timestamp(fold_start, tz=IST)
        end = start + pd.Timedelta(days=2)
        origin = start - pd.Timedelta(days=GAP_DAYS)
        # available_at is an imperfect provenance timestamp, but filtering it here
        # prevents known later-retrieved labels from entering historical folds.
        fit_rows = seasonal.loc[(seasonal.timestamp_ist <= origin) & (seasonal.available_at <= origin)]
        unavailable_rows = int(((seasonal.timestamp_ist <= origin) & (seasonal.available_at > origin)).sum())
        valid = seasonal.loc[(seasonal.target_start_ist >= start) & (seasonal.target_start_ist < end)]
        if valid.empty:
            log.warning("No labels for validation period %s", fold_start)
            continue
        x_fit = make_features(fit_rows, fit_rows, stations)
        x_valid = make_features(valid, fit_rows, stations)
        model = build_model()
        model.fit(x_fit, fit_rows.pm25)
        prediction = np.maximum(model.predict(x_valid), 0)
        baseline = x_valid["mean_30d"].fillna(fit_rows.pm25.median()).to_numpy()
        result = {"start": fold_start, "end_exclusive": str(end), "origin": str(origin),
                  "train_rows": len(fit_rows), "excluded_later_available_rows": unavailable_rows,
                  "validation_rows": len(valid),
                  "lgbm_rmse": score(valid.pm25, prediction),
                  "recent_30d_mean_rmse": score(valid.pm25, baseline)}
        fold_results.append(result)
        log.info("Validation %s: n=%d, later-available rows excluded=%d; LightGBM RMSE=%.3f; recent-mean RMSE=%.3f",
                 fold_start, len(valid), unavailable_rows, result["lgbm_rmse"], result["recent_30d_mean_rmse"])
    if not fold_results:
        raise RuntimeError("No validation labels found")

    x_all = make_features(seasonal, seasonal, stations)
    x_test = make_features(test, seasonal, stations)
    model = build_model()
    model.fit(x_all, seasonal.pm25)
    predictions = np.maximum(model.predict(x_test), 0)
    predicted_by_id = pd.Series(predictions, index=test.ID)
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(predicted_by_id)
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert len(submission) == 2592 and submission.Target.notna().all()
    assert np.isfinite(submission.Target).all() and (submission.Target >= 0).all()
    submission_path = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_path, index=False, float_format="%.6f")
    reloaded = pd.read_csv(submission_path)
    assert reloaded.ID.tolist() == sample.ID.tolist() and reloaded.Target.notna().all()
    model.booster_.save_model(str(run_dir / f"lightgbm_model_{stamp}.txt"))
    importance = pd.DataFrame({"feature": x_all.columns,
                               "gain": model.booster_.feature_importance(importance_type="gain")})
    importance.sort_values("gain", ascending=False).to_csv(run_dir / f"feature_importance_{stamp}.csv", index=False)
    valid_n = sum(f["validation_rows"] for f in fold_results)
    pooled_rmse = float(np.sqrt(sum(f["validation_rows"] * f["lgbm_rmse"] ** 2
                                    for f in fold_results) / valid_n))
    pooled_baseline_rmse = float(np.sqrt(sum(f["validation_rows"] * f["recent_30d_mean_rmse"] ** 2
                                             for f in fold_results) / valid_n))
    metrics = {"run_timestamp_ist": stamp, "forecast_gap_days": GAP_DAYS,
               "fit_months": list(TRAIN_MONTHS), "final_fit_rows": len(seasonal),
               "final_fit_by_year_month": {str(period): int(n) for period, n in
                   seasonal.groupby(seasonal.timestamp_ist.dt.strftime("%Y-%m")).size().items()},
               "excluded_other_month_rows": len(clean) - len(seasonal),
               "excluded_flagged_rows": len(train) - len(clean), "folds": fold_results,
               "validation_rows_total": valid_n, "pooled_validation_rmse": pooled_rmse,
               "pooled_baseline_rmse": pooled_baseline_rmse,
               "mean_fold_rmse": float(np.mean([f["lgbm_rmse"] for f in fold_results])),
               "mean_baseline_rmse": float(np.mean([f["recent_30d_mean_rmse"] for f in fold_results])),
               "submission_rows": len(submission), "prediction_min": float(predictions.min()),
               "prediction_median": float(np.median(predictions)), "prediction_max": float(predictions.max()),
               "input_files": {s: input_file(s).name for s in ["Train", "Test", "SampleSubmission", "Stations"]}}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Pooled validation RMSE: LightGBM %.3f; recent mean %.3f (%d labeled hours)",
             pooled_rmse, pooled_baseline_rmse, valid_n)
    log.info("Submission: %s; %d rows; prediction range %.3f to %.3f",
             submission_path, len(submission), predictions.min(), predictions.max())


if __name__ == "__main__":
    main()
