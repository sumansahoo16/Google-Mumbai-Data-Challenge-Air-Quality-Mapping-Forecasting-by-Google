# Mumbai PM2.5: five-year source and trend review

Analysis created 2026-11-08 IST. Values below are monthly mean PM2.5 concentrations in µg/m³, not AQI. A month is considered well covered at >=75% of calendar hours.

## Data found

| Period | Available PM2.5 series | Use in this analysis |
|---|---|---|
| 2022–2024 | OpenAQ public archive, AirNow monitor 8039 / sensor 23320 | Historical context, kept separate from competition stations |
| 2024–February 2025 | OpenCity republication of CPCB 15-minute data for Borivali East, Malad West, Byculla, Shivaji Nagar | Four named stations, with coverage and OpenCity site IDs shown |
| March 2025–November 2026 | Zindi Train.csv, four CPCB target sensor IDs | Four competition stations |

The OpenCity 2017–2023 files for these station names are AQI matrices, without a PM2.5 concentration field, so they were excluded. The OpenAQ archive has no 2023 files under the exact Borivali East, Malad West, Byculla, or Shivaji Nagar competition location IDs checked here; the 2022 Borivali/Malad archive records are sparse and use different sensor IDs. No valid four-station PM2.5 concentration series was established for 2022–2023.

## Main seasonal result

The four CPCB station names show a sharp rise after September. Only stations with >=75% coverage in **both** compared months enter each pair:

| Year | September mean | October mean | Stations compared | October / September |
|---|---:|---:|---|---:|
| 2024 | 14.2 | 44.2 | Malad West, Byculla | 3.1× |
| 2025 | 18.5 | 43.7 | All four | 2.4× |
| 2026 | 15.3 | 46.1 | All four | 3.0× |

The 2024 Borivali East September month has only 11% coverage and Shivaji Nagar October only 37%, so they are not part of the 2024 paired comparison. The 2026 November competition data extends only through November 2 and is unsuitable as a full monthly average.

November continues the rise where full months are available. Holding the same adequately covered stations within each year, **2024 Malad West + Byculla** go from 14.2 (September) to 44.2 (October) to **83.0 (November)**. **2025 Borivali East + Malad West + Shivaji Nagar** go from 18.7 to 44.5 to **77.2**. The HTML plot displays all available September–November points and marks sparse or partial months with open circles and dashed segments.

The independent AirNow monitor also rises in the same season, but its values cannot be read as competition-station levels:

| Year | September | October | November | Coverage note |
|---|---:|---:|---:|---|
| 2022 | 18.7 | 40.6 | 75.1 | September only 30% covered |
| 2023 | 13.8 | 52.3 | 73.8 | All three months >=96% covered |
| 2024 | 14.4 | 42.4 | 79.8 | All three months >=92% covered |
| 2025 | — | — | — | AirNow monitor absent |
| 2026 | 16.5 | 123.2 | 73.4 | November partial; October much higher than CPCB stations |

The 2026 AirNow October value is an unexplained monitor-specific divergence from the four CPCB stations (their mean was 46.1). It should not be pooled with them or used as a competition label.

## Year-on-year conclusion

The seasonal rise is much stronger than any demonstrated long-term movement. For the same three sufficiently covered CPCB stations (Borivali East, Malad West, Byculla), October means are **42.8 in 2024**, **38.9 in 2025**, and **45.8 in 2026**. That variation does not establish a steady increase or decrease. Changes in instrument IDs, data pipeline, and coverage limit inference.

## Source agreement check

The 2025 OpenCity and Zindi monthly means are usually close for Borivali East, Malad West, and Byculla when both have >=75% coverage. **Shivaji Nagar is an exception**: in October 2025, OpenCity gives 39.3 and Zindi gives 58.1 µg/m³ despite 80% and 85% respective coverage. The source ID and processing differences are unresolved. Keep the two original series distinguishable; the five-year table uses Zindi from March 2025 onward because it is the competition training source.

## Reproducibility

- `monthly_pm25_2022_2026.csv`: month, station, source, ID, mean, median, observed hours, coverage.
- `overlap_check_2025.csv`: OpenCity versus Zindi monthly comparison.
- `provenance.json`: source files and aggregation rule.
- `five_year_pm25_heatmap.html`: offline interactive heatmap; select monitor and mean/median.
- `analyze_five_year_pm25_code.py` and `build_five_year_heatmap_code.py`: code copies.

Sources: [OpenCity CPCB collection](https://data.opencity.in/dataset/mumbai-hourly-air-quality-reports), [OpenAQ public archive documentation](https://docs.openaq.org/aws/year-guide), [Zindi competition data page](https://zindi.world/competitions/google-mumbai-data-challenge/data).
