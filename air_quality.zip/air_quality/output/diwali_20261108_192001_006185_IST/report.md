# Diwali PM2.5 analysis

All times IST; concentrations µg/m³.
Diwali dates: 20 October 2025 and 8 November 2026.
Latest available observation: 2026-11-04 23:00 IST.
The 2026 source snapshot ends before Diwali, so no 2026 after-festival effect can be measured.
The 2025 comparison is observational and does not establish that fireworks caused the change.
Values above 1,000 µg/m³ were excluded from summary statistics as flagged extreme readings.

| Period | Station-hours | Median | Mean | P90 |
|---|---:|---:|---:|---:|
| 2025 pre, Oct 13–17 | 430 | 52.8 | 58.2 | 78.2 |
| 2025 festival, Oct 20 | 58 | 96.9 | 114.0 | 132.3 |
| 2025 after, Oct 21–22 | 175 | 72.2 | 90.5 | 142.2 |
| 2025 after, Oct 23–25 | 273 | 24.4 | 31.5 | 68.8 |
| 2026 before, Nov 1–4 | 258 | 37.3 | 36.4 | 47.3 |

The plot and CSV contain per-station daily medians and observation counts.
