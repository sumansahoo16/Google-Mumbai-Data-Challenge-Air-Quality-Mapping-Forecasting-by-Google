"""Weighted recent-day hourly PM2.5 forecast, repeated across target dates.

Requested weights, relative to the November 9 forecast origin:
November 8 = 0.4; November 7 = 0.3; November 6/5/4 = 0.1 each.
If a whole day has fewer than 12 station readings, carry forward the most
recent earlier well-covered day. Missing hours within that source day use the
seven-day station-hour median. No smoothing or target-date trend is applied.

Run: python3.11 air_quality/train_weighted_recent_days.py
All training, validation, prediction, and submission logic is in this file.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT, OUTPUT = ROOT / "input", ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
ORIGIN = pd.Timestamp("2026-11-09", tz=IST)
EXCLUDED_DAY = "2026-11-09"
BASE_WINDOW_DAYS = 7
DAY_WEIGHTS = ((1, 0.4), (2, 0.3), (3, 0.1), (4, 0.1), (5, 0.1))
MIN_DAY_HOURS = 12
VALIDATION_STARTS = ("2026-10-17", "2026-10-22", "2026-10-27",
                     "2026-11-01", "2026-11-03", "2026-11-05")


def newest(stem: str) -> Path:
    files = list(INPUT.glob(f"{stem}*.csv"))
    if not files:
        raise FileNotFoundError(f"Missing {stem} CSV in {INPUT}")
    return max(files, key=lambda p: (p.stat().st_mtime_ns, p.name))


def load() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    train_path = newest("Train")
    train = pd.read_csv(train_path)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    train = train.loc[(~train.flag_high_1000.astype(bool)) & train.pm25.notna() &
                      np.isfinite(train.pm25) & (train.pm25 >= 0)].copy()
    train["hour_start"] = train.timestamp_ist - pd.Timedelta(hours=1)
    train["day"] = train.hour_start.dt.strftime("%Y-%m-%d")
    train["hour"] = train.hour_start.dt.hour
    assert not train.duplicated(["location_id", "timestamp_ist"]).any()
    test = pd.read_csv(newest("Test"))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["hour"] = test.target_start_ist.dt.hour
    sample = pd.read_csv(newest("SampleSubmission"))
    assert train.location_id.nunique() == 4
    assert len(test) == len(sample) == 2592
    assert test.ID.is_unique and sample.ID.is_unique and set(test.ID) == set(sample.ID)
    return train, test, sample, train_path


def fit(train: pd.DataFrame, origin: pd.Timestamp) -> tuple[pd.Series, pd.Series, pd.DataFrame, pd.DataFrame]:
    recent = train.loc[(train.hour_start >= origin - pd.Timedelta(days=BASE_WINDOW_DAYS)) &
                       (train.hour_start < origin) & (train.day != EXCLUDED_DAY)].copy()
    stations = sorted(train.location_id.unique())
    keys = pd.MultiIndex.from_product([stations, range(24)], names=["location_id", "hour"])
    base = recent.groupby(["location_id", "hour"]).pm25.median().reindex(keys)
    station_median = recent.groupby("location_id").pm25.median()
    if len(station_median) != len(stations):
        raise ValueError(f"A station has no recent history at {origin}")
    fallback = pd.Series(keys.get_level_values("location_id").map(station_median).to_numpy(), index=keys)
    base = base.fillna(fallback)
    if base.isna().any():
        raise ValueError("Unable to construct the fallback hourly profile")

    weighted = pd.Series(0.0, index=keys)
    sources = []
    for station_id in stations:
        station = recent.loc[recent.location_id == station_id]
        counts = station.groupby("day").size()
        eligible = sorted(counts[counts >= MIN_DAY_HOURS].index)
        for lag, weight in DAY_WEIGHTS:
            requested = (origin - pd.Timedelta(days=lag)).strftime("%Y-%m-%d")
            prior = [day for day in eligible if day <= requested]
            source = prior[-1] if prior else None
            observed = station.loc[station.day == source].set_index("hour").pm25 if source else pd.Series(dtype=float)
            values = observed.reindex(range(24))
            missing_hours = int(values.isna().sum())
            values = values.fillna(base.loc[station_id].reset_index(drop=True))
            if values.isna().any():
                raise ValueError(f"Missing hourly forecast at station {station_id}, day {requested}")
            weighted.loc[station_id] += weight * values.to_numpy()
            sources.append({"location_id": int(station_id), "requested_day": requested,
                            "nominal_weight": weight, "source_day": source,
                            "source_day_rows": int(counts.get(source, 0)) if source else 0,
                            "hours_filled_from_hourly_median": missing_hours,
                            "whole_day_carried_forward": source != requested})
    return weighted, base, recent, pd.DataFrame(sources)


def predict(rows: pd.DataFrame, profile: pd.Series) -> np.ndarray:
    keys = pd.MultiIndex.from_frame(rows[["location_id", "hour"]])
    values = profile.reindex(keys).to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Missing station-hour prediction")
    return values


def validate(train: pd.DataFrame) -> dict:
    folds = []
    for day in VALIDATION_STARTS:
        start = pd.Timestamp(day, tz=IST)
        origin = start - pd.Timedelta(days=2)
        valid = train.loc[(train.hour_start >= start) &
                          (train.hour_start < start + pd.Timedelta(days=2))]
        weighted, base, _, sources = fit(train, origin)
        observed = valid.pm25.to_numpy()
        errors = observed - predict(valid, weighted)
        base_errors = observed - predict(valid, base)
        folds.append({"target_start_day": day, "origin_ist": str(origin),
                      "scored_rows": len(valid),
                      "weighted_rmse": float(np.sqrt(np.mean(errors ** 2))),
                      "weighted_mae": float(np.mean(np.abs(errors))),
                      "fixed_hourly_median_rmse": float(np.sqrt(np.mean(base_errors ** 2))),
                      "carried_forward_station_days": int(sources.whole_day_carried_forward.sum())})
    n = sum(f["scored_rows"] for f in folds)
    return {"folds": folds, "rows": n,
            "weighted_pooled_rmse": float(np.sqrt(sum(f["scored_rows"] * f["weighted_rmse"] ** 2 for f in folds) / n)),
            "weighted_pooled_mae": float(sum(f["scored_rows"] * f["weighted_mae"] for f in folds) / n),
            "fixed_hourly_median_pooled_rmse": float(np.sqrt(sum(f["scored_rows"] * f["fixed_hourly_median_rmse"] ** 2 for f in folds) / n))}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = args.output_root / f"weighted_recent_days_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_weighted_recent_days_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("weighted_recent_days")
    train, test, sample, train_path = load()
    weighted, base, recent, sources = fit(train, ORIGIN)
    check = validate(train)
    values = predict(test, weighted)
    by_id = pd.Series(values, index=test.ID)
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(by_id)
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    assert (submission.Target >= 0).all()
    invariant = test[["location_id", "hour"]].copy()
    invariant["prediction"] = values
    assert invariant.groupby(["location_id", "hour"]).prediction.nunique().eq(1).all()
    submission_file = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_file, index=False, float_format="%.6f")
    assert pd.read_csv(submission_file).ID.tolist() == sample.ID.tolist()

    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    profile = weighted.rename("weighted_prediction_pm25").to_frame().join(
        base.rename("fixed_hourly_median_pm25")).reset_index()
    profile["difference_pm25"] = profile.weighted_prediction_pm25 - profile.fixed_hourly_median_pm25
    profile = profile.merge(stations, on="location_id", how="left", validate="many_to_one")
    profile.to_csv(run_dir / f"hourly_profile_comparison_{stamp}.csv", index=False, float_format="%.6f")
    sources = sources.merge(stations, on="location_id", how="left", validate="many_to_one")
    sources.to_csv(run_dir / f"weight_sources_{stamp}.csv", index=False)
    metrics = {"run_timestamp_ist": stamp,
               "method": "hourly weighted mean of five recent day slots; missing whole days carried forward; missing hours use seven-day station-hour median",
               "train_file": train_path.name, "latest_observation_ist": str(train.timestamp_ist.max()),
               "forecast_origin_ist": str(ORIGIN), "excluded_history_day": EXCLUDED_DAY,
               "nominal_day_weights": {str(lag): weight for lag, weight in DAY_WEIGHTS},
               "minimum_hours_for_day": MIN_DAY_HOURS,
               "final_window_observed_rows": len(recent),
               "whole_day_carried_forward_slots": int(sources.whole_day_carried_forward.sum()),
               "effective_weight_on_source_day_by_station": {
                   str(int(station_id)): {str(day): float(weight) for day, weight in
                       frame.groupby("source_day", dropna=False).nominal_weight.sum().items()}
                   for station_id, frame in sources.groupby("location_id")},
               "no_smoothing": True, "no_target_date_trend": True,
               "validation": check,
               "validation_limit": "Retrospective by observation timestamp; historical first-publication times are not verified.",
               "submission_rows": len(submission), "prediction_min": float(submission.Target.min()),
               "prediction_max": float(submission.Target.max())}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Train %s; latest %s; %d history rows", train_path.name, train.timestamp_ist.max(), len(recent))
    log.info("Sources: %s", sources[["location_id", "requested_day", "source_day", "nominal_weight"]].to_dict(orient="records"))
    log.info("Backtest weighted RMSE %.3f; fixed median %.3f over %d rows",
             check["weighted_pooled_rmse"], check["fixed_hourly_median_pooled_rmse"], check["rows"])
    log.info("Submission %s; %d rows; range %.3f–%.3f",
             submission_file, len(submission), submission.Target.min(), submission.Target.max())
    print(run_dir)


if __name__ == "__main__":
    main()
