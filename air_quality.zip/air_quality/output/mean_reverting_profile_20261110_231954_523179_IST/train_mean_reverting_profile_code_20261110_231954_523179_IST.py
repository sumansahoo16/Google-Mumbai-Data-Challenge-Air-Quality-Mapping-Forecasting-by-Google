"""Train a 30-day, pre-Diwali mean-reverting station/hour forecast.

Run: python3.11 air_quality/train_mean_reverting_profile.py

This file alone loads data, validates candidate settings, fits the final model,
and creates a timestamped submission and reproducibility artifacts.
"""

from __future__ import annotations

import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
if not (ROOT / "input").is_dir():
    ROOT = ROOT.parent.parent
INPUT, OUTPUT = ROOT / "input", ROOT / "output"
IST = ZoneInfo("Asia/Kolkata")
FINAL_CUTOFF = pd.Timestamp("2026-11-08", tz=IST)
WINDOW_DAYS = 30
FOLD_STARTS = ("2026-10-17", "2026-10-22", "2026-10-27",
               "2026-11-01", "2026-11-03", "2026-11-05")
RECENT_HALF_LIVES = (2.5, 5.0)
REVERSION_HALF_LIVES = (3.0, 7.0)
TAIL_WEIGHTS = (0.0, 0.5, 1.0)


def newest(stem: str) -> Path:
    files = list(INPUT.glob(f"{stem}*.csv"))
    if not files:
        raise FileNotFoundError(f"Missing {stem} CSV")
    return max(files, key=lambda p: (p.stat().st_mtime_ns, p.name))


def load() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    path = newest("Train")
    train = pd.read_csv(path)
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert(IST)
    train["available_at"] = pd.to_datetime(train.available_at, utc=True, format="mixed").dt.tz_convert(IST)
    train = train.loc[train.pm25.notna() & np.isfinite(train.pm25) & (train.pm25 >= 0) &
                      ~train.flag_high_1000.astype(bool)].copy()
    train["hour_start"] = train.timestamp_ist - pd.Timedelta(hours=1)
    train["day"] = train.hour_start.dt.floor("D")
    train["hour"] = train.hour_start.dt.hour
    assert not train.duplicated(["location_id", "hour_start"]).any()
    test = pd.read_csv(newest("Test"))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert(IST)
    test["hour"] = test.target_start_ist.dt.hour
    sample = pd.read_csv(newest("SampleSubmission"))
    assert test.ID.is_unique and sample.ID.is_unique and set(test.ID) == set(sample.ID)
    return train, test, sample, path


def history_at(train: pd.DataFrame, cutoff: pd.Timestamp,
               as_of: pd.Timestamp | None) -> pd.DataFrame:
    keep = ((train.hour_start >= cutoff - pd.Timedelta(days=WINDOW_DAYS)) &
            (train.hour_start < cutoff))
    if as_of is not None:
        keep &= train.available_at <= as_of
    return train.loc[keep].copy()


def robust_daily_level(values: np.ndarray) -> float:
    """Winsorized daily average: retain mean scale while limiting one spike."""
    q_low, q_high = np.quantile(values, [0.10, 0.90])
    return float(np.clip(values, q_low, q_high).mean())


def fourier(hours: np.ndarray) -> np.ndarray:
    phase = 2 * np.pi * np.asarray(hours, dtype=float) / 24
    return np.column_stack([f(k * phase) for k in (1, 2, 3)
                            for f in (np.sin, np.cos)])


def hourly_shape(data: pd.DataFrame, daily: pd.DataFrame,
                 stations: list[int]) -> dict[int, np.ndarray]:
    centered = data.merge(daily[["location_id", "day", "daily_level"]],
                          on=["location_id", "day"], validate="many_to_one")
    centered["residual"] = centered.pm25 - centered.daily_level
    x = fourier(centered.hour.to_numpy())
    # The shared city shape is a weak prior for a station with missing hours.
    pooled = np.linalg.solve(x.T @ x + 40 * np.eye(6), x.T @ centered.residual.to_numpy())
    profiles = {}
    hours = fourier(np.arange(24))
    for station in stations:
        block = centered.loc[centered.location_id == station]
        if len(block) < 48:
            raise ValueError(f"Too few hourly readings for station {station}")
        z = fourier(block.hour.to_numpy())
        # Roughly 24 pooled observations shrink each station's six coefficients.
        coef = np.linalg.solve(z.T @ z + 24 * np.eye(6),
                               z.T @ block.residual.to_numpy() + 24 * pooled)
        shape = hours @ coef
        profiles[station] = shape - shape.mean()
    return profiles


def fit(data: pd.DataFrame, cutoff: pd.Timestamp,
        recent_half_life: float) -> dict:
    stations = sorted(data.location_id.unique().tolist())
    if len(stations) != 4:
        raise ValueError(f"Expected four stations, got {stations}")
    daily = data.groupby(["location_id", "day"]).pm25.agg(
        n="size", daily_level=lambda x: robust_daily_level(x.to_numpy())).reset_index()
    daily = daily.loc[daily.n >= 8].copy()
    if daily.groupby("location_id").size().min() < 5:
        raise ValueError("Insufficient days at a station")
    shapes = hourly_shape(data, daily, stations)
    long_level, recent_level, tail_allowance, last_day = {}, {}, {}, {}
    raw_tail = {}
    for station in stations:
        ds = daily.loc[daily.location_id == station].sort_values("day")
        age = (cutoff - ds.day).dt.total_seconds().to_numpy() / 86400
        long_weight = np.exp2(-age / 20.0)
        long_level[station] = float(np.average(ds.daily_level, weights=long_weight))
        recent = ds.loc[ds.day >= cutoff - pd.Timedelta(days=7)].copy()
        if recent.empty:
            recent = ds.tail(3).copy()
        recent_age = (cutoff - recent.day).dt.total_seconds().to_numpy() / 86400
        recent_weight = np.exp2(-recent_age / recent_half_life)
        recent_level[station] = float(np.average(recent.daily_level, weights=recent_weight))
        last_day[station] = ds.day.max()
        # This is the empirical gap between an ordinary level and the arithmetic
        # mean, which is the optimal point forecast under squared error.
        s = data.loc[data.location_id == station].copy()
        s = s.merge(ds[["day", "daily_level"]], on="day", how="inner", validate="many_to_one")
        residual = s.pm25.to_numpy() - s.daily_level.to_numpy() - shapes[station][s.hour.to_numpy()]
        raw_tail[station] = max(0.0, float(residual.mean()))
    global_tail = float(np.mean(list(raw_tail.values())))
    for station in stations:
        tail_allowance[station] = 0.75 * raw_tail[station] + 0.25 * global_tail
    return {"stations": stations, "daily": daily, "shapes": shapes,
            "long": long_level, "recent": recent_level, "last_day": last_day,
            "tail": tail_allowance, "history_rows": len(data)}


def predict(rows: pd.DataFrame, model: dict, reversion_half_life: float,
            tail_weight: float, date_col: str) -> np.ndarray:
    result = np.empty(len(rows), dtype=float)
    for station in model["stations"]:
        mask = rows.location_id.to_numpy() == station
        block = rows.loc[mask]
        if block.empty:
            continue
        days_ahead = (block[date_col].dt.floor("D") - model["last_day"][station]).dt.total_seconds().to_numpy() / 86400
        decay = np.exp2(-np.maximum(days_ahead, 0) / reversion_half_life)
        level = model["long"][station] + decay * (model["recent"][station] - model["long"][station])
        result[mask] = np.maximum(0, level + model["shapes"][station][block.hour.to_numpy()] +
                                  tail_weight * model["tail"][station])
    if not np.isfinite(result).all():
        raise ValueError("Nonfinite forecast")
    return result


def median_benchmark(history: pd.DataFrame, rows: pd.DataFrame,
                     cutoff: pd.Timestamp) -> np.ndarray:
    recent = history.loc[history.hour_start >= cutoff - pd.Timedelta(days=7)]
    station_hour = recent.groupby(["location_id", "hour"]).pm25.median()
    station = recent.groupby("location_id").pm25.median()
    keys = pd.MultiIndex.from_frame(rows[["location_id", "hour"]])
    result = station_hour.reindex(keys).to_numpy(dtype=float)
    fallback = rows.location_id.map(station).fillna(
        rows.location_id.map(history.groupby("location_id").pm25.median())).to_numpy(dtype=float)
    result = np.where(np.isnan(result), fallback, result)
    return result


def score(actual: np.ndarray, predicted: np.ndarray) -> dict:
    error = predicted - actual
    return {"rows": int(len(actual)), "rmse": float(np.sqrt(np.mean(error ** 2))),
            "mae": float(np.mean(np.abs(error))), "bias_prediction_minus_actual": float(error.mean())}


def validate(train: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    folds, predictions = [], []
    for day in FOLD_STARTS:
        start = pd.Timestamp(day, tz=IST)
        cutoff = start - pd.Timedelta(days=3)
        # Match today's setup: on the evening before the target, ignore the
        # last three calendar days of readings and use only already available rows.
        as_of = start - pd.Timedelta(seconds=1)
        history = history_at(train, cutoff, as_of)
        target = train.loc[(train.hour_start >= start) &
                           (train.hour_start < start + pd.Timedelta(days=2))].copy()
        if target.empty:
            continue
        actual = target.pm25.to_numpy()
        baseline = median_benchmark(history, target, cutoff)
        if not np.isfinite(baseline).all():
            raise ValueError(f"Missing benchmark at {day}")
        predictions.append(pd.DataFrame({"fold": day, "location_id": target.location_id.to_numpy(),
                                         "hour_start": target.hour_start.to_numpy(), "actual": actual,
                                         "median_7d": baseline}))
        folds.append({"fold": day, "cutoff": str(cutoff), "as_of": str(as_of),
                      "history_rows": len(history), "validation_rows": len(target),
                      "median_rmse": score(actual, baseline)["rmse"]})
        for half_life in RECENT_HALF_LIVES:
            model = fit(history, cutoff, half_life)
            for revert in REVERSION_HALF_LIVES:
                for tail in TAIL_WEIGHTS:
                    name = f"recent{half_life:g}_revert{revert:g}_tail{tail:g}"
                    predictions[-1][name] = predict(target, model, revert, tail, "hour_start")
    combined = pd.concat(predictions, ignore_index=True)
    scores = []
    for name in ["median_7d"] + [c for c in combined if c.startswith("recent")]:
        result = score(combined.actual.to_numpy(), combined[name].to_numpy())
        scores.append({"candidate": name, **result})
    leaderboard = pd.DataFrame(scores).sort_values(["rmse", "mae"]).reset_index(drop=True)
    return leaderboard, combined, pd.DataFrame(folds)


def main() -> None:
    stamp = datetime.now(IST).strftime("%Y%m%d_%H%M%S_%f_IST")
    run_dir = OUTPUT / f"mean_reverting_profile_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, run_dir / f"train_mean_reverting_profile_code_{stamp}.py")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.FileHandler(run_dir / f"training_{stamp}.log"),
                                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger("mean_reverting_profile")
    train, test, sample, train_path = load()
    leaderboard, validation_rows, folds = validate(train)
    winner = leaderboard.iloc[0]
    # The baseline remains in the comparison but the submitted model must be
    # this strategy's best candidate, even if it does not beat the baseline.
    candidate = leaderboard.loc[leaderboard.candidate != "median_7d"].iloc[0]
    name = str(candidate.candidate)
    recent_half_life, remainder = name.removeprefix("recent").split("_revert")
    reversion_half_life, tail_weight = remainder.split("_tail")
    recent_half_life, reversion_half_life, tail_weight = map(float, (recent_half_life, reversion_half_life, tail_weight))
    history = history_at(train, FINAL_CUTOFF, None)
    assert history.hour_start.min() >= pd.Timestamp("2026-10-09", tz=IST)
    assert history.hour_start.max() < FINAL_CUTOFF
    model = fit(history, FINAL_CUTOFF, recent_half_life)
    predicted = predict(test, model, reversion_half_life, tail_weight, "target_start_ist")
    submission = sample[["ID"]].copy()
    submission["Target"] = submission.ID.map(pd.Series(predicted, index=test.ID))
    assert submission.columns.tolist() == ["ID", "Target"]
    assert submission.ID.tolist() == sample.ID.tolist()
    assert submission.Target.notna().all() and np.isfinite(submission.Target).all()
    assert (submission.Target >= 0).all()
    submission_file = run_dir / f"submission_{stamp}.csv"
    submission.to_csv(submission_file, index=False, float_format="%.6f")
    assert pd.read_csv(submission_file).ID.tolist() == sample.ID.tolist()

    leaderboard.to_csv(run_dir / f"validation_leaderboard_{stamp}.csv", index=False, float_format="%.6f")
    folds.to_csv(run_dir / f"validation_folds_{stamp}.csv", index=False)
    validation_rows.to_csv(run_dir / f"validation_predictions_{stamp}.csv", index=False, float_format="%.6f")
    model["daily"].to_csv(run_dir / f"training_daily_levels_{stamp}.csv", index=False, float_format="%.6f")
    stations = pd.read_csv(newest("Stations"))[["location_id", "station_name"]]
    profiles = []
    for station in model["stations"]:
        for hour in range(24):
            profiles.append({"location_id": station, "hour": hour,
                             "hourly_effect": model["shapes"][station][hour],
                             "long_level": model["long"][station],
                             "recent_level": model["recent"][station],
                             "tail_allowance": model["tail"][station]})
    pd.DataFrame(profiles).merge(stations, on="location_id", validate="many_to_one").to_csv(
        run_dir / f"station_hour_profile_{stamp}.csv", index=False, float_format="%.6f")
    metrics = {"run_timestamp_ist": stamp, "method": "30-day robust dynamic station level + partially pooled Fourier hourly shape + validated tail allowance",
               "train_file": train_path.name, "training_window_start_ist": str(FINAL_CUTOFF - pd.Timedelta(days=30)),
               "training_window_end_exclusive_ist": str(FINAL_CUTOFF),
               "excluded_diwali_and_after": "2026-11-08 onward",
               "training_rows": len(history), "latest_training_hour_start_ist": str(history.hour_start.max()),
               "selected_candidate": name, "selected_validation": candidate.to_dict(),
               "median_benchmark_validation": leaderboard.loc[leaderboard.candidate == "median_7d"].iloc[0].to_dict(),
               "validation_winner": str(winner.candidate), "validation_rows": len(validation_rows),
               "validation_note": "Same two-day targets and 3-day history cutoff; historical availability_at honored. Candidate selected on these folds, so its validation score is selection-biased.",
               "submission_rows": len(submission), "prediction_min": float(submission.Target.min()),
               "prediction_max": float(submission.Target.max()), "input_note": "Only Train, Test, SampleSubmission, and Stations CSVs read. No last_days_data used."}
    (run_dir / f"metrics_{stamp}.json").write_text(json.dumps(metrics, indent=2) + "\n")
    log.info("Training window %s to %s; %d observations", metrics["training_window_start_ist"], FINAL_CUTOFF, len(history))
    log.info("Selected %s: validation RMSE %.3f; 7-day median RMSE %.3f", name,
             candidate.rmse, metrics["median_benchmark_validation"]["rmse"])
    log.info("Submission %s (%d rows), range %.2f–%.2f", submission_file, len(submission),
             submission.Target.min(), submission.Target.max())
    print(run_dir)


if __name__ == "__main__":
    main()
