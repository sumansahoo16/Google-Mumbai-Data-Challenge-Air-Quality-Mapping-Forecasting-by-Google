"""Analyze the competition's CPCB-derived Train data around Diwali 2025.

Uses only Python's standard library. Run: python3 air_quality/diwali_source_analysis.py
"""

import csv
import shutil
import statistics
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "input" / "Train (2).csv"
STAMP = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
OUT = ROOT / "output" / f"diwali_source_{STAMP}"
OUT.mkdir(parents=True)

PERIODS = {
    "baseline_oct13_17": ("2025-10-13", "2025-10-17"),
    "leadup_oct18_19": ("2025-10-18", "2025-10-19"),
    "diwali_oct20": ("2025-10-20", "2025-10-20"),
    "next_day_oct21": ("2025-10-21", "2025-10-21"),
    "days2_3_oct22_23": ("2025-10-22", "2025-10-23"),
    "days4_5_oct24_25": ("2025-10-24", "2025-10-25"),
}


def med(values):
    return statistics.median(values) if values else None


def write_csv(name, rows, fields):
    with (OUT / name).open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


data = []
removed = 0
with SOURCE.open(newline="") as fh:
    for row in csv.DictReader(fh):
        date = row["timestamp_ist"][:10]
        if not "2025-10-10" <= date <= "2025-10-27":
            continue
        value = float(row["pm25"])
        if row["flag_high_1000"].lower() == "true" or not 0 <= value <= 1000:
            removed += 1
            continue
        data.append({"date": date, "hour": int(row["timestamp_ist"][11:13]),
                     "station": row["station_name"].split(",")[0], "pm25": value})

stations = sorted({r["station"] for r in data})
groups = defaultdict(list)
for r in data:
    groups[(r["date"], r["station"])].append(r["pm25"])

daily = []
for day in sorted({r["date"] for r in data}):
    for station in stations:
        values = groups[(day, station)]
        daily.append({"date": day, "station": station, "observed_hours": len(values),
                      "coverage_pct": round(len(values) / 24 * 100, 1),
                      "median_pm25": round(med(values), 2) if values else ""})
write_csv("daily_station.csv", daily, list(daily[0]))

period_rows = []
for period, (start, end) in PERIODS.items():
    subset = [r for r in data if start <= r["date"] <= end]
    for station in ["ALL", *stations]:
        values = [r["pm25"] for r in subset if station == "ALL" or r["station"] == station]
        expected = 24 * (int(end[-2:]) - int(start[-2:]) + 1) * (4 if station == "ALL" else 1)
        period_rows.append({"period": period, "station": station, "hours": len(values),
                            "expected_hours": expected, "coverage_pct": round(len(values)/expected*100, 1),
                            "median_pm25": round(med(values), 2) if values else "",
                            "mean_pm25": round(statistics.mean(values), 2) if values else ""})
write_csv("period_station.csv", period_rows, list(period_rows[0]))

hourly = []
for date in ["2025-10-19", "2025-10-20", "2025-10-21", "2025-10-22"]:
    for hour in range(24):
        values = [r["pm25"] for r in data if r["date"] == date and r["hour"] == hour]
        hourly.append({"date": date, "hour_end_ist": hour, "stations_reporting": len(values),
                       "median_pm25": round(med(values), 2) if values else ""})
write_csv("hourly_festival.csv", hourly, list(hourly[0]))

by_period = {r["period"]: r for r in period_rows if r["station"] == "ALL"}
baseline = by_period["baseline_oct13_17"]["median_pm25"]
lines = ["# Diwali 2025: competition-source PM2.5", "",
         "Source: `input/Train (2).csv`, four CPCB-derived Mumbai PM2.5 stations. All times IST; timestamps mark the end of each hour. Units: µg/m³.",
         "Diwali was 20 October 2025. Three flagged readings above 1,000 µg/m³ were excluded from this window.",
         "", "| Window | Observed/possible station-hours | Coverage | Median PM2.5 | Change vs Oct 13–17 |",
         "|---|---:|---:|---:|---:|"]
for row in period_rows:
    if row["station"] != "ALL":
        continue
    change = 100 * (row["median_pm25"] / baseline - 1)
    lines.append(f'| {row["period"]} | {row["hours"]}/{row["expected_hours"]} | {row["coverage_pct"]}% | {row["median_pm25"]:.1f} | {change:+.1f}% |')
lines += ["", "## Interpretation", "",
          "The rise began before Diwali: Oct 18–19 was elevated relative to Oct 13–17. Oct 20 and Oct 21 remained elevated; levels declined by Oct 22–23 and were lower by Oct 24–25.",
          "These are observed associations, not a causal estimate of fireworks. Weather and other emissions can change at the same time, and station-hour coverage varies by window.",
          "See `daily_station.csv`, `period_station.csv`, and `hourly_festival.csv` for station and hour detail."]
(OUT / "report.md").write_text("\n".join(lines) + "\n")
shutil.copy2(__file__, OUT / "diwali_source_analysis_code.py")
print(OUT)
print("\n".join(lines))
