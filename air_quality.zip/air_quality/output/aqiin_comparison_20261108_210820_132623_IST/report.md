# AQI.in versus Zindi Mumbai PM2.5

Window: 2026-10-10 to 2026-11-08 (30 calendar days, IST).
Zindi source: `input/Train (2).csv`, four OpenAQ/CPCB PM2.5 stations. Flagged values above 1,000 µg/m³ excluded.
Daily Zindi city value is the equal-weight average of four station daily means, only when all four stations report.
AQI.in values must be **daily PM2.5 concentrations in µg/m³**, not AQI index values.

Zindi dates with all four stations: 21/30.
Matched dates with AQI.in concentration: 0.

**Correlation cannot be computed:** no AQI.in dated daily PM2.5 concentration series was available.
The public page was blocked by Cloudflare; the 30-day API returned HTTP 401 without authentication.
AQI.in displays a Mumbai city estimate and many location names, but no matching sensor IDs were verified.
A matching location name alone does not establish identical monitors or data processing.

AQI.in dashboard: https://www.aqi.in/in/dashboard/india/maharashtra/mumbai/pm
Competition: https://zindi.world/competitions/google-mumbai-data-challenge/data
