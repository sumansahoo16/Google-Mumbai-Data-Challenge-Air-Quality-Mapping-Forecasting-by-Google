"""Compare the two statistical submissions in an offline November 1–12 HTML.

This script only joins existing predictions and observations for review.
Training and submission creation live entirely in train_recent_level_adjusted_median.py.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input"
START = pd.Timestamp("2026-11-01", tz="Asia/Kolkata")
END = pd.Timestamp("2026-11-13", tz="Asia/Kolkata")

HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mumbai PM2.5 | Two statistical submissions</title>
<style>
:root{--ink:#172235;--muted:#58687d;--bg:#f3f6fa;--line:#dce5ee;--blue:#2465d8;--green:#07806f;--red:#d44c3d}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}main{max-width:1300px;margin:auto;padding:24px 20px 50px}h1{font-size:27px;margin:0 0 4px}h2{font-size:18px;margin:0 0 12px}h3{font-size:15px;margin:0 0 4px}p{margin:0 0 9px}.muted,.small{color:var(--muted)}.small{font-size:12px}.panel{background:white;border:1px solid var(--line);border-radius:11px;padding:17px;margin:15px 0}.note{background:#eaf5f3;border-left:4px solid var(--green);padding:11px 14px;border-radius:6px;margin:15px 0}.controls{display:flex;flex-wrap:wrap;gap:16px;align-items:end;margin:8px 0 12px}.controls label{display:flex;flex-direction:column;gap:4px;color:var(--muted);font-size:12px}.controls select{font:inherit;padding:6px 8px;border:1px solid #b8c8d8;background:white;border-radius:6px}.slide{min-width:230px;flex:1}.slide input{width:100%;accent-color:var(--blue)}.legend{display:flex;flex-wrap:wrap;gap:18px;margin:11px 0;font-size:12px;color:var(--muted)}.key{display:inline-block;width:18px;height:3px;vertical-align:middle;margin-right:5px}.base{background:var(--blue)}.candidate{background:var(--green)}.actual{background:var(--red)}.plot{margin:0 0 18px}.plot svg{display:block;width:100%;height:auto}.plot text{font:11px system-ui,sans-serif;fill:var(--muted)}.grid{stroke:#e5ebf2}.axis{stroke:#a9b8c8}.base-line{fill:none;stroke:var(--blue);stroke-width:2}.candidate-line{fill:none;stroke:var(--green);stroke-width:2.5}.actual-line{fill:none;stroke:var(--red);stroke-width:1.6}.actual-dot{fill:var(--red);stroke:white;stroke-width:.6}.hit{fill:transparent}.clip{fill:var(--red)}.tablewrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:7px 9px;border-bottom:1px solid #e6edf3;text-align:left}th{background:#edf2f7}td.num{text-align:right;font-variant-numeric:tabular-nums}.win{color:#08715f;font-weight:700}.loss{color:#a84e30}@media(max-width:700px){main{padding:15px 10px}.panel{padding:11px}.slide{min-width:100%}}
</style></head><body><main><h1>Second submission: recent station-level adjustment</h1><p class="muted">November 1–12, 2026 · hourly PM2.5 · µg/m³ · Asia/Kolkata · run __STAMP__</p>
<div class="note">Both submissions use the same station-specific 24-hour median pattern. The second adds one fixed station-level amount, estimated from the median error on that station's latest day with at least 12 readings. The current latest eligible day is 6 November. November 9 is excluded. The amount stays constant across forecast days; there is no trend or smoothing.</div>
<section class="panel"><h2>Slide through the predictions and actuals</h2><div class="controls"><label>Visible span<select id="span"><option value="1">1 day</option><option value="3">3 days</option><option value="7" selected>7 days</option><option value="12">12 days</option></select></label><label>Station<select id="station"><option value="all">All four stations</option>__STATION_OPTIONS__</select></label><label>Y axis<select id="axis"><option value="120">0–120 focus</option><option value="__FULL_MAX__">0–__FULL_MAX__ all values</option></select></label><label class="slide">Slide through dates <span id="rangeLabel"></span><input id="slider" type="range" min="1" max="6" step="1" value="1"></label></div>
<div class="legend"><span><i class="key base"></i>First submission: hourly median</span><span><i class="key candidate"></i>Second: hourly median + station level</span><span><i class="key actual"></i>Observed</span></div><div id="plots"></div><p class="small">The Y scale stays fixed while sliding. A red triangle means the observation is above the chosen axis. Hover over points for exact values. X labels show local date and hour. November 1–6 includes observations used to fit these profiles, so visual fit there is not independent validation.</p></section>
<section class="panel"><h2>Station adjustments</h2><div class="tablewrap"><table><thead><tr><th>Station</th><th>Recent day</th><th>Readings</th><th>Added to every hour (µg/m³)</th></tr></thead><tbody id="adjustments"></tbody></table></div><p class="small">The adjustment is the median of actual minus the first submission's hourly prediction on the selected recent day, capped at ±20 µg/m³. It may be positive or negative on another data snapshot.</p></section>
<section class="panel"><h2>Retrospective two-day-gap validation</h2><div class="tablewrap"><table><thead><tr><th>Target window starts</th><th>Observed hours</th><th>First RMSE</th><th>Second RMSE</th><th>Change</th></tr></thead><tbody id="folds"></tbody></table></div><p id="overall"></p><p class="small">These six windows use observation timestamps, but the first-publication time of historical readings is not verified. November windows did not consistently improve. Private scoring is November 11–12 and remains unknown.</p></section></main>
<script>
const data=__DATA__,stations=__STATIONS__,adjustments=__ADJUSTMENTS__,baseValidation=__BASE_VALIDATION__,newValidation=__NEW_VALIDATION__;
const NS='http://www.w3.org/2000/svg',fmt=v=>v===null?'—':Number(v).toFixed(2),byId=Object.fromEntries(stations.map(s=>[s.id,s.name]));
function svg(parent,tag,attrs={},label=''){const e=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(label)e.textContent=label;parent.appendChild(e);return e}
function path(points){return points.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ')}
function render(){const width=+document.getElementById('span').value,slider=document.getElementById('slider');slider.max=13-width;if(+slider.value>13-width)slider.value=13-width;const first=+slider.value,last=first+width-1,ymax=+document.getElementById('axis').value;document.getElementById('rangeLabel').textContent=`${first}–${last} Nov`;const selection=document.getElementById('station').value,chosen=selection==='all'?stations:stations.filter(s=>String(s.id)===selection);const host=document.getElementById('plots');host.innerHTML='';const start=Date.parse(`2026-11-${String(first).padStart(2,'0')}T00:00:00+05:30`),end=start+width*86400000,W=1100,H=215,L=54,R=15,T=15,B=41,pw=W-L-R,ph=H-T-B,x=t=>L+(t-start)/(end-start)*pw,y=v=>T+ph-Math.min(Math.max(v,0),ymax)/ymax*ph;
for(const st of chosen){const series=data.filter(r=>r.location_id===st.id&&r.day>=first&&r.day<=last);const wrap=document.createElement('div');wrap.className='plot';const h=document.createElement('h3');h.textContent=st.name;wrap.appendChild(h);const g=svg(wrap,'svg',{viewBox:`0 0 ${W} ${H}`,role:'img','aria-label':st.name+' two predictions and actual readings'});for(const v of [0,Math.round(ymax/2),ymax]){svg(g,'line',{x1:L,y1:y(v),x2:W-R,y2:y(v),class:'grid'});svg(g,'text',{x:L-7,y:y(v)+4,'text-anchor':'end'},String(v))}const tick=width===1?3:width===3?6:width===7?12:24;for(let hr=0;hr<=width*24;hr+=tick){const t=start+hr*3600000,xx=x(t),d=new Date(t+19800000);svg(g,'line',{x1:xx,y1:T,x2:xx,y2:T+ph,class:'grid'});const label=width===1?`${String(d.getUTCHours()).padStart(2,'0')}:00`:`${d.getUTCDate()} Nov ${String(d.getUTCHours()).padStart(2,'0')}`;svg(g,'text',{x:xx,y:H-11,'text-anchor':hr===0?'start':hr===width*24?'end':'middle'},label)}svg(g,'line',{x1:L,y1:T+ph,x2:W-R,y2:T+ph,class:'axis'});svg(g,'path',{d:path(series.map(r=>[x(Date.parse(r.time)),y(r.base)])),class:'base-line'});svg(g,'path',{d:path(series.map(r=>[x(Date.parse(r.time)),y(r.candidate)])),class:'candidate-line'});for(const r of series){const xx=x(Date.parse(r.time));for(const key of ['base','candidate']){const hit=svg(g,'circle',{cx:xx,cy:y(r[key]),r:3,class:'hit'});svg(hit,'title',{},`${r.label} · ${key} ${fmt(r[key])}`)}}let seg=[],prev=null;function flush(){if(seg.length>1)svg(g,'path',{d:path(seg),class:'actual-line'});seg=[]}for(const r of series){if(r.actual===null){flush();prev=null;continue}const t=Date.parse(r.time);if(prev!==null&&t-prev!==3600000)flush();const xx=x(t);seg.push([xx,y(r.actual)]);prev=t;const dot=r.actual>ymax?svg(g,'path',{d:`M ${xx-4} ${T+9} L ${xx} ${T} L ${xx+4} ${T+9} Z`,class:'clip'}):svg(g,'circle',{cx:xx,cy:y(r.actual),r:3,class:'actual-dot'});svg(dot,'title',{},`${r.label} · actual ${fmt(r.actual)} · first ${fmt(r.base)} · second ${fmt(r.candidate)}`)}flush();host.appendChild(wrap)}}
document.getElementById('adjustments').innerHTML=adjustments.map(a=>`<tr><td>${byId[a.location_id]}</td><td>${a.recent_day||'—'}</td><td class="num">${a.recent_hours}</td><td class="num">${a.level_shift>=0?'+':''}${fmt(a.level_shift)}</td></tr>`).join('');
document.getElementById('folds').innerHTML=baseValidation.folds.map((b,i)=>{const n=newValidation.folds[i],delta=n.rmse-b.rmse;return `<tr><td>${b.target_start_day}</td><td class="num">${b.scored_rows}</td><td class="num">${fmt(b.rmse)}</td><td class="num">${fmt(n.rmse)}</td><td class="num ${delta<0?'win':'loss'}">${delta>=0?'+':''}${fmt(delta)}</td></tr>`}).join('');
document.getElementById('overall').textContent=`Pooled RMSE: first ${fmt(baseValidation.pooled_rmse)}, second ${fmt(newValidation.pooled_rmse)} µg/m³ across ${newValidation.rows} observations. A lower value is better.`;
for(const id of ['span','station','axis'])document.getElementById(id).addEventListener('change',render);document.getElementById('slider').addEventListener('input',render);render();
</script></body></html>'''


def only(path: Path, pattern: str) -> Path:
    files = list(path.glob(pattern))
    if len(files) != 1:
        raise ValueError(f"Expected exactly one {pattern} in {path}")
    return files[0]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-run", type=Path, required=True)
    parser.add_argument("--candidate-run", type=Path, required=True)
    args = parser.parse_args()
    base_run, candidate_run = args.base_run.resolve(), args.candidate_run.resolve()
    base = pd.read_csv(only(base_run, "submission_*.csv")).rename(columns={"Target": "base_prediction_pm25"})
    candidate = pd.read_csv(only(candidate_run, "submission_*.csv")).rename(columns={"Target": "candidate_prediction_pm25"})
    base_metrics = json.loads(only(base_run, "metrics_*.json").read_text())
    candidate_metrics = json.loads(only(candidate_run, "metrics_*.json").read_text())
    test = pd.read_csv(max(INPUT.glob("Test*.csv"), key=lambda p: p.stat().st_mtime_ns))
    train = pd.read_csv(max(INPUT.glob("Train*.csv"), key=lambda p: p.stat().st_mtime_ns))
    test["target_start_ist"] = pd.to_datetime(test.target_start_ist, utc=True).dt.tz_convert("Asia/Kolkata")
    test["target_end_ist"] = pd.to_datetime(test.target_end_ist, utc=True).dt.tz_convert("Asia/Kolkata")
    train["timestamp_ist"] = pd.to_datetime(train.timestamp_ist, utc=True, format="mixed").dt.tz_convert("Asia/Kolkata")
    paired = test.loc[(test.target_start_ist >= START) & (test.target_start_ist < END)].copy()
    paired = paired.merge(base, on="ID", how="left", validate="one_to_one").merge(candidate, on="ID", how="left", validate="one_to_one")
    paired = paired.merge(train[["location_id", "timestamp_ist", "pm25"]].rename(columns={"timestamp_ist": "target_end_ist", "pm25": "actual_pm25"}), on=["location_id", "target_end_ist"], how="left", validate="one_to_one")
    assert len(paired) == 1152 and paired.base_prediction_pm25.notna().all() and paired.candidate_prediction_pm25.notna().all()
    paired = paired.sort_values(["target_start_ist", "location_id"])
    stations = pd.read_csv(max(INPUT.glob("Stations*.csv"), key=lambda p: p.stat().st_mtime_ns))[["location_id", "station_name"]].sort_values("location_id")
    paired = paired.merge(stations, on="location_id", how="left", validate="many_to_one")
    stamp = candidate_run.name.removeprefix("recent_level_adjusted_median_")
    csv_file = candidate_run / f"two_submission_comparison_20261101_20261112_{stamp}.csv"
    paired[["ID", "location_id", "station_name", "target_start_ist", "base_prediction_pm25", "candidate_prediction_pm25", "actual_pm25"]].to_csv(csv_file, index=False, float_format="%.6f")
    rows = [{"location_id": int(r.location_id), "day": int(r.target_start_ist.day),
             "time": r.target_start_ist.isoformat(), "label": r.target_start_ist.strftime("%d Nov %H:%M"),
             "base": round(float(r.base_prediction_pm25), 4),
             "candidate": round(float(r.candidate_prediction_pm25), 4),
             "actual": None if pd.isna(r.actual_pm25) else round(float(r.actual_pm25), 4)}
            for r in paired.itertuples(index=False)]
    full_max = int(np.ceil(max(paired.actual_pm25.max(), paired.candidate_prediction_pm25.max()) / 50) * 50)
    station_data = [{"id": int(r.location_id), "name": r.station_name} for r in stations.itertuples(index=False)]
    html = (HTML.replace("__STAMP__", stamp).replace("__FULL_MAX__", str(full_max))
            .replace("__STATION_OPTIONS__", "".join(f'<option value="{s["id"]}">{s["name"]}</option>' for s in station_data))
            .replace("__STATIONS__", json.dumps(station_data))
            .replace("__ADJUSTMENTS__", json.dumps(candidate_metrics["station_adjustments"]))
            .replace("__BASE_VALIDATION__", json.dumps(base_metrics["validation"]))
            .replace("__NEW_VALIDATION__", json.dumps(candidate_metrics["validation"]))
            .replace("__DATA__", json.dumps(rows).replace("</", "<\\/")))
    html_file = candidate_run / f"two_submission_review_20261101_20261112_{stamp}.html"
    html_file.write_text(html, encoding="utf-8")
    shutil.copy2(__file__, candidate_run / f"build_level_adjustment_review_code_{stamp}.py")
    print(html_file)
    print(csv_file)
    print(f"Rows {len(paired)}; observed {paired.actual_pm25.notna().sum()}; full Y axis {full_max}")


if __name__ == "__main__":
    main()
