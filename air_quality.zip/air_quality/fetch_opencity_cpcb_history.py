"""Fetch four CPCB-derived OpenCity PM2.5 files for 2024–2025.

Run: python3 air_quality/fetch_opencity_cpcb_history.py
Use --manifest-only to document the newest already-downloaded folder.
"""

import hashlib
import json
import shutil
import sys
import urllib.request
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent / "input"
BASE = "https://data.opencity.in/dataset/a99667bf-a5b8-40ae-9553-1329847292f4/resource"
FILES = {
    "borivali.csv": f"{BASE}/a4093a01-ce53-4740-8138-706b0cfdd8e3/download/mum-borivali-east-iitm-2024-25.csv",
    "malad.csv": f"{BASE}/e00bab2c-8c23-42d9-9ea5-306bab5cf1ae/download/mum-malad-west-iitm-2024-25.csv",
    "byculla.csv": f"{BASE}/2123fa6b-3260-4428-9fd0-669848bfb787/download/mum-byculla-bmc-2024-25.csv",
    "shivaji.csv": f"{BASE}/7001f676-43d3-4c7b-b5ff-e7dee0e95f83/download/mum-shivaji-nagar-bmc-2024-25.csv",
}


def main() -> None:
    if sys.argv[1:] == ["--manifest-only"]:
        folder = sorted(ROOT.glob("opencity_cpcb_2024_2025_*"))[-1]
    elif sys.argv[1:]:
        raise SystemExit("Usage: fetch_opencity_cpcb_history.py [--manifest-only]")
    else:
        stamp = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
        folder = ROOT / f"opencity_cpcb_2024_2025_{stamp}"
        folder.mkdir(parents=True, exist_ok=False)
        for filename, url in FILES.items():
            request = urllib.request.Request(url, headers={"User-Agent": "MumbaiPM25History/1.0"})
            with urllib.request.urlopen(request, timeout=90) as source, (folder / filename).open("wb") as target:
                shutil.copyfileobj(source, target)
            print(filename, (folder / filename).stat().st_size, flush=True)

    manifest = {
        "documented_at_ist": datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(),
        "catalog": "https://data.opencity.in/dataset/mumbai-hourly-air-quality-reports",
        "upstream": "CPCB CAAQMS repository, republished by OpenCity",
        "period_as_published": "2024-01-01 through 2025-12-31 UTC",
        "parameter": "PM2.5 concentration (µg/m³); 15-minute timestamps stored as UTC in CSV",
        "files": {},
    }
    for filename, url in FILES.items():
        path = folder / filename
        manifest["files"][filename] = {
            "url": url, "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    (folder / "provenance.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(folder)


if __name__ == "__main__":
    main()
