"""Build a self-contained year-by-month PM2.5 heatmap from the ten-year CSV.

Run: python3 air_quality/build_ten_year_heatmap.py
"""

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
snapshots = sorted((ROOT / "input").glob("mumbai_pm25_ten_year_*/monthly_pm25_2017_2026.csv"))
if not snapshots:
    raise FileNotFoundError("Run fetch_ten_year_pm25.py first")
source = snapshots[-1]
with source.open(newline="") as stream:
    records = list(csv.DictReader(stream))

stamp = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
out = ROOT / "output" / f"ten_year_pm25_{stamp}"
out.mkdir(parents=True, exist_ok=False)
shutil.copy2(__file__, out / "build_ten_year_heatmap_code.py")

html = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mumbai PM2.5 · 2017–2026 monthly history</title><style>
:root{--bg:#f6f8f7;--panel:#fff;--ink:#163027;--muted:#597067;--line:#dce6df;--accent:#087a61}*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.wrap{max-width:1180px;margin:auto;padding:26px}h1{font-size:clamp(25px,3vw,36px);margin:0 0 4px}p{color:var(--muted);margin:4px 0 0}.panel{background:var(--panel);border:1px solid var(--line);border-radius:16px;margin-top:19px;padding:22px;box-shadow:0 8px 32px #183c2c0b}
.controls{display:flex;gap:18px;flex-wrap:wrap;align-items:end}.controls label{display:grid;gap:5px;font-size:12px;font-weight:650;color:var(--muted)}select{border:1px solid #c7d6cb;border-radius:8px;background:#fff;color:var(--ink);padding:9px 12px;min-height:42px;font:inherit}.matrixWrap{overflow-x:auto;margin-top:20px}.matrix{display:grid;grid-template-columns:62px repeat(12,minmax(70px,1fr));gap:5px;min-width:900px}.head{font-weight:650;font-size:12px;color:var(--muted);text-align:center;padding:8px 0}.year{font-weight:700;padding:16px 5px;color:var(--ink)}.cell{border-radius:7px;min-height:56px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;position:relative}.cell.sparse{outline:2px dashed #ac5b42;outline-offset:-4px}.cell.empty{background:#f1f4f2;color:#a4b1aa;font-weight:400}.legend{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:17px;font-size:12px;color:var(--muted)}.gradient{width:190px;height:12px;border-radius:8px;background:linear-gradient(90deg,#e5f1eb,#9acdb9,#409b83,#175b71,#473a87)}.note{font-size:13px;margin-top:14px}.source{font-size:12px;margin-top:10px}a{color:#086e58}@media(max-width:600px){.wrap{padding:14px}.panel{padding:14px}}
</style></head><body><main class="wrap"><h1>Mumbai PM2.5 · 10 calendar years</h1><p>Monthly values, 2017–2026. Choose one monitor to keep sources and sensors distinct.</p>
<section class="panel"><div class="controls"><label>Monitor<select id="series"><option value="openaq_airnow_8039_23320">Mumbai AirNow · 2017–2026</option><option value="zindi_cpcb_12236418">Borivali East · CPCB target</option><option value="zindi_cpcb_12236426">Malad West · CPCB target</option><option value="zindi_cpcb_12238567">Byculla · CPCB target</option><option value="zindi_cpcb_12238576">Shivaji Nagar · CPCB target</option></select></label><label>Statistic<select id="stat"><option value="mean_pm25_ug_m3">Monthly mean</option><option value="median_pm25_ug_m3">Monthly median</option></select></label></div>
<div class="matrixWrap"><div class="matrix" id="matrix" role="img" aria-label="Monthly PM2.5 heatmap from 2017 to 2026"></div></div><div class="legend"><span>0</span><span class="gradient"></span><span>100+ µg/m³</span><span>Dashed border: under 75% hourly coverage</span><span>Grey: no observations</span></div><p class="note" id="coverageNote"></p><p class="source">Source data: <a href="https://docs.openaq.org/aws/about">OpenAQ public archive</a> (AirNow monitor) and <a href="https://zindi.world/competitions/google-mumbai-data-challenge/data">Zindi Train.csv</a> (four CPCB target sensors). The AirNow monitor is separate from the competition targets.</p></section></main>
<script id="data" type="application/json">__DATA__</script><script>
const data=JSON.parse(document.getElementById('data').textContent),lookup=new Map(data.map(r=>[r.series_id+'|'+r.month_ist,r]));
const series=document.getElementById('series'),stat=document.getElementById('stat'),matrix=document.getElementById('matrix'),note=document.getElementById('coverageNote');
const names=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function color(v){let p=Math.min(1,Math.max(0,v/100)),a=p<.5?[229,241,235]:[64,155,131],b=p<.5?[64,155,131]:[71,58,135],q=p<.5?p*2:(p-.5)*2;return 'rgb('+a.map((x,i)=>Math.round(x+(b[i]-x)*q)).join(',')+')'}
function render(){matrix.replaceChildren();let empty=document.createElement('div');matrix.append(empty);for(const m of names){let e=document.createElement('div');e.className='head';e.textContent=m;matrix.append(e)}
 let measured=0,sparse=0;for(let year=2017;year<=2026;year++){let y=document.createElement('div');y.className='year';y.textContent=year;matrix.append(y);for(let month=1;month<=12;month++){
  let key=year+'-'+String(month).padStart(2,'0'),row=lookup.get(series.value+'|'+key),v=row&&row[stat.value]!==''?Number(row[stat.value]):null;
  let cell=document.createElement('div');cell.className='cell'+(v===null?' empty':'')+(v!==null&&Number(row.coverage_pct)<75?' sparse':'');
  if(v===null){cell.textContent='—';cell.title=key+': no observations'}else{cell.textContent=v.toFixed(1);cell.style.background=color(v);cell.style.color=v>=45?'#fff':'#163027';cell.title=key+': '+v.toFixed(3)+' µg/m³; '+row.observed_hours+' observed hours; '+row.coverage_pct+'% coverage';measured++;if(Number(row.coverage_pct)<75)sparse++}
  matrix.append(cell)
 }}note.textContent=measured+' months with data; '+sparse+' have under 75% hourly coverage. Hover a month for exact value and coverage.'}
series.addEventListener('change',render);stat.addEventListener('change',render);render();
</script></body></html>'''

target = out / "ten_year_pm25_heatmap.html"
target.write_text(html.replace("__DATA__", json.dumps(records, separators=(",", ":"))))
print(target)
print(f"Monthly rows: {len(records)}; HTML bytes: {target.stat().st_size}")
