"""Create interactive hourly and rolling charts of competition PM2.5 targets.

Run: python3 air_quality/build_four_station_timeline.py
The generated HTML is self-contained and uses only Zindi Train (2).csv.
"""

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
TRAIN = ROOT / "input" / "Train (2).csv"
STAMP = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y%m%d_%H%M%S_%f_IST")
OUT = ROOT / "output" / f"four_station_timeline_{STAMP}"
OUT.mkdir(parents=True)

stations = [
    (11606, 12236418, "Borivali East"),
    (11611, 12236426, "Malad West"),
    (3409510, 12238567, "Byculla"),
    (3409511, 12238576, "Shivaji Nagar"),
]
station_index = {(str(loc), str(sensor)): i for i, (loc, sensor, _) in enumerate(stations)}
hourly = {}
excluded = 0
with TRAIN.open(newline="") as fh:
    for row in csv.DictReader(fh):
        key = (row["location_id"], row["sensor_id"])
        if key not in station_index:
            continue
        value = float(row["pm25"])
        if row["flag_high_1000"].lower() == "true" or not 0 <= value <= 1000:
            excluded += 1
            continue
        hour = row["timestamp_ist"][:16]
        readings = hourly.setdefault(hour, [None] * 4)
        if readings[station_index[key]] is not None:
            raise ValueError(f"Duplicate station-hour: {key} {hour}")
        readings[station_index[key]] = round(value, 2)

rows = [[hour, *readings] for hour, readings in sorted(hourly.items())]
data = {"stations": [s[2] for s in stations], "rows": rows,
        "first": rows[0][0][:10], "last": rows[-1][0][:10],
        "excluded": excluded}

html = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mumbai hourly PM2.5 · four stations</title>
<style>
:root{--bg:#f6f8f7;--panel:#fff;--ink:#163027;--muted:#597067;--line:#dce6df;--a:#087a61;--b:#d8732d;--c:#3775bd;--d:#a34db4;--marker:#ad3f43}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.wrap{max-width:1320px;margin:auto;padding:25px}h1{margin:0;font-size:clamp(24px,3vw,34px);line-height:1.2}p{color:var(--muted);margin:4px 0 0}.panel{margin-top:18px;padding:22px;background:var(--panel);border:1px solid var(--line);border-radius:16px;box-shadow:0 8px 32px #183c2c0b}.controls{display:flex;align-items:end;gap:22px;flex-wrap:wrap}.controls label{display:grid;gap:5px;color:var(--muted);font-size:12px;font-weight:650}.controls select{border:1px solid #c7d6cb;border-radius:8px;background:#fff;color:var(--ink);padding:9px 12px;min-height:42px;font:inherit}.sliderArea{flex:1;min-width:240px}.sliderArea input{width:100%;accent-color:var(--a);height:28px;margin:4px 0 0;cursor:pointer}.rangeText{font-size:17px;font-weight:650;color:var(--ink)}.legend{display:flex;gap:10px 20px;flex-wrap:wrap;margin:16px 0 5px}.legend span{display:flex;align-items:center;gap:7px;font-size:13px;color:var(--ink)}.swatch{display:inline-block;width:22px;height:4px;border-radius:3px}.chart{height:min(58vw,510px);min-height:330px;position:relative}.chart svg{width:100%;height:100%;display:block;overflow:visible}.grid{stroke:#e4ece7;stroke-width:1}.series{fill:none;stroke-width:2.3;stroke-linecap:round;stroke-linejoin:round}.vline{stroke:#729086;stroke-width:1;stroke-dasharray:3 3}.diwali{stroke:var(--marker);stroke-width:1.5;stroke-dasharray:5 4}.tick{font:12px system-ui,sans-serif;fill:var(--muted)}.axisTitle{font:12px system-ui,sans-serif;fill:var(--muted)}.tip{position:absolute;pointer-events:none;display:none;background:#193c30;color:#fff;border-radius:10px;padding:11px 13px;font-size:12px;line-height:1.55;min-width:175px;box-shadow:0 12px 28px #17382e33;z-index:2}.tip b{font-size:13px}.tip .item{display:flex;justify-content:space-between;gap:22px}.tip .dot{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:5px}.foot{margin-top:9px;font-size:12px;color:var(--muted)}@media(max-width:600px){.wrap{padding:15px}.panel{padding:14px}.chart{min-height:310px;height:370px}.rangeText{font-size:15px}.legend{gap:6px 12px}.legend span{font-size:12px}}
h2{margin:0 0 4px;font-size:20px}.chartNote{margin-bottom:14px}.rollingControls{margin:12px 0 4px}.scaleControl{margin-top:16px;align-items:center}.scaleNote{font-size:12px}
</style></head><body>
<main class="wrap"><h1>Mumbai PM2.5 · four stations</h1><p>Original hourly observations from the competition Train file. Each line is one monitoring station.</p>
<div class="controls scaleControl"><label>Fixed Y-axis maximum for both plots<select id="yMaximum"><option value="100" selected>100 µg/m³</option><option value="200">200 µg/m³</option><option value="400">400 µg/m³</option><option value="1000">1,000 µg/m³</option></select></label><span class="scaleNote">Values above this limit are clipped in the plots; hover for their full values.</span></div>
<section class="panel">
 <div class="controls"><label>Viewing interval<select id="interval"><option value="1">1 day</option><option value="3">3 days</option><option value="7" selected>7 days</option><option value="14">14 days</option><option value="30">30 days</option></select></label><div class="sliderArea"><label for="windowSlider">Slide through the data</label><input type="range" id="windowSlider" min="0" value="0" step="1" aria-label="First day of viewing interval"></div><div class="rangeText" id="rangeText"></div></div>
 <div class="legend" id="legend"></div><div class="chart" id="chart" role="img" aria-label="Hourly PM2.5 at four Mumbai monitoring stations"><div class="tip" id="tip"></div></div>
 <div class="foot">PM2.5 in µg/m³ · times are IST and mark the end of each observed hour · gaps indicate missing readings · <span id="excluded"></span> readings flagged above 1,000 µg/m³ excluded.</div>
</section>
<section class="panel"><h2>Rolling PM2.5 by station</h2><p class="chartNote">The same four stations, with independent date controls.</p>
 <div class="controls rollingControls"><label>Statistic<select id="rollingMetric"><option value="mean">Mean</option><option value="median">Median</option></select></label><label>Trailing window<select id="rollingDays"><option value="1">1 day</option><option value="7" selected>7 days</option><option value="14">14 days</option><option value="30">30 days</option></select></label><label>Viewing interval<select id="rollingInterval"><option value="1">1 day</option><option value="3">3 days</option><option value="7">7 days</option><option value="14">14 days</option><option value="30" selected>30 days</option></select></label><div class="sliderArea"><label for="rollingSlider">Slide through the data</label><input type="range" id="rollingSlider" min="0" value="0" step="1" aria-label="First day of rolling-chart viewing interval"></div><div class="rangeText" id="rollingRangeText"></div></div>
 <div class="chart" id="rollingChart" role="img" aria-label="Rolling PM2.5 at four Mumbai monitoring stations"><div class="tip" id="rollingTip"></div></div>
 <div class="foot">Each value uses valid hourly readings from the previous selected number of days, including before the visible dates. A line pauses after 24 hours without a station reading. Early windows use the readings available so far.</div>
</section></main>
<script id="data" type="application/json">__DATA__</script>
<script>
const D=JSON.parse(document.getElementById('data').textContent),colors=['#087a61','#d8732d','#3775bd','#a34db4'];
const msday=86400000,mshour=3600000,day=s=>Date.parse(s+'T00:00:00Z'),time=s=>Date.parse(s.replace(' ','T')+':00Z');
const fmt=n=>Number(n).toLocaleString('en-IN',{maximumFractionDigits:1});
const labelDate=t=>new Date(t).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
const labelHour=t=>new Date(t).toISOString().slice(0,16).replace('T',' ');
const slider=document.getElementById('windowSlider'),interval=document.getElementById('interval'),chartBox=document.getElementById('chart'),tip=document.getElementById('tip');
const first=day(D.first),last=day(D.last),prepared=D.rows.map(r=>[time(r[0]),...r.slice(1)]);
const rollingChart=document.getElementById('rollingChart'),rollingTip=document.getElementById('rollingTip'),rollingMetric=document.getElementById('rollingMetric'),rollingDays=document.getElementById('rollingDays'),rollingInterval=document.getElementById('rollingInterval'),rollingSlider=document.getElementById('rollingSlider'),rollingRangeText=document.getElementById('rollingRangeText'),yMaximum=document.getElementById('yMaximum'),rollingCache=new Map();
document.getElementById('excluded').textContent=fmt(D.excluded);
D.stations.forEach((s,i)=>{let e=document.createElement('span');e.innerHTML=`<i class="swatch" style="background:${colors[i]}"></i>${s}`;document.getElementById('legend').append(e)});
function node(name,attrs={}){let e=document.createElementNS('http://www.w3.org/2000/svg',name);Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));return e}
function rollingSeries(days,metric){
 const key=days+'-'+metric;if(rollingCache.has(key))return rollingCache.get(key);
 const states=Array.from({length:4},()=>({queue:[],head:0,sum:0,sorted:[],latest:-Infinity})),windowMs=days*msday;
 const lowerBound=(arr,value)=>{let lo=0,hi=arr.length;while(lo<hi){let mid=(lo+hi)>>1;if(arr[mid]<value)lo=mid+1;else hi=mid}return lo};
 const result=prepared.map(row=>{let t=row[0],out=[t];for(let s=0;s<4;s++){
  let st=states[s];while(st.head<st.queue.length&&st.queue[st.head][0]<=t-windowMs){let old=st.queue[st.head++][1];st.sum-=old;if(metric==='median')st.sorted.splice(lowerBound(st.sorted,old),1)}
  if(st.head>512&&st.head*2>st.queue.length){st.queue=st.queue.slice(st.head);st.head=0}
  let value=row[s+1];if(value!==null){st.queue.push([t,value]);st.sum+=value;st.latest=t;if(metric==='median')st.sorted.splice(lowerBound(st.sorted,value),0,value)}
  let count=st.queue.length-st.head;
  if(!count||t-st.latest>24*mshour)out.push(null);
  else if(metric==='mean')out.push(st.sum/count);
  else out.push((st.sorted[(count-1)>>1]+st.sorted[count>>1])/2)
 }return out});rollingCache.set(key,result);return result
}
function setupSlider(viewSelect,viewSlider,keepDate,defaultDate){let days=+viewSelect.value,max=Math.max(0,Math.round((last-first)/msday)-days+1);viewSlider.max=max;let pos=Math.round(((keepDate??day(defaultDate))-first)/msday);viewSlider.value=Math.max(0,Math.min(max,pos));draw()}
function draw(){
 const rolling=rollingSeries(+rollingDays.value,rollingMetric.value);
 for(const [chartBox,tip,source,isRolling,viewSelect,viewSlider,rangeElement] of [[document.getElementById('chart'),document.getElementById('tip'),prepared,false,interval,slider,document.getElementById('rangeText')],[rollingChart,rollingTip,rolling,true,rollingInterval,rollingSlider,rollingRangeText]]){
 let n=+viewSelect.value,start=first+(+viewSlider.value)*msday,end=start+n*msday;
 rangeElement.textContent=labelDate(start)+' – '+labelDate(end-msday);
 chartBox.querySelector('svg')?.remove();tip.style.display='none';let w=Math.max(310,chartBox.clientWidth),h=chartBox.clientHeight,m={l:61,r:20,t:20,b:57},pw=w-m.l-m.r,ph=h-m.t-m.b;
 let svg=node('svg',{viewBox:`0 0 ${w} ${h}`,'aria-hidden':'true'});chartBox.insertBefore(svg,tip);
 const visible=source.filter(r=>r[0]>=start&&r[0]<end),ymax=+yMaximum.value;
 const x=t=>m.l+(t-start)/(end-start)*pw,y=v=>m.t+ph-v/ymax*ph;
 for(let j=0;j<=4;j++){let value=j*ymax/4,yy=y(value);svg.append(node('line',{class:'grid',x1:m.l,x2:w-m.r,y1:yy,y2:yy}));let t=node('text',{class:'tick',x:m.l-9,y:yy+4,'text-anchor':'end'});t.textContent=fmt(value);svg.append(t)}
 if(n<=7){
  const narrow=w<650,stepHours=n===1?(narrow?4:2):n===3?(narrow?12:6):(narrow?24:12);
  for(let tval=start;tval<end;tval+=stepHours*mshour){let tx=x(tval),hour=new Date(tval).toISOString().slice(11,16),isMidnight=hour==='00:00';
   svg.append(node('line',{x1:tx,x2:tx,y1:m.t+ph,y2:m.t+ph+5,stroke:'#b7c8bd'}));
   let hlabel=node('text',{class:'tick',x:tx,y:h-28,'text-anchor':tval===start?'start':'middle'});hlabel.textContent=hour;svg.append(hlabel);
   if(isMidnight){let dlabel=node('text',{class:'tick',x:tx,y:h-10,'text-anchor':tval===start?'start':'middle'});dlabel.textContent=new Date(tval).toLocaleDateString('en-IN',{day:'numeric',month:'short',timeZone:'UTC'});svg.append(dlabel)}
  }
 }else{let nticks=w<560?3:Math.min(7,n+1);for(let j=0;j<nticks;j++){let tval=start+(end-start)*j/(nticks-1),tx=x(tval),t=node('text',{class:'tick',x:tx,y:h-12,'text-anchor':j===0?'start':j===nticks-1?'end':'middle'});t.textContent=labelDate(tval);svg.append(t)}}
 let axis=node('text',{class:'axisTitle',x:m.l,y:12});axis.textContent='PM2.5 µg/m³';svg.append(axis);
 const clipped=visible.reduce((count,row)=>count+row.slice(1).filter(v=>v!==null&&v>ymax).length,0);
 if(clipped){let note=node('text',{class:'axisTitle',x:w-m.r,y:12,'text-anchor':'end'});note.textContent=fmt(clipped)+' above scale';svg.append(note)}
 let d=day('2025-10-20');if(d>=start&&d<end){svg.append(node('line',{class:'diwali',x1:x(d),x2:x(d),y1:m.t,y2:m.t+ph}));let mark=node('text',{class:'tick',x:Math.min(w-85,x(d)+5),y:m.t+13});mark.textContent='Diwali 2025';svg.append(mark)}
 let clipId=isRolling?'rollingPlotClip':'hourlyPlotClip',defs=node('defs'),clip=node('clipPath',{id:clipId});clip.append(node('rect',{x:m.l,y:m.t,width:pw,height:ph}));defs.append(clip);svg.append(defs);
 let seriesLayer=node('g',{'clip-path':`url(#${clipId})`});svg.append(seriesLayer);
 for(let s=0;s<4;s++){let parts=[];const flush=()=>{if(parts.length===1){seriesLayer.append(node('circle',{cx:parts[0][0],cy:parts[0][1],r:3,fill:colors[s]}))}else if(parts.length>1){let p=node('path',{class:'series',stroke:colors[s],d:parts.map((q,i)=>(i?'L':'M')+q[0].toFixed(1)+' '+q[1].toFixed(1)).join(' ')});seriesLayer.append(p)}parts=[]};
 for(let i=0;i<visible.length;i++){let r=visible[i],v=r[s+1];if(v===null){flush();continue}if(i&&r[0]-visible[i-1][0]>(isRolling?24*mshour:mshour))flush();parts.push([x(r[0]),y(v)])}flush()}
 let cross=node('line',{class:'vline',y1:m.t,y2:m.t+ph,visibility:'hidden'});svg.append(cross);
 const hover=e=>{if(!visible.length)return;let rect=svg.getBoundingClientRect(),cursor=(e.clientX-rect.left)*w/rect.width,target=start+(cursor-m.l)/pw*(end-start);let lo=0,hi=visible.length-1;while(lo<hi){let mid=(lo+hi)>>1;if(visible[mid][0]<target)lo=mid+1;else hi=mid}let i=lo;if(i>0&&Math.abs(visible[i-1][0]-target)<Math.abs(visible[i][0]-target))i--;let r=visible[i],px=x(r[0]);cross.setAttribute('x1',px);cross.setAttribute('x2',px);cross.setAttribute('visibility','visible');tip.innerHTML=`<b>${labelHour(r[0])} IST</b>`+D.stations.map((s,j)=>`<div class="item"><span><i class="dot" style="background:${colors[j]}"></i>${s}</span><strong>${r[j+1]===null?'—':fmt(r[j+1])}</strong></div>`).join('');tip.style.display='block';tip.style.left=Math.max(0,Math.min(chartBox.clientWidth-195,e.clientX-rect.left+12))+'px';tip.style.top=Math.max(0,e.clientY-rect.top-75)+'px'};
 svg.addEventListener('pointermove',hover);svg.addEventListener('pointerleave',()=>{tip.style.display='none';cross.setAttribute('visibility','hidden')});
 }
}
slider.addEventListener('input',draw);rollingSlider.addEventListener('input',draw);interval.addEventListener('change',()=>setupSlider(interval,slider,first+(+slider.value)*msday,'2025-10-17'));rollingInterval.addEventListener('change',()=>setupSlider(rollingInterval,rollingSlider,first+(+rollingSlider.value)*msday,'2025-10-01'));rollingMetric.addEventListener('change',draw);rollingDays.addEventListener('change',draw);yMaximum.addEventListener('change',draw);let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(draw,120)});setupSlider(interval,slider,null,'2025-10-17');setupSlider(rollingInterval,rollingSlider,null,'2025-10-01');
</script></body></html>'''

target = OUT / "four_station_timeline.html"
target.write_text(html.replace("__DATA__", json.dumps(data, separators=(",", ":"))))
shutil.copy2(__file__, OUT / "build_four_station_timeline_code.py")
print(target)
print(f"Hourly timestamps: {len(rows)}; valid readings: {sum(v is not None for row in rows for v in row[1:])}; excluded: {excluded}; HTML bytes: {target.stat().st_size}")
