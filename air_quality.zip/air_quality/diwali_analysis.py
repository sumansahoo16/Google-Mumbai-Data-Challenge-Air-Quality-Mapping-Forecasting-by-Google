"""Describe observed Mumbai PM2.5 around Diwali; never uses Test targets to train."""

from datetime import datetime
from pathlib import Path
import shutil

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


BASE = Path(__file__).resolve().parent
TRAIN = BASE / "input" / "Train (2).csv"
ARCHIVE = sorted((BASE / "input").glob("openaq_archive_*/archive_hourly_pm25_*.csv"))
STAMP = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f_%Z")
OUT = BASE / "output" / f"diwali_{STAMP}"
OUT.mkdir(parents=True)

train = pd.read_csv(TRAIN)
train["timestamp_ist"] = pd.to_datetime(train["timestamp_ist"], utc=True).dt.tz_convert("Asia/Kolkata")
train["source"] = "Train"
frames = [train]
if ARCHIVE:
    archive = pd.read_csv(ARCHIVE[-1])
    print("Archive columns:", archive.columns.tolist())
    # Use only archive hours later than the last supplied training observation.
    date_col = "timestamp_ist" if "timestamp_ist" in archive else "hour_end_ist"
    archive["timestamp_ist"] = pd.to_datetime(archive[date_col], utc=True).dt.tz_convert("Asia/Kolkata")
    archive = archive[archive["timestamp_ist"] > train["timestamp_ist"].max()].copy()
    if "pm25" not in archive:
        archive["pm25"] = archive["mean"]
    if "station_name" not in archive:
        stations = train[["location_id", "station_name"]].drop_duplicates()
        archive = archive.merge(stations, on="location_id", how="left")
    if "count" in archive:
        archive = archive[archive["count"] >= 3]
    archive["source"] = "OpenAQ archive"
    frames.append(archive)

data = pd.concat(frames, ignore_index=True)
data = data[data["pm25"].notna() & data["pm25"].between(0, 1000)].copy()
data["date"] = data["timestamp_ist"].dt.date

windows = {
    "2025 pre, Oct 13–17": ("2025-10-13", "2025-10-18"),
    "2025 festival, Oct 20": ("2025-10-20", "2025-10-21"),
    "2025 after, Oct 21–22": ("2025-10-21", "2025-10-23"),
    "2025 after, Oct 23–25": ("2025-10-23", "2025-10-26"),
    "2026 before, Nov 1–4": ("2026-11-01", "2026-11-05"),
    "2026 festival, Nov 8": ("2026-11-08", "2026-11-09"),
    "2026 after, Nov 9–10": ("2026-11-09", "2026-11-11"),
}
rows = []
for period, (start, end) in windows.items():
    sample = data[(data["date"] >= pd.Timestamp(start).date()) & (data["date"] < pd.Timestamp(end).date())]
    for station, group in [("All stations", sample), *list(sample.groupby("station_name"))]:
        rows.append({"period": period, "station": station, "hours": len(group),
                     "median_pm25": group["pm25"].median(), "mean_pm25": group["pm25"].mean(),
                     "p90_pm25": group["pm25"].quantile(.9)})
periods = pd.DataFrame(rows)
periods.to_csv(OUT / "period_summary.csv", index=False)

daily = data.groupby(["date", "station_name"], as_index=False).agg(
    hours=("pm25", "size"), median_pm25=("pm25", "median"))
daily = daily[((daily["date"] >= pd.Timestamp("2025-10-13").date()) &
               (daily["date"] <= pd.Timestamp("2025-10-27").date())) |
              ((daily["date"] >= pd.Timestamp("2026-11-01").date()) &
               (daily["date"] <= pd.Timestamp("2026-11-04").date()))]
daily.to_csv(OUT / "daily_station_medians.csv", index=False)

fig, ax = plt.subplots(figsize=(11, 5))
older = daily[daily["date"] < pd.Timestamp("2026-01-01").date()]
for station, group in older.groupby("station_name"):
    ax.plot(pd.to_datetime(group["date"]), group["median_pm25"], marker="o", label=station.split(",")[0])
ax.axvline(pd.Timestamp("2025-10-20"), color="black", linestyle="--", label="Diwali, Oct 20")
ax.set(ylabel="Daily median PM2.5 (µg/m³)", title="Four Mumbai stations around Diwali 2025")
ax.legend(ncol=2, fontsize=9)
ax.grid(alpha=.25)
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(OUT / "diwali_2025_station_trend.png", dpi=160)
plt.close(fig)

overall = periods[(periods["station"] == "All stations") & (periods["hours"] > 0)]
latest = data["timestamp_ist"].max()
summary = ["# Diwali PM2.5 analysis", "", "All times IST; concentrations µg/m³.",
           "Diwali dates: 20 October 2025 and 8 November 2026.",
           f"Latest available observation: {latest.strftime('%Y-%m-%d %H:%M %Z')}.",
           ("The 2026 source snapshot ends before Diwali, so no 2026 after-festival effect can be measured."
            if latest.date() < pd.Timestamp("2026-11-08").date() else
            "The 2026 festival and after-festival windows are shown if observations are available."),
           "The 2025 comparison is observational and does not establish that fireworks caused the change.",
           "Values above 1,000 µg/m³ were excluded from summary statistics as flagged extreme readings.",
           "", "| Period | Station-hours | Median | Mean | P90 |", "|---|---:|---:|---:|---:|"]
for row in overall.itertuples():
    summary.append(f"| {row.period} | {row.hours} | {row.median_pm25:.1f} | {row.mean_pm25:.1f} | {row.p90_pm25:.1f} |")
summary += ["", "The plot and CSV contain per-station daily medians and observation counts."]
(OUT / "report.md").write_text("\n".join(summary) + "\n")
shutil.copy2(__file__, OUT / "diwali_analysis_code.py")
print(OUT)
print(overall.to_string(index=False))
